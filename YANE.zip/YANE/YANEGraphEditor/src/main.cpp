#include <imgui.h>
#include <backends\imgui_impl_glfw.h>
#include <backends\imgui_impl_opengl3.h>
#include <imnodes.h>

#include <GLFW/glfw3.h>

#include "Graph.hpp"
#include "NodeRegistry.hpp"
#include "YANEGraphEditor.hpp"

#pragma comment(lib, "opengl32.lib")

GLFWwindow* InitGLFW(uint32_t iWidth, uint32_t iHeight, const char* sWindowTitle)
{
    glfwInit();

    GLFWwindow* pGLFWWindow = glfwCreateWindow(iWidth, iHeight, sWindowTitle, nullptr, nullptr );
    glfwMakeContextCurrent(pGLFWWindow);
    glfwSwapInterval(1);

    return pGLFWWindow;
}

void InitImGui(GLFWwindow* pGLFWWindow)
{
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImNodes::CreateContext();

    ImGui::StyleColorsDark();
    ImNodes::StyleColorsDark();

    ImGui_ImplGlfw_InitForOpenGL(pGLFWWindow, true);
    ImGui_ImplOpenGL3_Init("#version 130");
}

void RegisterNodes()
{
    // --- Register nodes ---
    NodeRegistry::Instance().Register(
    {
        "AddInt",
        "Add (Int)",
        {
            {"A", EPinKind::Input, EPinType::Int},
            {"B", EPinKind::Input, EPinType::Int}
        },
        {
            {"Result", EPinKind::Output, EPinType::Int}
        }
    });

    NodeRegistry::Instance().Register(
    {
        "Print",
        "Print",
        {
            {"Value", EPinKind::Input, EPinType::Bool}
        },
        {}
    });
}

void Update(GLFWwindow* pGLFWWindow, GraphEditor* pGraphEditor)
{
    glfwPollEvents();

    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplGlfw_NewFrame();
    ImGui::NewFrame();

    ImGui::Begin("Graph");
    {
        pGraphEditor->Draw();
    }
    ImGui::End();

    ImGui::Render();
    int display_w, display_h;
    glfwGetFramebufferSize(pGLFWWindow, &display_w, &display_h);
    glViewport(0, 0, display_w, display_h);
    glClear(GL_COLOR_BUFFER_BIT);
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

    glfwSwapBuffers(pGLFWWindow);
}

void Cleanup(GLFWwindow* pGLFWWindow)
{
    // 1. imnodes first
    ImNodes::DestroyContext();

    // 2. ImGui backends
    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplGlfw_Shutdown();

    // 3. ImGui core
    ImGui::DestroyContext();

    // 4. THEN destroy window
    glfwDestroyWindow(pGLFWWindow);
    glfwTerminate();
}

int main() 
{
    GLFWwindow* pGLFWWindow = InitGLFW(1280, 800, "Node Editor");
    InitImGui(pGLFWWindow);

    RegisterNodes();

    // --- Create graph ---
    Graph graph;
    {
        graph.CreateNode("AddInt", 100, 200);
        graph.CreateNode("Print", 400, 200);
        graph.CreateNode("AddInt", 300, 200);
    }

    GraphEditor editor(graph);

    // --- Main loop ---
    while (!glfwWindowShouldClose(pGLFWWindow))
    {
        Update(pGLFWWindow, &editor);
    }

    Cleanup(pGLFWWindow);
}
