#pragma once
#include <cstdint>
#include <string>

using NodeID    = uint32_t;
using PinID     = uint32_t;
using LinkID    = uint32_t;

enum class EPinKind 
{
    Input,
    Output
};

enum class EPinType 
{
    Exec,
    Bool,
    Int,
    Float,
    String,
    Wildcard
};
