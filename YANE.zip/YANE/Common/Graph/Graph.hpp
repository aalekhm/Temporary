#pragma once
#include <unordered_map>
#include <vector>
#include <string>
#include "Types.hpp"

struct Pin 
{
    PinID           id;
    NodeID          node;
    EPinKind        kind;
    EPinType        type;
    std::string     name;
};

struct Node 
{
    NodeID              id;
    std::string         name;
    std::string         type;

    std::vector<PinID>  inputs;
    std::vector<PinID>  outputs;

    float               posX = 0.0f;
    float               posY = 0.0f;
};

struct Link 
{
    LinkID      id;
    PinID       from;
    PinID       to;
};

class Graph 
{
    public:
        NodeID          CreateNode(const std::string& type, float x, float y);
        void            RemoveNode(NodeID id);

        bool            CanCreateLink(PinID from, PinID to) const;
        LinkID          CreateLink(PinID from, PinID to);
        void            RemoveLink(LinkID id);

        const Node*     GetNode(NodeID id) const;
        const Pin*      GetPin(PinID id) const;

        // Debug helpers
        void            Dump() const;

        std::unordered_map<NodeID, Node>    nodes;
        std::unordered_map<PinID, Pin>      pins;
        std::unordered_map<LinkID, Link>    links;
    private:
        NodeID                              nextNodeID = 1;
        PinID                               nextPinID = 1;
        LinkID                              nextLinkID = 1;
};
