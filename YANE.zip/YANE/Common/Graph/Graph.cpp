#include "Graph.hpp"
#include "NodeRegistry.hpp"
#include <cassert>
#include <iostream>

NodeID Graph::CreateNode(const std::string& type, float x, float y) 
{
    const NodeDefinition* def = NodeRegistry::Instance().Get(type);
    assert(def && "Unknown node type");

    Node node;
    node.id = nextNodeID++;
    node.type = type;
    node.name = def->m_sDisplayName;
    node.posX = x;
    node.posY = y;

    for (const auto& p : def->m_vInputs) 
    {
        PinID pid = nextPinID++;
        pins[pid] = { pid, node.id, p.m_eKind, p.m_eType, p.m_sName };
        node.inputs.push_back(pid);
    }

    for (const auto& p : def->m_vOutputs) 
    {
        PinID pid = nextPinID++;
        pins[pid] = { pid, node.id, p.m_eKind, p.m_eType, p.m_sName };
        node.outputs.push_back(pid);
    }

    nodes[node.id] = node;
    return node.id;
}

void Graph::RemoveNode(NodeID id) 
{
    auto it = nodes.find(id);
    if (it == nodes.end())
        return;

    for (PinID pid : it->second.inputs)
        pins.erase(pid);
    for (PinID pid : it->second.outputs)
        pins.erase(pid);

    nodes.erase(it);
}

bool Graph::CanCreateLink(PinID a, PinID b) const 
{
    const Pin* p1 = GetPin(a);
    const Pin* p2 = GetPin(b);
    if (!p1 || !p2)
        return false;

    if (p1->kind == p2->kind)
        return false;
    if (p1->type != p2->type)
        return false;

    return p1->kind == EPinKind::Output;
}

LinkID Graph::CreateLink(PinID from, PinID to) 
{
    assert(CanCreateLink(from, to));

    Link link;
    link.id = nextLinkID++;
    link.from = from;
    link.to = to;

    links[link.id] = link;
    return link.id;
}

void Graph::RemoveLink(LinkID id) 
{
    links.erase(id);
}

const Node* Graph::GetNode(NodeID id) const 
{
    auto it = nodes.find(id);
    if (it == nodes.end())
        return nullptr;
    return &it->second;
}

const Pin* Graph::GetPin(PinID id) const 
{
    auto it = pins.find(id);
    if (it == pins.end())
        return nullptr;
    return &it->second;
}

void Graph::Dump() const 
{
    std::cout << "\n=== Graph Dump ===\n";
    for (const auto& [nid, node] : nodes) 
    {
        std::cout << "Node " << nid << " [" << node.name << "]\n";
        for (PinID pid : node.inputs)
            std::cout << "  Input  Pin " << pid << "\n";
        for (PinID pid : node.outputs)
            std::cout << "  Output Pin " << pid << "\n";
    }

    for (const auto& [lid, link] : links) 
    {
        std::cout << "Link " << lid
            << " : " << link.from
            << " -> " << link.to << "\n";
    }
}
