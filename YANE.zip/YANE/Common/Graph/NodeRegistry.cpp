#include "NodeRegistry.hpp"
#include <cassert>

NodeRegistry& NodeRegistry::Instance() 
{
    static NodeRegistry instance;
    return instance;
}

void NodeRegistry::Register(const NodeDefinition& def)
{
    m_vDefs[def.m_sType] = def;
}

const NodeDefinition* NodeRegistry::Get(const std::string& type) const
{
    auto it = m_vDefs.find(type);
    if (it == m_vDefs.end())
    {
        return nullptr;
    }

    return &it->second;
}
