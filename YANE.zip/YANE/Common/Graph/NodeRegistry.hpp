#pragma once
#include <string>
#include <vector>
#include <unordered_map>
#include "Types.hpp"

struct PinDefinition
{
    std::string     m_sName;
    EPinKind        m_eKind;
    EPinType        m_eType;
};

struct NodeDefinition
{
    std::string                     m_sType;
    std::string                     m_sDisplayName;
    std::vector<PinDefinition>      m_vInputs;
    std::vector<PinDefinition>      m_vOutputs;
};

class NodeRegistry 
{
    public:
        static  NodeRegistry&       Instance();

        void                        Register(const NodeDefinition& def);
        const   NodeDefinition*     Get(const std::string& type) const;

    private:
        std::unordered_map<std::string, NodeDefinition> m_vDefs;
};
