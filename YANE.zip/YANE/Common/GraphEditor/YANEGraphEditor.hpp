#pragma once
#include "Graph.hpp"

class GraphEditor 
{
    public:
        explicit    GraphEditor(Graph& graph);

        void        Draw();

    protected:
        void        HandleDelete();
        void        RemoveSelectedLinks(int32_t iCount);
    private:
        Graph&      graph;
};
