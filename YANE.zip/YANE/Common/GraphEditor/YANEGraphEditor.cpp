﻿#include "YANEGraphEditor.hpp"

#include <imgui.h>
#include <imnodes.h>

GraphEditor::GraphEditor(Graph& g)
: graph(g) {}

void GraphEditor::Draw() 
{
    IMNODES_NAMESPACE::BeginNodeEditor();
    {
        // Draw nodes
        for (auto& [nodeID, node] : graph.nodes) 
        {
            ImNodes::BeginNode(node.id);
            {
                ImNodes::BeginNodeTitleBar();
                {
                    ImGui::TextUnformatted(node.name.c_str());
                }
                ImNodes::EndNodeTitleBar();

                // Inputs
                for (PinID pid : node.inputs) 
                {
                    const Pin& pin = graph.pins.at(pid);
                    ImNodes::BeginInputAttribute(pin.id);
                    {
                        ImGui::Text("%s", pin.name.c_str());
                    }
                    ImNodes::EndInputAttribute();
                }

                // Outputs
                for (PinID pid : node.outputs) 
                {
                    const Pin& pin = graph.pins.at(pid);
                    ImNodes::BeginOutputAttribute(pin.id);
                    {
                        ImGui::Indent(40);
                        ImGui::Text("%s", pin.name.c_str());
                    }
                    ImNodes::EndOutputAttribute();
                }
            }
            ImNodes::EndNode();

            //ImNodes::SetNodeGridSpacePos(   node.id,
            //                                ImVec2(node.posX, node.posY));
        }

        // Draw links
        for (auto& [linkID, link] : graph.links) 
        {
            ImNodes::Link(link.id, link.from, link.to);
        }
    }
    ImNodes::EndNodeEditor();

    // Handle 'New' & 'Deleted' links
    {
        // Handle new links
        int startAttr, endAttr;
        if (ImNodes::IsLinkCreated(&startAttr, &endAttr))
        {
            // ImGui will create a link aith any node.
            // The client, has to verify if the link is valid & allow one(update its graph) or discard it.
            if (graph.CanCreateLink((PinID)startAttr, (PinID)endAttr))
            {
                graph.CreateLink((PinID)startAttr, (PinID)endAttr);
            }
            else
            {
                RemoveSelectedLinks(1);
            }
        }

        HandleDelete();
    }
}

void GraphEditor::RemoveSelectedLinks(int32_t iCount)
{
    std::vector<int> selectedLinks(iCount);
    ImNodes::GetSelectedLinks(selectedLinks.data());

    for (int linkId : selectedLinks)
        graph.RemoveLink((LinkID)linkId);

    ImNodes::ClearLinkSelection();
}

void GraphEditor::HandleDelete()
{
    // Handle deleted links
    int selectedLinkCount = ImNodes::NumSelectedLinks();
    if (selectedLinkCount > 0 && ImGui::IsKeyPressed(ImGuiKey_Delete))
    {
        RemoveSelectedLinks(selectedLinkCount);
    }
}