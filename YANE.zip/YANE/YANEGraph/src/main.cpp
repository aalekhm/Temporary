#include "Graph.hpp"
#include "NodeRegistry.hpp"
#include <iostream>

int main() 
{
    // --- Register node types ---
    NodeRegistry::Instance().Register(
    {
        "AddInt",
        "Add (Int)",
        {
            {"A", EPinKind::Input, EPinType::Int},
            {"B", EPinKind::Input, EPinType::Int}
        },
        {
            {"Result", EPinKind::Output, EPinType::Int}
        }
    });

    NodeRegistry::Instance().Register(
    {
        "PrintInt",
        "Print (Int)",
        {
            {"Value", EPinKind::Input, EPinType::Int}
        },
        {}
    });

    // --- Create graph ---
    Graph graph;

    NodeID addNode = graph.CreateNode("AddInt", 100, 100);
    NodeID printNode = graph.CreateNode("PrintInt", 300, 100);

    const Node* add = graph.GetNode(addNode);
    const Node* print = graph.GetNode(printNode);

    // --- Attempt valid link ---
    PinID addResult = add->outputs[0];
    PinID printIn = print->inputs[0];

    if (graph.CanCreateLink(addResult, printIn)) 
    {
        graph.CreateLink(addResult, printIn);
        std::cout << "Link created successfully.\n";
    }
    else 
    {
        std::cout << "Link creation failed.\n";
    }

    // --- Dump graph ---
    graph.Dump();

    return 0;
}
