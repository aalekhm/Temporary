$brushSet = new SimSet() {
   canSaveDynamicFields = "1";
   internalName = "Brushes";
      setType = "Brushes";
};
