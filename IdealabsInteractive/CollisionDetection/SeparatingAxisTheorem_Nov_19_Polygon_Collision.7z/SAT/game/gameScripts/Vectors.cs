
function MovePoly::drawPolygonEdges(%this) {
      %VERTICES = %this.noOfVertices;
      for(%i = 0; %i < %VERTICES; %i++) {
         %ptA = %this.getName()@"_VERTEX_"@%i;
         %ptB = %this.getName()@"_VERTEX_"@%i+1;
         
         if(%i == %VERTICES - 1) {
            %ptB = %this.getName()@"_VERTEX_0";
         }
      
         %vectorEdge = t2dVectorSub(%ptA.getPosition(), %ptB.getPosition());
         %EDGE_LEN = t2dVectorDistance(%ptA.getPosition(), %ptB.getPosition());
         
         %ptA.edge.safeDelete();
         %ptA.edge = point.clone(true);
         
         %ptA.edge.setSize(%EDGE_LEN, 1);
         %ptA.edge.setBlendColor(0, 128, 255, 255);
         
         %edgeNormalized = t2dVectorNormalise(%vectorEdge);
         %centerPos = t2dVectorScale(%edgeNormalized, -%EDGE_LEN/2);      
         %ptA.edge.setPosition(t2dVectorAdd(%ptA.getPosition(), %centerPos));
         
         %angle = calculateAngle(%ptA.getPositionX(), %ptA.getPositionY(), %ptB.getPositionX(), %ptB.getPositionY());
         %ptA.edge.setRotation(%angle);
         
         
         attachToPoly(%this, %ptA);
         attachToPoly(%this, %ptA.edge);
         
         /////////////////////////////////
   }
}

function MovePoly::projectAxis(%this, %CHECK_POLY) {
      %VERTICES = %this.noOfVertices;
      %ALL_AXIS_COLLIDING = true;
      for(%i = 0; %i < %VERTICES; %i++) {
         %ptA = %this@"_VERTEX_"@%i;
         %ptB = %this@"_VERTEX_"@%i+1;
         
         if(%i == %VERTICES - 1) {
            %ptB = %this@"_VERTEX_0";
         }
      
         %vectorEdge = t2dVectorSub(%ptA.getPosition(), %ptB.getPosition());
         %edgeNormalized = t2dVectorNormalise(%vectorEdge);         
         %angle = calculateAngle(%ptA.getPositionX(), %ptA.getPositionY(), %ptB.getPositionX(), %ptB.getPositionY());

         %EDGE_LEN = t2dVectorDistance(%ptA.getPosition(), %ptB.getPosition());
                  
         //Axis Drawing...
         //%LHNormal = -getWord(%vectorEdge, 1) SPC getWord(%vectorEdge, 0);//LeftHandNormal
         //%RHNormal = getWord(%vectorEdge, 1) SPC -getWord(%vectorEdge, 0);//RightHandNormal
         
         //Aa, Draws a perpendicular to the edge from %ptA
         %LHNormal = getWord(%ptA.getPosition(), 0)-getWord(%vectorEdge, 1) SPC getWord(%ptA.getPosition(), 1)+getWord(%vectorEdge, 0);
         %RHNormal = getWord(%ptA.getPosition(), 0)+getWord(%vectorEdge, 1) SPC getWord(%ptA.getPosition(), 1)-getWord(%vectorEdge, 0);

         %axis = t2dVectorSub(%LHNormal, %RHNormal);
         %normalisedAxis = t2dVectorNormalise(%axis);
         
         if($debug) {
            //if(%i == 2) {
               ///*
                  if(!isObject(%ptA.axisPoint))
                     %ptA.axisPoint = point.clone(true);
                  %ptA.axisPoint.setSize(512, 1);
                  %ptA.axisPoint.setBlendColor(128, 128, 128, 255);
                  %ptA.axisPoint.setRotation(90+%angle);
                  %ptA.axisPoint.setPosition(%ptA.getPosition());
                  attachToPoly(%ptA, %ptA.axisPoint);
               //*/
                  
                  if(!isObject(%ptA.LNormal))
                     %ptA.LNormal = LNormal.clone(true);
                  %ptA.LNormal.setPosition(%LHNormal);
                  %ptA.LNormal.setBlendColor(255, 255, 0, 255);
                  attachToPoly(%ptA, %ptA.LNormal);
                  
                  if(!isObject(%ptA.RNormal))
                     %ptA.RNormal = RNormal.clone(true);
                  %ptA.RNormal.setPosition(%RHNormal);
                  %ptA.RNormal.setBlendColor(255, 255, 0, 255);
                  attachToPoly(%ptA, %ptA.RNormal);
            //}
         }
                  %this.MY_LIMITS = %this.projectVertices(%this, %LHNormal, %normalisedAxis, 0);
                  %this.HIS_LIMITS = %this.projectVertices(%CHECK_POLY, %LHNormal, %normalisedAxis, 1);
                  
                  //echo(%this.MY_LIMITS@" %DOTPROD == "@%this.HIS_LIMITS);
                  
                  %myMin = getWord(%this.MY_LIMITS, 0);
                  %myMax = getWord(%this.MY_LIMITS, 1);
                  %hisMin = getWord(%this.HIS_LIMITS, 0);
                  %hisMax = getWord(%this.HIS_LIMITS, 1);


                  if(   (%hisMin >= %myMin && %hisMin <= %myMax)
                        ||
                        (%hisMax >= %myMin && %hisMax <= %myMax)
                        ||
                        (%myMin >= %hisMin && %myMin <= %hisMax)
                        ||
                        (%myMax >= %hisMin && %myMax <= %hisMax)
                  ) {
                        %ALL_AXIS_COLLIDING = true;
                  }
                  else {
                        %ALL_AXIS_COLLIDING = false;
                        break;
                  }
                  
                  //echo("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% "@%ALL_AXIS_COLLIDING);

   }
   
   //echo("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& "@%ALL_AXIS_COLLIDING);
   return %ALL_AXIS_COLLIDING;
}

function MovePoly::projectVertices(%this, %POLYGON, %LHNormal, %normalisedAxis, %isMyVerticesProjection) {
      %VERTICES = %POLYGON.noOfVertices;
      %minProd = %maxProd = 0;
      
      for(%i = 0; %i < %VERTICES; %i++) {
         %VERTEX = %POLYGON@"_VERTEX_"@%i;
         
         %vectB = t2dVectorSub(%LHNormal, %VERTEX.getPosition());
         %DOTPROD = t2dVectorDot(%normalisedAxis, %vectB);
   
         %projB = getWord(%normalisedAxis, 0)*%DOTPROD SPC getWord(%normalisedAxis, 1)*%DOTPROD;
         if($debug) {
            /*
            %projB_Point = point.clone(true);
            %projB_Point.setPosition(t2dVectorSub(%LHNormal, %projB));
            
            if(%isMyVerticesProjection)
               %projB_Point.setBlendColor(128, 0, 128, 255);
            else
               %projB_Point.setBlendColor(0, 255, 255, 255);
               
            attachToPoly(%POLYGON, %projB_Point);
            */
         }
         if(%i == 0) {
            %minProd = %maxProd = %DOTPROD;
         }
         //echo(%minProd@" "@%maxProd@" ___________________________ "@%DOTPROD);
         if(%DOTPROD < %minProd)
            %minProd = %DOTPROD;
         else 
         if(%DOTPROD > %maxProd)
            %maxProd = %DOTPROD;
      }
      
      return (%minProd SPC %maxProd);
      
}

function attachToPoly(%parent, %obj) {
      if(!%obj.getIsMounted()) {
         %localPointVertex = %parent.getLocalPoint(%obj.getPosition());
         %obj.mount(%parent, getWord(%localPointVertex, 0), getWord(%localPointVertex, 1));
      }
}

