
function MovePoly::drawPolygonEdges(%this) {
      %VERTICES = %this.noOfVertices;
      for(%i = 0; %i < %VERTICES; %i++) {
         %ptA = %this.getName()@"_VERTEX_"@%i;
         %ptB = %this.getName()@"_VERTEX_"@%i+1;
         
         if(%i == %VERTICES - 1) {
            %ptB = %this.getName()@"_VERTEX_0";
         }
      
         %vectorEdge = t2dVectorSub(%ptA.getPosition(), %ptB.getPosition());
         %EDGE_LEN = t2dVectorDistance(%ptA.getPosition(), %ptB.getPosition());
         
         %ptA.edge.safeDelete();
         %ptA.edge = point.clone(true);
         
         %ptA.edge.setSize(%EDGE_LEN, 1);
         %ptA.edge.setBlendColor(0, 128, 255, 255);
         
         %edgeNormalized = t2dVectorNormalise(%vectorEdge);
         %centerPos = t2dVectorScale(%edgeNormalized, -%EDGE_LEN/2);      
         %ptA.edge.setPosition(t2dVectorAdd(%ptA.getPosition(), %centerPos));
         
         %angle = calculateAngle(%ptA.getPositionX(), %ptA.getPositionY(), %ptB.getPositionX(), %ptB.getPositionY());
         %ptA.edge.setRotation(%angle);
         
         
         attachToPoly(%this, %ptA);
         attachToPoly(%this, %ptA.edge);
         
         /////////////////////////////////
   }
}

function MovePoly::projectAxis(%this, %CHECK_POLY) {
      %VERTICES = %this.noOfVertices;
      %ALL_AXIS_COLLIDING = true;
      for(%i = 0; %i < %VERTICES; %i++) {
         %ptA = %this@"_VERTEX_"@%i;
         %ptB = %this@"_VERTEX_"@%i+1;
         
         if(%i == %VERTICES - 1) {
            %ptB = %this@"_VERTEX_0";
         }
      
         %vectorEdge = t2dVectorSub(%ptA.getPosition(), %ptB.getPosition());
         %edgeNormalized = t2dVectorNormalise(%vectorEdge);         
         %angle = calculateAngle(%ptA.getPositionX(), %ptA.getPositionY(), %ptB.getPositionX(), %ptB.getPositionY());

         %EDGE_LEN = t2dVectorDistance(%ptA.getPosition(), %ptB.getPosition());
                  
         //Axis Drawing...
         //%LHNormal = -getWord(%vectorEdge, 1) SPC getWord(%vectorEdge, 0);//LeftHandNormal
         //%RHNormal = getWord(%vectorEdge, 1) SPC -getWord(%vectorEdge, 0);//RightHandNormal
         
         //Aa, Draws a perpendicular to the edge from %ptA
         %LHNormal = getWord(%ptA.getPosition(), 0)-getWord(%vectorEdge, 1) SPC getWord(%ptA.getPosition(), 1)+getWord(%vectorEdge, 0);
         %RHNormal = getWord(%ptA.getPosition(), 0)+getWord(%vectorEdge, 1) SPC getWord(%ptA.getPosition(), 1)-getWord(%vectorEdge, 0);

         %axis = t2dVectorSub(%LHNormal, %RHNormal);
         %normalisedAxis = t2dVectorNormalise(%axis);
         
         if($debug) {
            //if(%i == 2) {
               ///*
                  if(!isObject(%ptA.axisPoint))
                     %ptA.axisPoint = point.clone(true);
                  %ptA.axisPoint.setSize(512, 1);
                  %ptA.axisPoint.setBlendColor(128, 0, 128, 255);
                  %ptA.axisPoint.setRotation(90+%angle);
                  %ptA.axisPoint.setPosition(%ptA.getPosition());
                  attachToPoly(%ptA, %ptA.axisPoint);
               //*/
                  
                  if(!isObject(%ptA.LNormal))
                     %ptA.LNormal = LNormal.clone(true);
                  %ptA.LNormal.setPosition(%LHNormal);
                  %ptA.LNormal.setBlendColor(255, 255, 0, 255);
                  attachToPoly(%ptA, %ptA.LNormal);
                  
                  if(!isObject(%ptA.RNormal))
                     %ptA.RNormal = RNormal.clone(true);
                  %ptA.RNormal.setPosition(%RHNormal);
                  %ptA.RNormal.setBlendColor(255, 255, 0, 255);
                  attachToPoly(%ptA, %ptA.RNormal);
            //}
         }
                  %this.MY_LIMITS = %this.projectVertices(%this, %LHNormal, %normalisedAxis, 0);
                  %this.HIS_LIMITS = %this.projectVertices(%CHECK_POLY, %LHNormal, %normalisedAxis, 1);
                  
                  //echo(%this.MY_LIMITS@" %DOTPROD == "@%this.HIS_LIMITS);
                  
                  %myMin = getWord(%this.MY_LIMITS, 0);
                  %myMax = getWord(%this.MY_LIMITS, 1);
                  %hisMin = getWord(%this.HIS_LIMITS, 0);
                  %hisMax = getWord(%this.HIS_LIMITS, 1);


                  if(   (%hisMin >= %myMin && %hisMin <= %myMax)
                        ||
                        (%hisMax >= %myMin && %hisMax <= %myMax)
                        ||
                        (%myMin >= %hisMin && %myMin <= %hisMax)
                        ||
                        (%myMax >= %hisMin && %myMax <= %hisMax)
                  ) {
                        %ALL_AXIS_COLLIDING = true;
                  }
                  else {
                        %ALL_AXIS_COLLIDING = false;
                        break;
                  }
                  
                  //echo("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% "@%ALL_AXIS_COLLIDING);

   }
   
   //echo("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& "@%ALL_AXIS_COLLIDING);
   return %ALL_AXIS_COLLIDING;
}

function MovePoly::projectVertices(%this, %POLYGON, %LHNormal, %normalisedAxis, %isMyVerticesProjection) {
      %VERTICES = %POLYGON.noOfVertices;
      %minProd = %maxProd = 0;
      
      for(%i = 0; %i < %VERTICES; %i++) {
         %VERTEX = %POLYGON@"_VERTEX_"@%i;
         
         %vectB = t2dVectorSub(%LHNormal, %VERTEX.getPosition());
         %DOTPROD = t2dVectorDot(%normalisedAxis, %vectB);
   
         %projB = getWord(%normalisedAxis, 0)*%DOTPROD SPC getWord(%normalisedAxis, 1)*%DOTPROD;
         if($debug) {
            ///*
            %projB_Point = point.clone(true);
            %projB_Point.setPosition(t2dVectorSub(%LHNormal, %projB));
            
            if(%isMyVerticesProjection)
               %projB_Point.setBlendColor(128, 0, 128, 255);
            else
               %projB_Point.setBlendColor(0, 255, 255, 255);
               
            attachToPoly(%POLYGON, %projB_Point);
            //*/
         }
         if(%i == 0) {
            %minProd = %maxProd = %DOTPROD;
         }
         echo(%minProd@" "@%maxProd@" ___________________________ "@%DOTPROD);
         if(%DOTPROD < %minProd)
            %minProd = %DOTPROD;
         else 
         if(%DOTPROD > %maxProd)
            %maxProd = %DOTPROD;
      }
      
      return (%minProd SPC %maxProd);
      
}

function attachToPoly(%parent, %obj) {
      if(!%obj.getIsMounted()) {
         %localPointVertex = %parent.getLocalPoint(%obj.getPosition());
         %obj.mount(%parent, getWord(%localPointVertex, 0), getWord(%localPointVertex, 1));
      }
}

function MovePoly::projectCircle(%this, %CIRCLE) {
      %VERTICES = %this.noOfVertices;
      %ALL_AXIS_COLLIDING = true;
      for(%i = 0; %i < %VERTICES; %i++) {
         %ptA = %this@"_VERTEX_"@%i;
         %ptB = %this@"_VERTEX_"@%i+1;
         
         if(%i == %VERTICES - 1) {
            %ptB = %this@"_VERTEX_0";
         }
      
         %vectorEdge = t2dVectorSub(%ptA.getPosition(), %ptB.getPosition());
         //%edgeNormalized = t2dVectorNormalise(%vectorEdge);         
         %angle = calculateAngle(%ptA.getPositionX(), %ptA.getPositionY(), %ptB.getPositionX(), %ptB.getPositionY());

         %EDGE_LEN = t2dVectorDistance(%ptA.getPosition(), %ptB.getPosition());
                  
         //Axis Drawing...
         //%LHNormal = -getWord(%vectorEdge, 1) SPC getWord(%vectorEdge, 0);//LeftHandNormal
         //%RHNormal = getWord(%vectorEdge, 1) SPC -getWord(%vectorEdge, 0);//RightHandNormal
         
         //Aa, Draws a perpendicular to the edge from %ptA
         %LHNormal = getWord(%ptA.getPosition(), 0)-getWord(%vectorEdge, 1) SPC getWord(%ptA.getPosition(), 1)+getWord(%vectorEdge, 0);
         %RHNormal = getWord(%ptA.getPosition(), 0)+getWord(%vectorEdge, 1) SPC getWord(%ptA.getPosition(), 1)-getWord(%vectorEdge, 0);

         %axis = t2dVectorSub(%LHNormal, %RHNormal);
         %normalisedAxis = t2dVectorNormalise(%axis);
         
         if($debug) {
            //if(%i == 2) {
               ///*
                  if(!isObject(%ptA.axisPoint))
                     %ptA.axisPoint = point.clone(true);
                  %ptA.axisPoint.setSize(512, 1);
                  %ptA.axisPoint.setBlendColor(128, 0, 128, 255);
                  %ptA.axisPoint.setRotation(90+%angle);
                  %ptA.axisPoint.setPosition(%ptA.getPosition());
                  attachToPoly(%ptA, %ptA.axisPoint);
               //*/
                  
                  if(!isObject(%ptA.LNormal))
                     %ptA.LNormal = LNormal.clone(true);
                  %ptA.LNormal.setPosition(%LHNormal);
                  %ptA.LNormal.setBlendColor(255, 255, 0, 255);
                  attachToPoly(%ptA, %ptA.LNormal);
                  
                  if(!isObject(%ptA.RNormal))
                     %ptA.RNormal = RNormal.clone(true);
                  %ptA.RNormal.setPosition(%RHNormal);
                  %ptA.RNormal.setBlendColor(255, 255, 0, 255);
                  attachToPoly(%ptA, %ptA.RNormal);
            //}
         }
         
         ////////////////////////////////////////////////////////////////////
         /////// VERTEX to CIRCLE center Axis
//if(%i == 0) {
         %vectorAxis = t2dVectorSub(%ptA.getPosition(), %CIRCLE.getPosition());
         %normalisedVectorAxis = t2dVectorNormalise(%vectorAxis);
         %angle = calculateAngle(%ptA.getPositionX(), %ptA.getPositionY(), %CIRCLE.getPositionX(), %CIRCLE.getPositionY());
         
         %AXIS_LEN = t2dVectorDistance(%ptA.getPosition(), %CIRCLE.getPosition());
            
         if($debug) {
                  if(!isObject(%ptA.axisPointCircle))
                     %ptA.axisPointCircle = point.clone(true);
                  %ptA.axisPointCircle.setSize(512, 1);
                  %ptA.axisPointCircle.setBlendColor(0, 128, 0, 255);
                  %ptA.axisPointCircle.setRotation(%angle);
                  %ptA.axisPointCircle.setPosition(%ptA.getPosition());
                  attachToPoly(%ptA, %ptA.axisPointCircle);
         }

         %this.MY_LIMITS = %this.projectVertices(%this, %ptA.getPosition(), %normalisedAxis, 0);
         %this.HIS_LIMITS = %this.projectCircleOnEdge(%CIRCLE, %angle, %ptA.getPosition(), %normalisedAxis, 1);
///*
                  %myMin = getWord(%this.MY_LIMITS, 0);
                  %myMax = getWord(%this.MY_LIMITS, 1);
                  %hisMin = getWord(%this.HIS_LIMITS, 0);
                  %hisMax = getWord(%this.HIS_LIMITS, 1);


                  if(   (%hisMin >= %myMin && %hisMin <= %myMax)
                        ||
                        (%hisMax >= %myMin && %hisMax <= %myMax)
                        ||
                        (%myMin >= %hisMin && %myMin <= %hisMax)
                        ||
                        (%myMax >= %hisMin && %myMax <= %hisMax)
                  ) {
                        %ALL_AXIS_COLLIDING = true;
                        if(%i == 0)
                        %ALL_AXIS_COLLIDING = %this.projectCircleEdges(%CIRCLE, %angle, %LHNormal, %normalisedVectorAxis, 1);
                        if(!%ALL_AXIS_COLLIDING)
                           break;
               echo(%ALL_AXIS_COLLIDING@" *********** ");

                  }
                  else {
                        %ALL_AXIS_COLLIDING = false;
                        break;
                  }         
//*/
            
                  
//}
         ////////////////////////////////////////////////////////////////////
         
         
         
      }
      
      return %ALL_AXIS_COLLIDING;
}

function MovePoly::projectCircleOnEdge(%this, %CIRCLE, %angle, %LHNormal, %normalisedAxis, %isMyVerticesProjection) {
      %RADII = %CIRCLE.getWidth()/2;
      
      %VERTICES = 2;
      %minProd = %maxProd = 0;
      
      %atRADII = t2dVectorScale(%normalisedAxis, -%RADII);
      %PROJ_POINT = t2dVectorAdd(%atRADII, %CIRCLE.getPosition());
      %vectB = t2dVectorSub(%LHNormal, %PROJ_POINT);
      %DOTPROD_0 = t2dVectorDot(%normalisedAxis, %vectB);
      %projB = getWord(%normalisedAxis, 0)*%DOTPROD_0 SPC getWord(%normalisedAxis, 1)*%DOTPROD_0;
   //echo(%LHNormal@" %normalisedAxis == "@%normalisedAxis@" "@%PROJ_POINT@" "@%CIRCLE.getPosition()@" %DOTPROD == "@%DOTPROD);
      if($debug) {
         %projB_Point = point.clone(true);
         %projB_Point.setBlendColor(255, 0, 0, 255);
         %projB_Point.setPosition(t2dVectorSub(%LHNormal, %projB));
      }
      
      %atRADII = t2dVectorScale(%normalisedAxis, %RADII);
      %PROJ_POINT = t2dVectorAdd(%atRADII, %CIRCLE.getPosition());
      %vectB = t2dVectorSub(%LHNormal, %PROJ_POINT);
      %DOTPROD_1 = t2dVectorDot(%normalisedAxis, %vectB);
      %projB = getWord(%normalisedAxis, 0)*%DOTPROD_1 SPC getWord(%normalisedAxis, 1)*%DOTPROD_1;
   //echo(%LHNormal@" %normalisedAxis == "@%normalisedAxis@" "@%PROJ_POINT@" "@%CIRCLE.getPosition()@" %DOTPROD == "@%DOTPROD);

      if($debug) {
         %projB_Point = point.clone(true);
         %projB_Point.setBlendColor(255, 0, 0, 255);
         %projB_Point.setPosition(t2dVectorSub(%LHNormal, %projB));
      }

      if(%DOTPROD_0 < %DOTPROD_1)
         return %DOTPROD_0 SPC %DOTPROD_1;
      else 
         return %DOTPROD_1 SPC %DOTPROD_0;
}

function MovePoly::projectCircleEdges(%this, %CIRCLE, %angle, %LHNormal, %normalisedVectorAxis, %isMyVerticesProjection) {
      %RADII = %CIRCLE.getWidth()/2;
      
      %VERTICES = %this.noOfVertices;
      %minProd = %maxProd = 0;
      
      %atRADIIMin = t2dVectorScale(%normalisedVectorAxis, -%RADII);
      %atRADIIMax = t2dVectorScale(%normalisedVectorAxis, %RADII);

%vectB = t2dVectorAdd(%atRADIIMin, %CIRCLE.getPosition());
%hisMin = %myMin = t2dVectorDot(%normalisedVectorAxis, %vectB);
%vectB = t2dVectorAdd(%atRADIIMax, %CIRCLE.getPosition());
%hisMax = %myMax = t2dVectorDot(%normalisedVectorAxis, %vectB);

      if($debug) {
         %dotRADII = point.clone(true);
         %dotRADII.setBlendColor(255, 0, 255, 255);
         %dotRADII.setPosition(t2dVectorAdd(%atRADIIMin, %CIRCLE.getPosition()));

         %dotRADII = point.clone(true);
         %dotRADII.setBlendColor(255, 0, 0, 255);
         %dotRADII.setPosition(t2dVectorAdd(%atRADIIMax, %CIRCLE.getPosition()));
      }

      for(%i = 0; %i < %VERTICES; %i++) {
         %VERTEX = %this@"_VERTEX_"@%i;
//if(%i == 0) {
   echo("%VERTEX == "@%VERTEX.getPosition());
         %vectB = t2dVectorSub(%VERTEX.getPosition(), %CIRCLE.getPosition());
         %DOTPROD = t2dVectorDot(%normalisedVectorAxis, %vectB);
         
         if($debug) {
            %vertexProj = getWord(%normalisedVectorAxis, 0)*%DOTPROD SPC getWord(%normalisedVectorAxis, 1)*%DOTPROD;
            %vertexProjDot = point.clone(true);
            %vertexProjDot.setBlendColor(255, 0, 0, 255);
            %vertexProjDot.setPosition(t2dVectorAdd(%vertexProj, %CIRCLE.getPosition()));
         }
//}

         if(%DOTPROD < %hisMin)
            %hisMin = %DOTPROD;
         else 
         if(%DOTPROD > %hisMax)
            %hisMax = %DOTPROD;
            
      }

echo(%myMin@" == "@%myMax@" *** "@%hisMin@" == "@%hisMax);
      if(   (%hisMin >= %myMin && %hisMin <= %myMax)
            ||
            (%hisMax >= %myMin && %hisMax <= %myMax)
            ||
            (%myMin >= %hisMin && %myMin <= %hisMax)
            ||
            (%myMax >= %hisMin && %myMax <= %hisMax)
      ) {
            %ALL_AXIS_COLLIDING = true;
      }
      else {
            %ALL_AXIS_COLLIDING = false;
      }
                  
      echo("%ALL_AXIS_COLLIDING =================== "@%ALL_AXIS_COLLIDING);

      return (%ALL_AXIS_COLLIDING);
      
}