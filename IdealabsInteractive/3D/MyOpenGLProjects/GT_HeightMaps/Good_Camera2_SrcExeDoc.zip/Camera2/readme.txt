Advanved CodeColony Camera 
==========================

Keys to use:

w : forwards
s : backwards
a : turn left
d : turn right
x : turn up
y : turn down
v : strafe right
c : strafe left
r : move up
f : move down
m/n : roll


Enjoy!

Philipp Crocoll, March 2003