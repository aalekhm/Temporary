/* material.h */

#include "types.h"

void setup_material_file (char *);
void close_material_file (void);

void write_material (Material *);
