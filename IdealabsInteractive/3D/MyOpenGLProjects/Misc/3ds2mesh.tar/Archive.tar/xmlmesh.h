/* xmlmesh.h */

#include "types.h"

void setup_mesh_file (char *);
void close_mesh_file (void);

void write_mesh (Mesh *);
