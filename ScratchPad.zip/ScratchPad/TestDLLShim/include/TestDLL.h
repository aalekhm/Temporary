#pragma once
#include <Windows.h>
#include <tchar.h>

#ifdef TESTDLL_EXPORTS
#define TESTDLL_EXPORTS_API __declspec(dllexport)
#else
#define TESTDLL_EXPORTS_API __declspec(dllimport)
#endif

extern "C" int TestFunction(int iInput);
extern "C" int AnotherTestFunction(int iInput);