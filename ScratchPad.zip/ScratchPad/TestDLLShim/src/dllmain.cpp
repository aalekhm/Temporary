// dllmain.cpp : Defines the entry point for the DLL application.
#include <Windows.h>
#include <tchar.h>
#include <iostream>
#include "TestDLL.h"

/*
1    0 00011050 AnotherTestFunction = @ILT + 75(AnotherTestFunction)
2    1 000110B9 TestFunction = @ILT + 180(TestFunction)
*/

#pragma comment(linker, "/export:AnotherTestFunction=Shim_AnotherTestFunction,@1")
#pragma comment(linker, "/export:TestFunction=Shim_TestFunction,@2")

struct FunctionTable
{
    void*   AnotherTestFunction;
    void*   TestFunction;
};

static FunctionTable    funcTable;
static HMODULE          system_dll;

extern "C"
{
    int Shim_AnotherTestFunction(int iInput)
    {
        OutputDebugStringW(L"Shim_AnotherTestFunction Called__!");
        std::cout << "Shim_AnotherTestFunction Called__!" << std::endl;
        int iRetVal = reinterpret_cast<decltype(&AnotherTestFunction)>(funcTable.AnotherTestFunction)(iInput);

        return iRetVal;
    }

    int Shim_TestFunction(int iInput)
    {
        OutputDebugStringW(L"Shim_TestFunction Called__!");
        std::cout << "Shim_TestFunction Called__!" << std::endl;
        int iRetVal = reinterpret_cast<decltype(&TestFunction)>(funcTable.TestFunction)(iInput + 1);

        return iRetVal;
    }
}

static void Initialize()
{
    std::cout << "Initialize!" << std::endl;
    system_dll = LoadLibraryA("C:\\Windows\\System32\\TestDLL.dll");
    if (system_dll)
    {
        std::cout << "Initialize 1!" << std::endl;
        funcTable.AnotherTestFunction   = reinterpret_cast<decltype(&AnotherTestFunction)>(GetProcAddress(system_dll, "AnotherTestFunction"));
        funcTable.TestFunction          = reinterpret_cast<decltype(&TestFunction)>(GetProcAddress(system_dll, "TestFunction"));

        std::cout << "Initialize 2!" << std::endl;
    }
}

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
                     )
{
    switch (ul_reason_for_call)
    {
        case DLL_PROCESS_ATTACH:
        {
            std::cout << "Test DLL Shim Loaded!" << std::endl;
            OutputDebugStringW(L"Test DLL Shim Loaded!");
            Initialize();
        }
        break;
        case DLL_THREAD_ATTACH:
        case DLL_THREAD_DETACH:
        break;
        case DLL_PROCESS_DETACH:
        {
            std::cout << "Test DLL Shim UnLoaded!" << std::endl;
            OutputDebugStringW(L"Test DLL Shim UnLoaded!");
        }
        break;
    }

    return TRUE;
}

