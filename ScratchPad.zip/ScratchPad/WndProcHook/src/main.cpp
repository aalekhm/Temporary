// wndproc_hook.cpp
// Build as a DLL. When injected into a process, it subclasses the first
// top-level window owned by the process and logs key messages.
//
// Compile: Visual Studio -> create DLL project and add this file.
// Make sure runtime library / character set match your project settings.

#include <windows.h>
#include <stdio.h>
#include <tchar.h>

static WNDPROC g_originalWndProc = nullptr;
static HWND    g_hookedWnd = nullptr;
static HANDLE  g_logFile = INVALID_HANDLE_VALUE;
static CRITICAL_SECTION g_logLock;
static volatile LONG g_installed = 0; // 0 = not installed, 1 = installed

// Helper: append a UTF-8 string to temp log file and OutputDebugString
static void LogMessage(const char* fmt, ...)
{
    char buf[1024];
    va_list ap;
    va_start(ap, fmt);
    int n = vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    if (n < 0) buf[0] = '\0';
    buf[sizeof(buf) - 1] = '\0';

    // OutputDebugString (useful with DebugView)
    OutputDebugStringA("[UEInputHook] ");
    OutputDebugStringA(buf);
    OutputDebugStringA("\n");

    // Append to file (thread-safe)
    EnterCriticalSection(&g_logLock);
    if (g_logFile != INVALID_HANDLE_VALUE) {
        DWORD written = 0;
        // write utf-8 bytes then newline
        WriteFile(g_logFile, buf, (DWORD)strlen(buf), &written, NULL);
        WriteFile(g_logFile, "\r\n", 2, &written, NULL);
        FlushFileBuffers(g_logFile);
    }
    LeaveCriticalSection(&g_logLock);
}

// Find first top-level visible window that belongs to current process
static BOOL CALLBACK EnumProc_FindMyWindow(HWND hwnd, LPARAM lParam)
{
    DWORD pid = 0;
    GetWindowThreadProcessId(hwnd, &pid);
    if (pid != GetCurrentProcessId()) return TRUE; // continue

    // skip invisible or child windows
    if (!IsWindowVisible(hwnd)) return TRUE;
    if (GetWindow(hwnd, GW_OWNER) != NULL) return TRUE;

    // candidate found
    *((HWND*)lParam) = hwnd;
    return FALSE; // stop enumeration
}

static HWND FindMainWindowForCurrentProcess()
{
    HWND hwnd = NULL;
    EnumWindows(EnumProc_FindMyWindow, (LPARAM)&hwnd);
    return hwnd;
}

// Our hooked window proc
LRESULT CALLBACK HookedWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch (uMsg) {
    case WM_KEYDOWN:
    case WM_SYSKEYDOWN: {
        int vk = (int)wParam;
        LogMessage("WM_KEYDOWN: VK=0x%02X (%d)", vk, vk);
        break;
    }
    case WM_KEYUP:
    case WM_SYSKEYUP: {
        int vk = (int)wParam;
        LogMessage("WM_KEYUP: VK=0x%02X (%d)", vk, vk);
        break;
    }
    case WM_CHAR: {
        char ch = (char)wParam;
        LogMessage("WM_CHAR: '%c' (0x%02X)", (ch >= 32 && ch < 127) ? ch : '?', (unsigned)wParam);
        break;
    }
    default:
        break;
    }

    // Forward to original WndProc
    if (g_originalWndProc) {
        return CallWindowProc(g_originalWndProc, hWnd, uMsg, wParam, lParam);
    }
    else {
        return DefWindowProc(hWnd, uMsg, wParam, lParam);
    }
}

// Install subclass on the main window
static bool InstallHook()
{
    if (InterlockedCompareExchange(&g_installed, 1, 0) != 0) {
        // already installed
        return true;
    }

    InitializeCriticalSection(&g_logLock);

    // Open log file in temp
    char tempPath[MAX_PATH];
    char logPath[MAX_PATH];
    if (GetTempPathA(MAX_PATH, tempPath) == 0) {
        strcpy_s(tempPath, "C:\\");
    }
    sprintf_s(logPath, "%sue_keylog.txt", tempPath);
    g_logFile = CreateFileA(logPath, GENERIC_WRITE | GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (g_logFile != INVALID_HANDLE_VALUE) {
        // move pointer to end for append
        SetFilePointer(g_logFile, 0, NULL, FILE_END);
    }

    HWND hwnd = FindMainWindowForCurrentProcess();
    if (!hwnd) {
        LogMessage("InstallHook: Failed to find main window for this process");
        // still keep installed flag so we don't retry continuously
        return false;
    }

    // subclass the window
    g_hookedWnd = hwnd;
    // store original WndProc
    g_originalWndProc = (WNDPROC)SetWindowLongPtr(hwnd, GWLP_WNDPROC, (LONG_PTR)HookedWndProc);
    if (!g_originalWndProc) {
        DWORD err = GetLastError();
        LogMessage("InstallHook: SetWindowLongPtr failed err=%u", (unsigned)err);
        return false;
    }

    LogMessage("InstallHook: Subclassed window 0x%p, original WndProc=0x%p, log=%s", hwnd, g_originalWndProc, logPath);
    return true;
}

// Remove subclass and cleanup
static void UninstallHook()
{
    if (InterlockedCompareExchange(&g_installed, 0, 1) != 1) {
        return; // not installed
    }

    if (g_hookedWnd && g_originalWndProc) {
        // restore original
        SetWindowLongPtr(g_hookedWnd, GWLP_WNDPROC, (LONG_PTR)g_originalWndProc);
        LogMessage("UninstallHook: restored original WndProc");
    }

    if (g_logFile != INVALID_HANDLE_VALUE) {
        CloseHandle(g_logFile);
        g_logFile = INVALID_HANDLE_VALUE;
    }

    DeleteCriticalSection(&g_logLock);
}

// Thread to wait until window exists and then install subclass
static DWORD WINAPI InstallThread(LPVOID)
{
    // try for a few seconds to find a window
    const int maxAttempts = 60;
    for (int i = 0; i < maxAttempts; ++i) {
        if (FindMainWindowForCurrentProcess()) break;
        Sleep(200);
    }

    // Attempt to install (may fail if window not found)
    InstallHook();
    return 0;
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD reason, LPVOID reserved)
{
    switch (reason) {
    case DLL_PROCESS_ATTACH:
        // spawn a thread to install hook so we don't block DllMain work
        DisableThreadLibraryCalls(hModule);
        CreateThread(NULL, 0, InstallThread, NULL, 0, NULL);
        break;
    case DLL_PROCESS_DETACH:
        UninstallHook();
        break;
    }
    return TRUE;
}
