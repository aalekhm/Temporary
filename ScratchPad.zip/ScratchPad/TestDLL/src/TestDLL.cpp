#include "TestDLL.h"
#include <iostream>

extern "C" TESTDLL_EXPORTS_API int TestFunction(int iInput)
{
	TCHAR sOutString[255];
	_stprintf_s(sOutString, L"TestFunction(%d) called!", iInput);

	OutputDebugStringW(sOutString);
	std::cout << "Original TestFunction called!" << std::endl;

	return 2 * iInput;
}

extern "C" TESTDLL_EXPORTS_API int AnotherTestFunction(int iInput)
{
	TCHAR sOutString[255];
	_stprintf_s(sOutString, L"AnotherTestFunction(%d) called!", iInput);

	OutputDebugStringW(sOutString);
	std::cout << "Original AnotherTestFunction called!" << std::endl;

	return 3 * iInput;
}