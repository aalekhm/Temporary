#include <iostream>
#include <utility>
#include "Network/NetDefines.h"
#include "Network/NetServer.h"
#include "Buffer/BufferData.hpp"
#include "QRCode/QrCode.hpp"

using namespace qrcodegen;

NetServer		g_NetServer;

#pragma pack(1)
struct SHeader
{
	int32_t		m_iSize;
};

int main()
{
	// Simple operation
	QrCode qr0 = QrCode::encodeText("Hello, world!", QrCode::Ecc::MEDIUM);
	for (int y = 0; y < qr0.getSize(); y++) 
	{
		for (int x = 0; x < qr0.getSize(); x++) 
		{
			bool bQRModule = qr0.getModule(x, y);
			std::cout << "" << (bQRModule ? '.' : ',');
		}
		std::cout << "\n";
	}

	auto& iIPAddress	= g_NetServer.m_iIPAddress;
	auto& iPort			= g_NetServer.m_iPort;

	NetBase::getDynamicIPAddress(iIPAddress);
	iPort = PORT;

	if (g_NetServer.netInitialize())
	{
		if (g_NetServer.netListen(iIPAddress, iPort, 1))
		{
			while (1)
			{
				SHeader HEADER;
				BufferData DATA;

				// Header
				g_NetServer.netRecvAll(&HEADER, sizeof(SHeader));

				// Data
				{
					DATA.setSize(HEADER.m_iSize + 1);
					g_NetServer.netRecvAll(DATA.m_pBuffer, HEADER.m_iSize);

					DATA.m_pBuffer[HEADER.m_iSize] = '\0';
				}

				LOG_CONSOLE("DATA = " << DATA.m_pBuffer);
			}
		}
	}

    return 0;
}