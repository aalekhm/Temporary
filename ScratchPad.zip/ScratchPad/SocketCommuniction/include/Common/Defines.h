#pragma once

#include <stdint.h>
#include <stdlib.h>
#include <iostream>
#include <sstream>
#include <assert.h>

#define NOT !

#define ASSERT(__message__, __iReturnValue__) \
std::cout << ##__message__ << __iReturnValue__ << std::endl; \
assert(__iReturnValue__ > 0);

#define LOG_TAG "[C++]"
#define LOG_CONSOLE(__string__) std::cout << LOG_TAG << " " << __string__ << "\n";

// Object deletion macro
#define SAFE_DELETE(x) if(x != NULL) { delete x; x = NULL; }

// Array deletion macro
#define SAFE_DELETE_ARRAY(x) if(x != NULL) { delete[] x; x = NULL; }

// Ref cleanup macro
#define SAFE_RELEASE(x)	if(x != NULL) { (x)->release(); x = NULL; }