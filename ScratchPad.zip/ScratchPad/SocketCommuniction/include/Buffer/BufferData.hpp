#pragma once
#include "Common/Defines.h"

class BufferData
{
	public:
		BufferData()
		: m_iBufferSize(-1)
		, m_pBuffer(nullptr)
		{ }

		BufferData(size_t iBufferSize)
		{
			setSize(iBufferSize);
		}

		void setSize(size_t iBufferSize)
		{
			m_iBufferSize = iBufferSize;
			m_pBuffer = (uint8_t*)std::malloc(iBufferSize);
			memset(m_pBuffer, 0, m_iBufferSize);
		}

		virtual ~BufferData()
		{
			if (m_pBuffer != nullptr)
			{
				std::free(m_pBuffer);
			}
		}

		uint8_t*		m_pBuffer;
		size_t			m_iBufferSize;
	protected:
	private:
};
