#pragma once
#include "Common/Defines.h"

class BufferedStream
{
	public:
	protected:
	private:
};