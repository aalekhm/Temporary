#include <iostream>
#include <utility>
#include <mutex>

#define MOVE_VS_FORWARD
#ifdef MOVE_VS_FORWARD
void Show(int&&)
{
    std::cout << "int&& called" << std::endl;
}

void Show(int&)
{
    std::cout << "int& called" << std::endl;
}

template<typename T>
void Foo(T&& x)
{
    std::cout << "straight: ";
    Show(x);                    // Things that are declared as rvalue reference can be lvalues or rvalues. 
                                // The distinguishing criterion is: if it has a name, then it is an lvalue. Otherwise, it is an rvalue.
                                // Hence, 'x' inside Foo() when called with '10' is an lvalue

    std::cout << "move: ";
    Show(std::move(x));

    std::cout << "forward: ";
    Show(std::forward<T>(x));

    std::cout << std::endl;
}
#endif

class CTemp
{
    public:
        void setInt(int i) const
        {
            //m_iInt = i;
        }
    protected:
    private:
        int m_iInt;
};

void someFunc(const CTemp& pTemp)
{
    pTemp.setInt(10);
}

void someFunc_(CTemp& pTemp)
{

    pTemp.setInt(10);
}

#if !_DEBUG
#define DATA_TYPE(__dataType__) __dataType__
#else
#define DATA_TYPE(__dataType__) auto
#endif

int main0()
{
#ifdef MOVE_VS_FORWARD
    Foo(10);    // Things that are declared as rvalue reference can be lvalues or rvalues. 
                // The distinguishing criterion is: if it has a name, then it is an lvalue. Otherwise, it is an rvalue.
                // Hence, 'x' inside Foo() when called with '10' is an lvalue

    int x = 10;
    Foo(x);
#endif

    DATA_TYPE(int32_t) i = 10;
    

    return 0;
}

////////////////////////////////////////////////////////////////
/// <summary>
/// RAII - Resource Acquisition Is Initialization
/// </summary>
class Lock
{
    public:
        explicit Lock(std::mutex* mu)
        {
           mu->lock();
           m_pMutex = mu;
        }

        Lock(const Lock& pOther) = delete;
        Lock& operator=(const Lock& pOther) = delete;

        Lock(Lock&& pOther) noexcept
        {
            if (pOther.m_pMutex != nullptr)
            {
                m_pMutex = pOther.m_pMutex;
                pOther.m_pMutex = nullptr;
            }
        }

        Lock& operator=(Lock&& pOther) noexcept
        {
            if (pOther.m_pMutex != nullptr)
            {
                m_pMutex = pOther.m_pMutex;
                pOther.m_pMutex = nullptr;
            }
        }

        ~Lock()
        {
            if (m_pMutex != nullptr)
            {
                m_pMutex->unlock();
            }
        }
    private:
        std::mutex* m_pMutex;
};

int main()
{
    std::mutex mu;
    {
        Lock lock(&mu);

        // Disallow 'Copy Construction' & 'Copy Assignment'
        //Lock lock1 = lock;
        //lock1 = lock

        Lock lockMoved(std::move(lock));
    }

    return 0;
}
////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////
/// <summary>
/// Overloading 'new' & 'delete'
/// </summary>

class Test
{
    public:
        int32_t m_iMember = 0;
        Test()
        {

        }

        ~Test()
        {

        }

        void* operator new(size_t iSize)
        {
            void* pTest = malloc(iSize);

            return pTest;
        }

        void* operator new[](size_t iSize)
        {
            void* pTest = malloc(iSize);

            return pTest;
        }

        void operator delete(void* pTest)
        {
            free(pTest);
        }

        void operator delete[](void* pTest)
        {
            free(pTest);
        }
};

int main2()
{
    {
        Test* pTest = new Test();
        Test* pTest1 = new Test[5];

        delete(pTest);
        delete[](pTest1);
    }

    return 0;
}
////////////////////////////////////////////////////////////////