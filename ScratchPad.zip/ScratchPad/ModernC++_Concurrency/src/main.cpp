#include <iostream>
#include <fstream>
#include <thread>
#include <mutex>
#include <deque>
#include <future>
#include <string>

using namespace std::chrono_literals;

// Process:
//	Pros:
//		-	Slow & complicated to start a process.
//		-	As OS has to devote bunch of resources to start it.
//		-	Can be easily run on a Distributed systems.
//	Cons:
//		-Has more overhead, as OS has to provide  lot of protection.
//			so that 1 process will not accidently step on to another process.
//		-	Communication happens through inter process communication channels, which is a slower.

// Threads:
//	Pros:
//		-	Easy to start.
//		-	Light weight process. Low overhead
//		-	Communication happens through shared memory, which is a lot faster.
//		-	Provies better performance than multiprocessing.
//		-	
//	Cons:
//		-	Difficult to implement, as there are a bunch of multithreading issues
//			which neds to be carefullly handled.
//		-	Can't be run on a Distributed system. (To make it run on multiple system, threads
//			should communicate via some kind of another channel rather than shared memory).

#define STD_THREAD									1
#define STD_MUTEX									0
#define STD_LOCK_GUARD								0
#define STD_UNIQUE_GUARD							0
#define STD_ONCE_FLAG								0
#define STD_CONDITION_VARIABLE						0
#define STD_ASYNC_FUTURE							0
#define STD_ASYNC_FUTURE_2							0
#define STD_ASYNC_FUTURE_PROMISE					0
#define STD_ASYNC_FUTURE_PROMISE_2					0
#define STD_ASYNC_FUTURE_PROMISE_SHAREDFUTURE		0
#define STD_PACKAGED_TASK_1							0
#define STD_PACKAGED_TASK_2							0

#if STD_THREAD == 1

	/* std::thread */
	class Functor
	{
		public:
			void operator()() { std::cout << "Functor()" << std::endl; }
	};
		
	int getValue(int i) { std::cout << "function()" << std::endl; return i; }
		
	int main()
	{
		// 0.
		std::thread t1(getValue, 6);

		// 1.
		std::thread t2( (Functor()) );
		
		// 2.
		std::thread t3([](int i) 
		{
			std::cout << "[](){...} call" << std::endl;
		}, 7);
		
		t1.join();
		t2.join();
		t3.join();
		
		return 0;
	}

#elif STD_MUTEX == 1

	/* std::mutex */
	std::mutex _mu;
		
	int getValue(int i)
	{
		_mu.lock();
		std::cout << i << std::endl;
		_mu.unlock();

		return i;
	}
		
	int main()
	{
		std::thread t1(getValue, 6);
		t1.join();
		
		return 0;
	}

#elif STD_LOCK_GUARD == 1

	/* std::lock_guard -	Coarse grained lock. type of RAII.
							Cannot be unlocked.
	*/
	std::mutex _mu;
		
	int getValue(int i)
	{
		std::lock_guard<std::mutex> guard(_mu);
		std::cout << i << std::endl;

		return i;
	}
		
	int main()
	{
		std::thread t1(getValue, 6);
		t1.join();
		
		return 0;
	}

#elif STD_UNIQUE_GUARD == 1

	/* std::unique_lock -	Fine grained lock 
							Use 'unique_lock', only if 
							locking/unlocking functionality is required frequently.
							Else use 'lock_guard' instead.
	*/

	std::mutex _mu;
		
	int getValue(int i)
	{
		std::unique_lock<std::mutex> ulock(_mu, std::defer_lock);
		// 'std::defer_lock' provides lazy initialization.

		// 0. using the std::cout resource.
		ulock.lock();
		std::cout << i << std::endl;
		ulock.unlock();

		// ... Do something else

		// 1. using the std::cout resource again.
		ulock.lock();
		std::cout << i << std::endl;
		ulock.unlock();

		return i;
	}
		
	int main()
	{
		std::thread t1(getValue, 6);
		t1.join();
		
		return 0;
	}

#elif STD_ONCE_FLAG == 1

	/* std::once_flag -	Call only once & is thread safe */
	class LogFile 
	{
		std::mutex			_mu;
		std::once_flag		_flag;
		std::ofstream		_ofstream;
	public:
		LogFile() {}

		void shared_print(std::string str) 
		{
			std::call_once(_flag, [&]() 
			{
				// File will be opened only once by one thread.
				_ofstream.open("log.txt");	
			});

			std::unique_lock<std::mutex> ulocker(_mu);
			_ofstream << str << std::endl;
		}
	};

	int main()
	{
		LogFile log;
		log.shared_print("Hello World!");

		return 0;
	}

#elif STD_CONDITION_VARIABLE == 1
	/* std::condition_variable */
	std::deque<int>				_queue;
	std::mutex					_mu;
	std::condition_variable		_cond;

	void producer()							// Keeps adding stuff to the queue.
	{
		int iCount = 10;
		while (iCount > 0)
		{
			std::unique_lock<std::mutex> ulocker(_mu);
			_queue.push_front(iCount);
			ulocker.unlock();

			_cond.notify_one();				// Notify one waiting thread, if there is one.
			// or
			_cond.notify_all();				// Notify all the waiting threads.

			std::this_thread::sleep_for(std::chrono::seconds(1));
			iCount--;
		}
	}

	void consumer()							// Keeps removing stuff from the queue.
	{
		int iData = 0;
		while (iData != 1)
		{
			std::unique_lock<std::mutex> ulocker(_mu);
			_cond.wait(ulocker);
			// or
			_cond.wait(ulocker, []() { return !_queue.empty(); }); // Spurious wake
			// If consumer thread wake up by itself, 'Spurious Wake', it will check the
			// predicate & act accordingly. If the condition is met, thread will continue running
			// else wait.

			iData = _queue.back();
			_queue.pop_back();
			ulocker.unlock();
			std::cout << "Consumer got value from Producer: " << iData << std::endl;
		}
	}

	int main()
	{
		std::thread t_Producer(producer);
		std::thread t_Consumer(consumer);

		t_Producer.join();
		t_Consumer.join();

		return 0;
	}

#elif STD_ASYNC_FUTURE == 1

	/* std::async, std::future - Passing value from the 'Child' thread to the 'Parent' thread */
	int factorial(int n)
	{
		int res = 1;
		for (int i = n; i > 1; i--)
		{
			res *= i;
		}

		return res;
	}

	int main()
	{
		std::future<int> fu = std::async(factorial, 7);		// 'async' is a high level api for creating a thread.
		int iResult = fu.get();									// 'future' can be 'got' once once.
																// 'fu.get' waits for the child thread to finish 
																// & then get the value from it.
		std::cout << "iResult = " << iResult << std::endl;


		std::future<int> fu_deferred = std::async(std::launch::deferred, factorial, 7);
		iResult = fu_deferred.get();							// Creation of thread is deferred until fu_deferred.get() is called.
		std::cout << "iResult = " << iResult << std::endl;

																// Immediately creates a thread & starts.
		std::future<int> fu_async = std::async(std::launch::async, factorial, 7);
		iResult = fu_async.get();
		std::cout << "iResult = " << iResult << std::endl;

																// Thread creation depends on the OS implementation. Default functionality.
		std::future<int> fu_async_Deferred = std::async(	std::launch::async
															|
															std::launch::deferred,
															factorial, 7);

		return 0;
	}

#elif STD_ASYNC_FUTURE_2 == 1

	/* std::async, std::future */
	std::mutex g_mutex;

	std::string f(const int n)
	{
		std::string n_string = std::to_string(n);

		g_mutex.lock();
		std::cout << "at start of thread " << std::this_thread::get_id()
				  << " that takes " << n_string << " seconds." << std::endl;
		g_mutex.unlock();

		std::this_thread::sleep_for(std::chrono::seconds(n));

		g_mutex.lock();
		std::cout << "at end of thread " << std::this_thread::get_id()
				  << " that took " << n_string << " seconds." << std::endl;
		g_mutex.unlock();

		return "Hello from " + n_string + ".";
	}

	int main()
	{
		std::vector<std::future<std::string>> futures;

		for (const auto& s : {1, 5})
		{
			futures.push_back(std::async(std::launch::async, f, s));
		}

		for (auto& f: futures)
		{
			const auto s = f.get();
			std::cout << s << std::endl;
		}
	}

#elif STD_ASYNC_FUTURE_PROMISE == 1

	/* std::async, std::future, std::promise - Passing value from the 'Parent' thread to the 'Child' thread */
	int factorial(std::future<int>& fuParam)
	{
		int res = 1;
		int n = fuParam.get();

		for (int i = n; i > 1; i--)
		{
			res *= i;
		}

		return res;
	}

	int main()
	{
		std::promise<int>	paramPromise;
		std::future<int>	paramFuture = paramPromise.get_future();

		std::future<int> fu_result = std::async(std::launch::async, factorial, std::ref(paramFuture));

		// ...
		// Do Something
		std::this_thread::sleep_for(std::chrono::milliseconds(100));
		paramPromise.set_value(7);

		int iResult = fu_result.get();
		std::cout << "iResult = " << iResult << std::endl;

		return 0;
	}

#elif STD_ASYNC_FUTURE_PROMISE_2 == 1

	/* std::async, std::future, std::promise */
	int Operation(std::promise<int>& dataPromise)
	{
		auto fu = dataPromise.get_future();
		std::cout << "Waiting for data" << std::endl;

		auto iCount = fu.get();
		std::cout << "Data available" << std::endl;

		int sum{};
		for (int i = 0; i < iCount; i++)
		{
			sum += i;

			std::cout << ".";
			std::this_thread::sleep_for(300ms);
		}

		return sum;
	}

	int main()
	{
		std::promise<int> dataPromise;
		std::future<int> fuResult = std::async(std::launch::async, Operation, std::ref(dataPromise));
		// Parameters to std::async are always passed by value, hence need to cast it via std::ref or std::cref if necessary

		std::this_thread::sleep_for(1s);

		dataPromise.set_value(10);

		if (fuResult.valid())
		{
			auto sum = fuResult.get();
			std::cout << "Sum = " << sum << std::endl;
		}

		return 0;
	}

#elif STD_ASYNC_FUTURE_PROMISE_SHAREDFUTURE == 1

	/* std::async, std::future, std::promise, std::shared_future - Broadcast kind of communication model */
	int factorial(std::shared_future<int> sfuParam)
	{
		int res = 1;
		int n = sfuParam.get();

		for (int i = n; i > 1; i--)
		{
			res *= i;
		}

		return res;
	}

	int main()
	{
		std::promise<int>		paramPromise;
		std::future<int>		paramFuture = paramPromise.get_future();
		std::shared_future<int>	paramSharedFuture = paramFuture.share();

		std::future<int> fu_result = std::async(std::launch::async, factorial, paramSharedFuture);
		std::future<int> fu_result1 = std::async(std::launch::async, factorial, paramSharedFuture);
		std::future<int> fu_result2 = std::async(std::launch::async, factorial, paramSharedFuture);
		std::future<int> fu_result3 = std::async(std::launch::async, factorial, paramSharedFuture);
		// ... 10 threads

		// ...
		// Do Something
		std::this_thread::sleep_for(std::chrono::milliseconds(100));
		paramPromise.set_value(7);

		int iResult = fu_result.get();
		std::cout << "iResult = " << iResult << std::endl;

		// ...

		return 0;
	}

#elif STD_PACKAGED_TASK_1 == 1

	/* packaged_task */
	int factorial(int N)
	{
		int res = 1;
		for (int i = N; i > 1; i--)
		{
			res *= i;
		}

		return res;
	}

	int main()
	{
		// 0.
		{
			std::packaged_task<int(int)> pt(factorial);

			// ...

			pt(7);										// Call packaged_task in a different context.
			int iResult = pt.get_future().get();		// Gets the return value.

			std::cout << "iResult = " << iResult << std::endl;
		}

		// 1.
		{
														// Pass in a function object created using 'std::bind'
			std::packaged_task<int()> pt(std::bind(factorial, 7));

			// ...

			pt();										// Call packaged_task without the parameter as its already bounded.
			int iResult = pt.get_future().get();		// Gets the return value.

			std::cout << "iResult = " << iResult << std::endl;
		}

		return 0;
	}

#elif STD_PACKAGED_TASK_2 == 1

	/* packaged_task */
	int factorial(int N)
	{
		int res = 1;
		for (int i = N; i > 1; i--)
		{
			res *= i;
		}

		return res;
	}

	std::deque<std::packaged_task<int()>>	_task_q;		// Since '_task_q' is a shared resource, we must make it thread safe.
	std::mutex								_mu;			// Hence use a 'mutex' to synchronize it.
	std::condition_variable					_cond;			// Use the 'condition_variable' to notify about the condition.

	void thread_1()
	{
		std::packaged_task<int()> t;
		{
			std::unique_lock<std::mutex> ulocker(_mu);					// Access to '_task_q' is locked using a 'unique_lock'.
			_cond.wait(ulocker, []() { return !_task_q.empty(); });		// We have to pop from the queue only if its not empty,
																		// else it can sleep indefinately until awaken.
			t = std::move(_task_q.front());
			_task_q.pop_front();
		}
		
		t();
	}

	int main()
	{
		std::thread t1(thread_1);

		std::packaged_task<int()> pt(std::bind(factorial, 7));
		std::future<int> fu = pt.get_future();
		{
			std::lock_guard<std::mutex> guard(_mu);						// Access to '_task_q' is locked using a 'lock_guard'.
			_task_q.push_back( std::move(pt) );
		}
		_cond.notify_one();												// And notified to any listeners about the push.
		
		std::cout << "FU = " << fu.get() << std::endl;

		t1.join();

		return 0;
	}

#endif

