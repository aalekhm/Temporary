#pragma once
#include <Windows.h>
#include <tchar.h>

#ifdef TESTDLL_EXPORTS
#define TESTDLL_EXPORTS_API __declspec(dllexport)
#else
#define TESTDLL_EXPORTS_API __declspec(dllimport)
#endif

extern "C" TESTDLL_EXPORTS_API int TestFunction(int iInput);
extern "C" TESTDLL_EXPORTS_API int AnotherTestFunction(int iInput);