#include <Windows.h>
#include <iostream>
#include "TestDLL.h"

int main(int argc, char* argv[])
{
	std::cout << TestFunction(5) << std::endl;
	std::cout << AnotherTestFunction(5) << std::endl;
	//HMODULE hModule = LoadLibrary(L"TestDLL.dll");
}