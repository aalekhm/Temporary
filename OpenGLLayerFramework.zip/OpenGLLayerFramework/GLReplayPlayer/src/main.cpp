#include"gltrace/gltrace.hpp"
#include <iostream>

#define CAPTURE_FILE "..\\x64\\Debug\\capture.gltrace"
using namespace gltrace;

int main(int argc, char** argv)
{
    const char* tracefile = (argc > 1) ? argv[1] : CAPTURE_FILE;

    WindowInitConfig cfg; 
    {
        cfg.title = "Replay Player";
        cfg.vsync = true;
    }

    GLFWwindow* win = (GLFWwindow*)InitGLAndWindow(cfg, false);
    if (!win)
    {
        fprintf(stderr, "Failed to init window+GL\n"); return 1;
    }

    std::function<void()> pOnFrameEnd = [&win, &cfg]()
    {
        PollAndSwap(win);
    };

    // Create replayer
    gltrace::Replayer replayer( tracefile, pOnFrameEnd);
    if (!replayer.Good())
    {
        std::cerr << "Failed to open replay file: " << tracefile << "\n";
        return -1;
    }
    replayer.Run();

    system("pause");
    DestroyWindow(win);

    return 0;
}