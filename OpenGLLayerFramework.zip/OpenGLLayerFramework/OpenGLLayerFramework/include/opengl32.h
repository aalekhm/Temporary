#pragma once

/*

          1    0 0001F400 GlmfBeginGlsBlock
          2    1 0001F470 GlmfCloseMetaFile
          3    2 0001F510 GlmfEndGlsBlock
          4    3 0001F550 GlmfEndPlayback
          5    4 0001F640 GlmfInitPlayback
          6    5 0001F910 GlmfPlayGlsRecord
          7    6 00025FA0 glAccum
          8    7 00026010 glAlphaFunc
          9    8 00026080 glAreTexturesResident
         10    9 00026100 glArrayElement
         11    A 00026130 glBegin
         12    B 00026160 glBindTexture
         13    C 00026190 glBitmap
         14    D 00026250 glBlendFunc
         15    E 000262C0 glCallList
         16    F 000262F0 glCallLists
         17   10 00026320 glClear
         18   11 00026380 glClearAccum
         19   12 00026420 glClearColor
         20   13 000264C0 glClearDepth
         21   14 00026530 glClearIndex
         22   15 000265A0 glClearStencil
         23   16 00026600 glClipPlane
         24   17 00026670 glColor3b
         25   18 000266A0 glColor3bv
         26   19 000266D0 glColor3d
         27   1A 00026700 glColor3dv
         28   1B 00026730 glColor3f
         29   1C 00026760 glColor3fv
         30   1D 00026790 glColor3i
         31   1E 000267C0 glColor3iv
         32   1F 000267F0 glColor3s
         33   20 00026820 glColor3sv
         34   21 00026850 glColor3ub
         35   22 00026880 glColor3ubv
         36   23 000268B0 glColor3ui
         37   24 000268E0 glColor3uiv
         38   25 00026910 glColor3us
         39   26 00026940 glColor3usv
         40   27 00026970 glColor4b
         41   28 000269B0 glColor4bv
         42   29 000269E0 glColor4d
         43   2A 00026A20 glColor4dv
         44   2B 00026A50 glColor4f
         45   2C 00026A90 glColor4fv
         46   2D 00026AC0 glColor4i
         47   2E 00026B00 glColor4iv
         48   2F 00026B30 glColor4s
         49   30 00026B70 glColor4sv
         50   31 00026BA0 glColor4ub
         51   32 00026BE0 glColor4ubv
         52   33 00026C10 glColor4ui
         53   34 00026C50 glColor4uiv
         54   35 00026C80 glColor4us
         55   36 00026CC0 glColor4usv
         56   37 00026CF0 glColorMask
         57   38 00026D80 glColorMaterial
         58   39 00026DF0 glColorPointer
         59   3A 00026ED0 glCopyPixels
         60   3B 00026F70 glCopyTexImage1D
         61   3C 00027020 glCopyTexImage2D
         62   3D 000270E0 glCopyTexSubImage1D
         63   3E 00027180 glCopyTexSubImage2D
         64   3F 00027240 glCullFace
         65   40 0003F7A0 glDebugEntry
         66   41 000272A0 glDeleteLists
         67   42 00027310 glDeleteTextures
         68   43 00027380 glDepthFunc
         69   44 000273E0 glDepthMask
         70   45 00027440 glDepthRange
         71   46 000274C0 glDisable
         72   47 000274F0 glDisableClientState
         73   48 00027520 glDrawArrays
         74   49 00027550 glDrawBuffer
         75   4A 000275B0 glDrawElements
         76   4B 000275F0 glDrawPixels
         77   4C 000276E0 glEdgeFlag
         78   4D 00027710 glEdgeFlagPointer
         79   4E 00027740 glEdgeFlagv
         80   4F 00027770 glEnable
         81   50 000277A0 glEnableClientState
         82   51 000277D0 glEnd
         83   52 00027800 glEndList
         84   53 00027860 glEvalCoord1d
         85   54 00027890 glEvalCoord1dv
         86   55 000278C0 glEvalCoord1f
         87   56 000278F0 glEvalCoord1fv
         88   57 00027920 glEvalCoord2d
         89   58 00027950 glEvalCoord2dv
         90   59 00027980 glEvalCoord2f
         91   5A 000279B0 glEvalCoord2fv
         92   5B 000279E0 glEvalMesh1
         93   5C 00027A60 glEvalMesh2
         94   5D 00027B00 glEvalPoint1
         95   5E 00027B30 glEvalPoint2
         96   5F 00027B60 glFeedbackBuffer
         97   60 00027BE0 glFinish
         98   61 00027C40 glFlush
         99   62 00027CA0 glFogf
        100   63 00027D10 glFogfv
        101   64 00027D80 glFogi
        102   65 00027DF0 glFogiv
        103   66 00027E60 glFrontFace
        104   67 00027EC0 glFrustum
        105   68 00027F80 glGenLists
        106   69 00027FE0 glGenTextures
        107   6A 00028050 glGetBooleanv
        108   6B 000280C0 glGetClipPlane
        109   6C 000282C0 glGetDoublev
        110   6D 00028330 glGetError
        111   6E 00028390 glGetFloatv
        112   6F 00028400 glGetIntegerv
        113   70 00028470 glGetLightfv
        114   71 000284F0 glGetLightiv
        115   72 00028570 glGetMapdv
        116   73 000285F0 glGetMapfv
        117   74 00028670 glGetMapiv
        118   75 000286F0 glGetMaterialfv
        119   76 00028770 glGetMaterialiv
        120   77 000287F0 glGetPixelMapfv
        121   78 00028860 glGetPixelMapuiv
        122   79 000288D0 glGetPixelMapusv
        123   7A 00028940 glGetPointerv
        124   7B 00028970 glGetPolygonStipple
        125   7C 000289D0 glGetString
        126   7D 00028A30 glGetTexEnvfv
        127   7E 00028AB0 glGetTexEnviv
        128   7F 00028B30 glGetTexGendv
        129   80 00028BB0 glGetTexGenfv
        130   81 00028C30 glGetTexGeniv
        131   82 00028CB0 glGetTexImage
        132   83 00028D50 glGetTexLevelParameterfv
        133   84 00028DE0 glGetTexLevelParameteriv
        134   85 00028E70 glGetTexParameterfv
        135   86 00028EF0 glGetTexParameteriv
        136   87 00028F70 glHint
        137   88 00028FE0 glIndexMask
        138   89 00029040 glIndexPointer
        139   8A 00029070 glIndexd
        140   8B 000290A0 glIndexdv
        141   8C 000290D0 glIndexf
        142   8D 00029100 glIndexfv
        143   8E 00029130 glIndexi
        144   8F 00029160 glIndexiv
        145   90 00029190 glIndexs
        146   91 000291C0 glIndexsv
        147   92 000291F0 glIndexub
        148   93 00029220 glIndexubv
        149   94 00029250 glInitNames
        150   95 000292B0 glInterleavedArrays
        151   96 000292E0 glIsEnabled
        152   97 00029340 glIsList
        153   98 000293A0 glIsTexture
        154   99 00029400 glLightModelf
        155   9A 00029470 glLightModelfv
        156   9B 000294E0 glLightModeli
        157   9C 00029550 glLightModeliv
        158   9D 000295C0 glLightf
        159   9E 00029640 glLightfv
        160   9F 000296C0 glLighti
        161   A0 00029740 glLightiv
        162   A1 000297C0 glLineStipple
        163   A2 00029830 glLineWidth
        164   A3 000298A0 glListBase
        165   A4 00029900 glLoadIdentity
        166   A5 00029930 glLoadMatrixd
        167   A6 00029960 glLoadMatrixf
        168   A7 00029990 glLoadName
        169   A8 000299F0 glLogicOp
        170   A9 00029A50 glMap1d
        171   AA 00029B00 glMap1f
        172   AB 00029BB0 glMap2d
        173   AC 00029CA0 glMap2f
        174   AD 00029D90 glMapGrid1d
        175   AE 00029E10 glMapGrid1f
        176   AF 00029E90 glMapGrid2d
        177   B0 00029F40 glMapGrid2f
        178   B1 00029FF0 glMaterialf
        179   B2 0002A020 glMaterialfv
        180   B3 0002A050 glMateriali
        181   B4 0002A080 glMaterialiv
        182   B5 0002A0B0 glMatrixMode
        183   B6 0002A0E0 glMultMatrixd
        184   B7 0002A110 glMultMatrixf
        185   B8 0002A140 glNewList
        186   B9 0002A1B0 glNormal3b
        187   BA 0002A1E0 glNormal3bv
        188   BB 0002A210 glNormal3d
        189   BC 0002A240 glNormal3dv
        190   BD 0002A270 glNormal3f
        191   BE 0002A2A0 glNormal3fv
        192   BF 0002A2D0 glNormal3i
        193   C0 0002A300 glNormal3iv
        194   C1 0002A330 glNormal3s
        195   C2 0002A360 glNormal3sv
        196   C3 0002A390 glNormalPointer
        197   C4 0002A3C0 glOrtho
        198   C5 0002A480 glPassThrough
        199   C6 0002A4F0 glPixelMapfv
        200   C7 0002A570 glPixelMapuiv
        201   C8 0002A5F0 glPixelMapusv
        202   C9 0002A670 glPixelStoref
        203   CA 0002A6E0 glPixelStorei
        204   CB 0002A750 glPixelTransferf
        205   CC 0002A7C0 glPixelTransferi
        206   CD 0002A830 glPixelZoom
        207   CE 0002A8B0 glPointSize
        208   CF 0002A920 glPolygonMode
        209   D0 0002A990 glPolygonOffset
        210   D1 0002A9C0 glPolygonStipple
        211   D2 0002AA20 glPopAttrib
        212   D3 0002AA50 glPopClientAttrib
        213   D4 0002AA80 glPopMatrix
        214   D5 0002AAB0 glPopName
        215   D6 0002AB10 glPrioritizeTextures
        216   D7 0002AB90 glPushAttrib
        217   D8 0002ABC0 glPushClientAttrib
        218   D9 0002ABF0 glPushMatrix
        219   DA 0002AC20 glPushName
        220   DB 0002AC80 glRasterPos2d
        221   DC 0002AD00 glRasterPos2dv
        222   DD 0002AD60 glRasterPos2f
        223   DE 0002ADE0 glRasterPos2fv
        224   DF 0002AE40 glRasterPos2i
        225   E0 0002AEB0 glRasterPos2iv
        226   E1 0002AF10 glRasterPos2s
        227   E2 0002AF80 glRasterPos2sv
        228   E3 0002AFE0 glRasterPos3d
        229   E4 0002B070 glRasterPos3dv
        230   E5 0002B0D0 glRasterPos3f
        231   E6 0002B160 glRasterPos3fv
        232   E7 0002B1C0 glRasterPos3i
        233   E8 0002B240 glRasterPos3iv
        234   E9 0002B2A0 glRasterPos3s
        235   EA 0002B320 glRasterPos3sv
        236   EB 0002B380 glRasterPos4d
        237   EC 0002B420 glRasterPos4dv
        238   ED 0002B480 glRasterPos4f
        239   EE 0002B520 glRasterPos4fv
        240   EF 0002B580 glRasterPos4i
        241   F0 0002B610 glRasterPos4iv
        242   F1 0002B670 glRasterPos4s
        243   F2 0002B710 glRasterPos4sv
        244   F3 0002B770 glReadBuffer
        245   F4 0002B7D0 glReadPixels
        246   F5 0002B880 glRectd
        247   F6 0002B920 glRectdv
        248   F7 0002B990 glRectf
        249   F8 0002BA30 glRectfv
        250   F9 0002BAA0 glRecti
        251   FA 0002BB30 glRectiv
        252   FB 0002BBA0 glRects
        253   FC 0002BC40 glRectsv
        254   FD 0002BCB0 glRenderMode
        255   FE 0002BD10 glRotated
        256   FF 0002BD50 glRotatef
        257  100 0002BD90 glScaled
        258  101 0002BDC0 glScalef
        259  102 0002BDF0 glScissor
        260  103 0002BE80 glSelectBuffer
        261  104 0002BEF0 glShadeModel
        262  105 0002BF50 glStencilFunc
        263  106 0002BFD0 glStencilMask
        264  107 0002C030 glStencilOp
        265  108 0002C0B0 glTexCoord1d
        266  109 0002C0E0 glTexCoord1dv
        267  10A 0002C110 glTexCoord1f
        268  10B 0002C140 glTexCoord1fv
        269  10C 0002C170 glTexCoord1i
        270  10D 0002C1A0 glTexCoord1iv
        271  10E 0002C1D0 glTexCoord1s
        272  10F 0002C200 glTexCoord1sv
        273  110 0002C230 glTexCoord2d
        274  111 0002C260 glTexCoord2dv
        275  112 0002C290 glTexCoord2f
        276  113 0002C2C0 glTexCoord2fv
        277  114 0002C2F0 glTexCoord2i
        278  115 0002C320 glTexCoord2iv
        279  116 0002C350 glTexCoord2s
        280  117 0002C380 glTexCoord2sv
        281  118 0002C3B0 glTexCoord3d
        282  119 0002C3E0 glTexCoord3dv
        283  11A 0002C410 glTexCoord3f
        284  11B 0002C440 glTexCoord3fv
        285  11C 0002C470 glTexCoord3i
        286  11D 0002C4A0 glTexCoord3iv
        287  11E 0002C4D0 glTexCoord3s
        288  11F 0002C500 glTexCoord3sv
        289  120 0002C530 glTexCoord4d
        290  121 0002C570 glTexCoord4dv
        291  122 0002C5A0 glTexCoord4f
        292  123 0002C5E0 glTexCoord4fv
        293  124 0002C610 glTexCoord4i
        294  125 0002C650 glTexCoord4iv
        295  126 0002C680 glTexCoord4s
        296  127 0002C6C0 glTexCoord4sv
        297  128 0002C6F0 glTexCoordPointer
        298  129 0002C730 glTexEnvf
        299  12A 0002C7B0 glTexEnvfv
        300  12B 0002C830 glTexEnvi
        301  12C 0002C8B0 glTexEnviv
        302  12D 0002C930 glTexGend
        303  12E 0002C9B0 glTexGendv
        304  12F 0002CA30 glTexGenf
        305  130 0002CAB0 glTexGenfv
        306  131 0002CB30 glTexGeni
        307  132 0002CBB0 glTexGeniv
        308  133 0002CC30 glTexImage1D
        309  134 0002CCF0 glTexImage2D
        310  135 0002CDC0 glTexParameterf
        311  136 0002CE40 glTexParameterfv
        312  137 0002CEC0 glTexParameteri
        313  138 0002CF40 glTexParameteriv
        314  139 0002CFC0 glTexSubImage1D
        315  13A 0002D070 glTexSubImage2D
        316  13B 0002D140 glTranslated
        317  13C 0002D170 glTranslatef
        318  13D 0002D1A0 glVertex2d
        319  13E 0002D1D0 glVertex2dv
        320  13F 0002D200 glVertex2f
        321  140 0002D230 glVertex2fv
        322  141 0002D260 glVertex2i
        323  142 0002D290 glVertex2iv
        324  143 0002D2C0 glVertex2s
        325  144 0002D2F0 glVertex2sv
        326  145 0002D320 glVertex3d
        327  146 0002D350 glVertex3dv
        328  147 0002D380 glVertex3f
        329  148 0002D3B0 glVertex3fv
        330  149 0002D3E0 glVertex3i
        331  14A 0002D410 glVertex3iv
        332  14B 0002D440 glVertex3s
        333  14C 0002D470 glVertex3sv
        334  14D 0002D4A0 glVertex4d
        335  14E 0002D4E0 glVertex4dv
        336  14F 0002D510 glVertex4f
        337  150 0002D550 glVertex4fv
        338  151 0002D580 glVertex4i
        339  152 0002D5C0 glVertex4iv
        340  153 0002D5F0 glVertex4s
        341  154 0002D630 glVertex4sv
        342  155 0002D660 glVertexPointer
        343  156 0002D6A0 glViewport
        344  157 00041110 wglChoosePixelFormat
        345  158 00023E20 wglCopyContext
        346  159 00023320 wglCreateContext
        347  15A 00023330 wglCreateLayerContext
        348  15B 00023F60 wglDeleteContext
        349  15C 0001E240 wglDescribeLayerPlane
        350  15D 000413F0 wglDescribePixelFormat
        351  15E 00002220 wglGetCurrentContext
        352  15F 00024040 wglGetCurrentDC
        353  160 00024070 wglGetDefaultProcAddress
        354  161 0001E300 wglGetLayerPaletteEntries
        355  162 000416D0 wglGetPixelFormat
        356  163 00024080 wglGetProcAddress
        357  164 0001F0E0 wglMakeCurrent
        358  165 0001E3B0 wglRealizeLayerPalette
        359  166 0001E460 wglSetLayerPaletteEntries
        360  167 000417A0 wglSetPixelFormat
        361  168 00024180 wglShareLists
        362  169 00041A50 wglSwapBuffers
        363  16A 0001E520 wglSwapLayerBuffers
        364  16B 00020690 wglSwapMultipleBuffers
        365  16C 00024390 wglUseFontBitmapsA
        366  16D 00024A90 wglUseFontBitmapsW
        367  16E 0000E840 wglUseFontOutlinesA
        368  16F 0000EBF0 wglUseFontOutlinesW
*/

/*
#pragma comment(linker, "/export:GlmfBeginGlsBlock=C:\\Windows\\System32\\opengl32.GlmfBeginGlsBlockC,@1")
#pragma comment(linker, "/export:GlmfCloseMetaFile=C:\\Windows\\System32\\opengl32.GlmfCloseMetaFile,@2")
#pragma comment(linker, "/export:GlmfEndGlsBlock=C:\\Windows\\System32\\opengl32.GlmfEndGlsBlock,@3")
#pragma comment(linker, "/export:GlmfEndPlayback=C:\\Windows\\System32\\opengl32.GlmfEndPlayback,@4")
#pragma comment(linker, "/export:GlmfInitPlayback=C:\\Windows\\System32\\opengl32.GlmfInitPlayback,@5")
#pragma comment(linker, "/export:GlmfPlayGlsRecord=C:\\Windows\\System32\\opengl32.GlmfPlayGlsRecord,@6")
#pragma comment(linker, "/export:glAccum=C:\\Windows\\System32\\opengl32.glAccum,@7")
#pragma comment(linker, "/export:glAlphaFunc=C:\\Windows\\System32\\opengl32.glAlphaFunc,@8")
#pragma comment(linker, "/export:glAreTexturesResident=C:\\Windows\\System32\\opengl32.glAreTexturesResident,@9")
#pragma comment(linker, "/export:glArrayElement=C:\\Windows\\System32\\opengl32.glArrayElement,@10")
#pragma comment(linker, "/export:glBegin=Shim_glBegin,@11")
#pragma comment(linker, "/export:glBindTexture=C:\\Windows\\System32\\opengl32.glBindTexture,@12")
#pragma comment(linker, "/export:glBitmap=C:\\Windows\\System32\\opengl32.glBitmap,@13")
#pragma comment(linker, "/export:glBlendFunc=C:\\Windows\\System32\\opengl32.glBlendFunc,@14")
#pragma comment(linker, "/export:glCallList=C:\\Windows\\System32\\opengl32.glCallList,@15")
#pragma comment(linker, "/export:glCallLists=C:\\Windows\\System32\\opengl32.glCallLists,@16")
#pragma comment(linker, "/export:glClear=Shim_glClear,@17")
#pragma comment(linker, "/export:glClearAccum=C:\\Windows\\System32\\opengl32.glClearAccum,@18")
#pragma comment(linker, "/export:glClearColor=C:\\Windows\\System32\\opengl32.glClearColor,@19")
#pragma comment(linker, "/export:glClearDepth=C:\\Windows\\System32\\opengl32.glClearDepth,@20")
#pragma comment(linker, "/export:glClearIndex=C:\\Windows\\System32\\opengl32.glClearIndex,@21")
#pragma comment(linker, "/export:glClearStencil=C:\\Windows\\System32\\opengl32.glClearStencil,@22")
#pragma comment(linker, "/export:glClipPlane=C:\\Windows\\System32\\opengl32.glClipPlane,@23")
#pragma comment(linker, "/export:glColor3b=C:\\Windows\\System32\\opengl32.glColor3b,@24")
#pragma comment(linker, "/export:glColor3bv=C:\\Windows\\System32\\opengl32.glColor3bv,@25")
#pragma comment(linker, "/export:glColor3d=C:\\Windows\\System32\\opengl32.glColor3d,@26")
#pragma comment(linker, "/export:glColor3dv=C:\\Windows\\System32\\opengl32.glColor3dv,@27")
#pragma comment(linker, "/export:glColor3f=Shim_glColor3f,@28")
#pragma comment(linker, "/export:glColor3fv=C:\\Windows\\System32\\opengl32.glColor3fv,@29")
#pragma comment(linker, "/export:glColor3i=C:\\Windows\\System32\\opengl32.glColor3i,@30")
#pragma comment(linker, "/export:glColor3iv=C:\\Windows\\System32\\opengl32.glColor3iv,@31")
#pragma comment(linker, "/export:glColor3s=C:\\Windows\\System32\\opengl32.glColor3s,@32")
#pragma comment(linker, "/export:glColor3sv=C:\\Windows\\System32\\opengl32.glColor3sv,@33")
#pragma comment(linker, "/export:glColor3ub=C:\\Windows\\System32\\opengl32.glColor3ub,@34")
#pragma comment(linker, "/export:glColor3ubv=C:\\Windows\\System32\\opengl32.glColor3ubv,@35")
#pragma comment(linker, "/export:glColor3ui=C:\\Windows\\System32\\opengl32.glColor3ui,@36")
#pragma comment(linker, "/export:glColor3uiv=C:\\Windows\\System32\\opengl32.glColor3uiv,@37")
#pragma comment(linker, "/export:glColor3us=C:\\Windows\\System32\\opengl32.glColor3us,@38")
#pragma comment(linker, "/export:glColor3usv=C:\\Windows\\System32\\opengl32.glColor3usv,@39")
#pragma comment(linker, "/export:glColor4b=C:\\Windows\\System32\\opengl32.glColor4b,@40")
#pragma comment(linker, "/export:glColor4bv=C:\\Windows\\System32\\opengl32.glColor4bv,@41")
#pragma comment(linker, "/export:glColor4d=C:\\Windows\\System32\\opengl32.glColor4d,@42")
#pragma comment(linker, "/export:glColor4dv=C:\\Windows\\System32\\opengl32.glColor4dv,@43")
#pragma comment(linker, "/export:glColor4f=C:\\Windows\\System32\\opengl32.glColor4f,@44")
#pragma comment(linker, "/export:glColor4fv=C:\\Windows\\System32\\opengl32.glColor4fv,@45")
#pragma comment(linker, "/export:glColor4i=C:\\Windows\\System32\\opengl32.glColor4i,@46")
#pragma comment(linker, "/export:glColor4iv=C:\\Windows\\System32\\opengl32.glColor4iv,@47")
#pragma comment(linker, "/export:glColor4s=C:\\Windows\\System32\\opengl32.glColor4s,@48")
#pragma comment(linker, "/export:glColor4sv=C:\\Windows\\System32\\opengl32.glColor4sv,@49")
#pragma comment(linker, "/export:glColor4ub=C:\\Windows\\System32\\opengl32.glColor4ub,@50")
#pragma comment(linker, "/export:glColor4ubv=C:\\Windows\\System32\\opengl32.glColor4ubv,@51")
#pragma comment(linker, "/export:glColor4ui=C:\\Windows\\System32\\opengl32.glColor4ui,@52")
#pragma comment(linker, "/export:glColor4uiv=C:\\Windows\\System32\\opengl32.glColor4uiv,@53")
#pragma comment(linker, "/export:glColor4us=C:\\Windows\\System32\\opengl32.glColor4us,@54")
#pragma comment(linker, "/export:glColor4usv=C:\\Windows\\System32\\opengl32.glColor4usv,@55")
#pragma comment(linker, "/export:glColorMask=C:\\Windows\\System32\\opengl32.glColorMask,@56")
#pragma comment(linker, "/export:glColorMaterial=C:\\Windows\\System32\\opengl32.glColorMaterial,@57")
#pragma comment(linker, "/export:glColorPointer=C:\\Windows\\System32\\opengl32.glColorPointer,@58")
#pragma comment(linker, "/export:glCopyPixels=C:\\Windows\\System32\\opengl32.glCopyPixels,@59")
#pragma comment(linker, "/export:glCopyTexImage1D=C:\\Windows\\System32\\opengl32.glCopyTexImage1D,@60")
#pragma comment(linker, "/export:glCopyTexImage2D=C:\\Windows\\System32\\opengl32.glCopyTexImage2D,@61")
#pragma comment(linker, "/export:glCopyTexSubImage1D=C:\\Windows\\System32\\opengl32.glCopyTexSubImage1D,@62")
#pragma comment(linker, "/export:glCopyTexSubImage2D=C:\\Windows\\System32\\opengl32.glCopyTexSubImage2D,@63")
#pragma comment(linker, "/export:glCullFace=C:\\Windows\\System32\\opengl32.glCullFace,@64")
#pragma comment(linker, "/export:glDebugEntry=C:\\Windows\\System32\\opengl32.glDebugEntry,@65")
#pragma comment(linker, "/export:glDeleteLists=C:\\Windows\\System32\\opengl32.glDeleteLists,@66")
#pragma comment(linker, "/export:glDeleteTextures=C:\\Windows\\System32\\opengl32.glDeleteTextures,@67")
#pragma comment(linker, "/export:glDepthFunc=C:\\Windows\\System32\\opengl32.glDepthFunc,@68")
#pragma comment(linker, "/export:glDepthMask=C:\\Windows\\System32\\opengl32.glDepthMask,@69")
#pragma comment(linker, "/export:glDepthRange=C:\\Windows\\System32\\opengl32.glDepthRange,@70")
#pragma comment(linker, "/export:glDisable=C:\\Windows\\System32\\opengl32.glDisable,@71")
#pragma comment(linker, "/export:glDisableClientState=C:\\Windows\\System32\\opengl32.glDisableClientState,@72")
#pragma comment(linker, "/export:glDrawArrays=C:\\Windows\\System32\\opengl32.glDrawArrays,@73")
#pragma comment(linker, "/export:glDrawBuffer=C:\\Windows\\System32\\opengl32.glDrawBuffer,@74")
#pragma comment(linker, "/export:glDrawElements=C:\\Windows\\System32\\opengl32.glDrawElements,@75")
#pragma comment(linker, "/export:glDrawPixels=C:\\Windows\\System32\\opengl32.glDrawPixels,@76")
#pragma comment(linker, "/export:glEdgeFlag=C:\\Windows\\System32\\opengl32.glEdgeFlag,@77")
#pragma comment(linker, "/export:glEdgeFlagPointer=C:\\Windows\\System32\\opengl32.glEdgeFlagPointer,@78")
#pragma comment(linker, "/export:glEdgeFlagv=C:\\Windows\\System32\\opengl32.glEdgeFlagv,@79")
#pragma comment(linker, "/export:glEnable=C:\\Windows\\System32\\opengl32.glEnable,@80")
#pragma comment(linker, "/export:glEnableClientState=C:\\Windows\\System32\\opengl32.glEnableClientState,@81")
#pragma comment(linker, "/export:glEnd=C:\\Windows\\System32\\opengl32.glEnd,@82")
#pragma comment(linker, "/export:glEndList=C:\\Windows\\System32\\opengl32.glEndList,@83")
#pragma comment(linker, "/export:glEvalCoord1d=C:\\Windows\\System32\\opengl32.glEvalCoord1d,@84")
#pragma comment(linker, "/export:glEvalCoord1dv=C:\\Windows\\System32\\opengl32.glEvalCoord1dv,@85")
#pragma comment(linker, "/export:glEvalCoord1f=C:\\Windows\\System32\\opengl32.glEvalCoord1f,@86")
#pragma comment(linker, "/export:glEvalCoord1fv=C:\\Windows\\System32\\opengl32.glEvalCoord1fv,@87")
#pragma comment(linker, "/export:glEvalCoord2d=C:\\Windows\\System32\\opengl32.glEvalCoord2d,@88")
#pragma comment(linker, "/export:glEvalCoord2dv=C:\\Windows\\System32\\opengl32.glEvalCoord2dv,@89")
#pragma comment(linker, "/export:glEvalCoord2f=C:\\Windows\\System32\\opengl32.glEvalCoord2f,@90")
#pragma comment(linker, "/export:glEvalCoord2fv=C:\\Windows\\System32\\opengl32.glEvalCoord2fv,@91")
#pragma comment(linker, "/export:glEvalMesh1=C:\\Windows\\System32\\opengl32.glEvalMesh1,@92")
#pragma comment(linker, "/export:glEvalMesh2=C:\\Windows\\System32\\opengl32.glEvalMesh2,@93")
#pragma comment(linker, "/export:glEvalPoint1=C:\\Windows\\System32\\opengl32.glEvalPoint1,@94")
#pragma comment(linker, "/export:glEvalPoint2=C:\\Windows\\System32\\opengl32.glEvalPoint2,@95")
#pragma comment(linker, "/export:glFeedbackBuffer=C:\\Windows\\System32\\opengl32.glFeedbackBuffer,@96")
#pragma comment(linker, "/export:glFinish=C:\\Windows\\System32\\opengl32.glFinish,@97")
#pragma comment(linker, "/export:glFlush=C:\\Windows\\System32\\opengl32.glFlush,@98")
#pragma comment(linker, "/export:glFogf=C:\\Windows\\System32\\opengl32.glFogf,@99")
#pragma comment(linker, "/export:glFogfv=C:\\Windows\\System32\\opengl32.glFogfv,@100")
#pragma comment(linker, "/export:glFogi=C:\\Windows\\System32\\opengl32.glFogi,@101")
#pragma comment(linker, "/export:glFogiv=C:\\Windows\\System32\\opengl32.glFogiv,@102")
#pragma comment(linker, "/export:glFrontFace=C:\\Windows\\System32\\opengl32.glFrontFace,@103")
#pragma comment(linker, "/export:glFrustum=C:\\Windows\\System32\\opengl32.glFrustum,@104")
#pragma comment(linker, "/export:glGenLists=C:\\Windows\\System32\\opengl32.glGenLists,@105")
#pragma comment(linker, "/export:glGenTextures=C:\\Windows\\System32\\opengl32.glGenTextures,@106")
#pragma comment(linker, "/export:glGetBooleanv=C:\\Windows\\System32\\opengl32.glGetBooleanv,@107")
#pragma comment(linker, "/export:glGetClipPlane=C:\\Windows\\System32\\opengl32.glGetClipPlane,@108")
#pragma comment(linker, "/export:glGetDoublev=C:\\Windows\\System32\\opengl32.glGetDoublev,@109")
#pragma comment(linker, "/export:glGetError=C:\\Windows\\System32\\opengl32.glGetError,@110")
#pragma comment(linker, "/export:glGetFloatv=C:\\Windows\\System32\\opengl32.glGetFloatv,@111")
#pragma comment(linker, "/export:glGetIntegerv=C:\\Windows\\System32\\opengl32.glGetIntegerv,@112")
#pragma comment(linker, "/export:glGetLightfv=C:\\Windows\\System32\\opengl32.glGetLightfv,@113")
#pragma comment(linker, "/export:glGetLightiv=C:\\Windows\\System32\\opengl32.glGetLightiv,@114")
#pragma comment(linker, "/export:glGetMapfv=C:\\Windows\\System32\\opengl32.glGetMapfv,@115")
#pragma comment(linker, "/export:glGetMapdv=C:\\Windows\\System32\\opengl32.glGetMapdv,@116")
#pragma comment(linker, "/export:glGetMapiv=C:\\Windows\\System32\\opengl32.glGetMapiv,@117")
#pragma comment(linker, "/export:glGetMaterialfv=C:\\Windows\\System32\\opengl32.glGetMaterialfv,@118")
#pragma comment(linker, "/export:glGetMaterialiv=C:\\Windows\\System32\\opengl32.glGetMaterialiv,@119")
#pragma comment(linker, "/export:glGetPixelMapfv=C:\\Windows\\System32\\opengl32.glGetPixelMapfv,@120")
#pragma comment(linker, "/export:glGetPixelMapuiv=C:\\Windows\\System32\\opengl32.glGetPixelMapuiv,@121")
#pragma comment(linker, "/export:glGetPixelMapusv=C:\\Windows\\System32\\opengl32.glGetPixelMapusv,@122")
#pragma comment(linker, "/export:glGetPointerv=C:\\Windows\\System32\\opengl32.glGetPointerv,@123")
#pragma comment(linker, "/export:glGetPolygonStipple=C:\\Windows\\System32\\opengl32.glGetPolygonStipple,@124")
#pragma comment(linker, "/export:glGetString=C:\\Windows\\System32\\opengl32.glGetString,@125")
#pragma comment(linker, "/export:glGetTexEnvfv=C:\\Windows\\System32\\opengl32.glGetTexEnvfv,@126")
#pragma comment(linker, "/export:glGetTexEnviv=C:\\Windows\\System32\\opengl32.glGetTexEnviv,@127")
#pragma comment(linker, "/export:glGetTexGendv=C:\\Windows\\System32\\opengl32.glGetTexGendv,@128")
#pragma comment(linker, "/export:glGetTexGenfv=C:\\Windows\\System32\\opengl32.glGetTexGenfv,@129")
#pragma comment(linker, "/export:glGetTexGeniv=C:\\Windows\\System32\\opengl32.glGetTexGeniv,@130")
#pragma comment(linker, "/export:glGetTexImage=C:\\Windows\\System32\\opengl32.glGetTexImage,@131")
#pragma comment(linker, "/export:glGetTexLevelParameterfv=C:\\Windows\\System32\\opengl32.glGetTexLevelParameterfv,@132")
#pragma comment(linker, "/export:glGetTexLevelParameteriv=C:\\Windows\\System32\\opengl32.glGetTexLevelParameteriv,@133")
#pragma comment(linker, "/export:glGetTexParameterfv=C:\\Windows\\System32\\opengl32.glGetTexParameterfv,@134")
#pragma comment(linker, "/export:glGetTexParameteriv=C:\\Windows\\System32\\opengl32.glGetTexParameteriv,@135")
#pragma comment(linker, "/export:glHint=C:\\Windows\\System32\\opengl32.glHint,@136")
#pragma comment(linker, "/export:glIndexMask=C:\\Windows\\System32\\opengl32.glIndexMask,@137")
#pragma comment(linker, "/export:glIndexPointer=C:\\Windows\\System32\\opengl32.glIndexPointer,@138")
#pragma comment(linker, "/export:glIndexd=C:\\Windows\\System32\\opengl32.glIndexd,@139")
#pragma comment(linker, "/export:glIndexdv=C:\\Windows\\System32\\opengl32.glIndexdv,@140")
#pragma comment(linker, "/export:glIndexf=C:\\Windows\\System32\\opengl32.glIndexf,@141")
#pragma comment(linker, "/export:glIndexfv=C:\\Windows\\System32\\opengl32.glIndexfv,@142")
#pragma comment(linker, "/export:glIndexi=C:\\Windows\\System32\\opengl32.glIndexi,@143")
#pragma comment(linker, "/export:glIndexiv=C:\\Windows\\System32\\opengl32.glIndexiv,@144")
#pragma comment(linker, "/export:glIndexs=C:\\Windows\\System32\\opengl32.glIndexs,@145")
#pragma comment(linker, "/export:glIndexsv=C:\\Windows\\System32\\opengl32.glIndexsv,@146")
#pragma comment(linker, "/export:glIndexub=C:\\Windows\\System32\\opengl32.glIndexub,@147")
#pragma comment(linker, "/export:glIndexubv=C:\\Windows\\System32\\opengl32.glIndexubv,@148")
#pragma comment(linker, "/export:glInitNames=C:\\Windows\\System32\\opengl32.glInitNames,@149")
#pragma comment(linker, "/export:glInterleavedArrays=C:\\Windows\\System32\\opengl32.glInterleavedArrays,@150")
#pragma comment(linker, "/export:glIsEnabled=C:\\Windows\\System32\\opengl32.glIsEnabled,@151")
#pragma comment(linker, "/export:glIsList=C:\\Windows\\System32\\opengl32.glIsList,@152")
#pragma comment(linker, "/export:glIsTexture=C:\\Windows\\System32\\opengl32.glIsTexture,@153")
#pragma comment(linker, "/export:glLightModelf=C:\\Windows\\System32\\opengl32.glLightModelf,@154")
#pragma comment(linker, "/export:glLightModelfv=C:\\Windows\\System32\\opengl32.glLightModelfv,@155")
#pragma comment(linker, "/export:glLightModeli=C:\\Windows\\System32\\opengl32.glLightModeli,@156")
#pragma comment(linker, "/export:glLightModeliv=C:\\Windows\\System32\\opengl32.glLightModeliv,@157")
#pragma comment(linker, "/export:glLightf=C:\\Windows\\System32\\opengl32.glLightf,@158")
#pragma comment(linker, "/export:glLightfv=C:\\Windows\\System32\\opengl32.glLightfv,@159")
#pragma comment(linker, "/export:glLighti=C:\\Windows\\System32\\opengl32.glLighti,@160")
#pragma comment(linker, "/export:glLightiv=C:\\Windows\\System32\\opengl32.glLightiv,@161")
#pragma comment(linker, "/export:glLineStipple=C:\\Windows\\System32\\opengl32.glLineStipple,@162")
#pragma comment(linker, "/export:glLineWidth=C:\\Windows\\System32\\opengl32.glLineWidth,@163")
#pragma comment(linker, "/export:glListBase=C:\\Windows\\System32\\opengl32.glListBase,@164")
#pragma comment(linker, "/export:glLoadIdentity=C:\\Windows\\System32\\opengl32.glLoadIdentity,@165")
#pragma comment(linker, "/export:glLoadMatrixd=C:\\Windows\\System32\\opengl32.glLoadMatrixd,@166")
#pragma comment(linker, "/export:glLoadMatrixf=C:\\Windows\\System32\\opengl32.glLoadMatrixf,@167")
#pragma comment(linker, "/export:glLoadName=C:\\Windows\\System32\\opengl32.glLoadName,@168")
#pragma comment(linker, "/export:glLogicOp=C:\\Windows\\System32\\opengl32.glLogicOp,@169")
#pragma comment(linker, "/export:glMap1d=C:\\Windows\\System32\\opengl32.glMap1d,@170")
#pragma comment(linker, "/export:glMap1f=C:\\Windows\\System32\\opengl32.glMap1f,@171")
#pragma comment(linker, "/export:glMap2d=C:\\Windows\\System32\\opengl32.glMap2d,@172")
#pragma comment(linker, "/export:glMap2f=C:\\Windows\\System32\\opengl32.glMap2f,@173")
#pragma comment(linker, "/export:glMapGrid1d=C:\\Windows\\System32\\opengl32.glMapGrid1d,@174")
#pragma comment(linker, "/export:glMapGrid1f=C:\\Windows\\System32\\opengl32.glMapGrid1f,@175")
#pragma comment(linker, "/export:glMapGrid2d=C:\\Windows\\System32\\opengl32.glMapGrid2d,@176")
#pragma comment(linker, "/export:glMapGrid2f=C:\\Windows\\System32\\opengl32.glMapGrid2f,@177")
#pragma comment(linker, "/export:glMaterialf=C:\\Windows\\System32\\opengl32.glMaterialf,@178")
#pragma comment(linker, "/export:glMaterialfv=C:\\Windows\\System32\\opengl32.glMaterialfv,@179")
#pragma comment(linker, "/export:glMateriali=C:\\Windows\\System32\\opengl32.glMateriali,@180")
#pragma comment(linker, "/export:glMaterialiv=C:\\Windows\\System32\\opengl32.glMaterialiv,@181")
#pragma comment(linker, "/export:glMatrixMode=C:\\Windows\\System32\\opengl32.glMatrixMode,@182")
#pragma comment(linker, "/export:glMultMatrixd=C:\\Windows\\System32\\opengl32.glMultMatrixd,@183")
#pragma comment(linker, "/export:glMultMatrixf=C:\\Windows\\System32\\opengl32.glMultMatrixf,@184")
#pragma comment(linker, "/export:glNewList=C:\\Windows\\System32\\opengl32.glNewList,@185")
#pragma comment(linker, "/export:glNormal3b=C:\\Windows\\System32\\opengl32.glNormal3b,@186")
#pragma comment(linker, "/export:glNormal3bv=C:\\Windows\\System32\\opengl32.glNormal3bv,@187")
#pragma comment(linker, "/export:glNormal3d=C:\\Windows\\System32\\opengl32.glNormal3d,@188")
#pragma comment(linker, "/export:glNormal3dv=C:\\Windows\\System32\\opengl32.glNormal3dv,@189")
#pragma comment(linker, "/export:glNormal3f=C:\\Windows\\System32\\opengl32.glNormal3f,@190")
#pragma comment(linker, "/export:glNormal3fv=C:\\Windows\\System32\\opengl32.glNormal3fv,@191")
#pragma comment(linker, "/export:glNormal3i=C:\\Windows\\System32\\opengl32.glNormal3i,@192")
#pragma comment(linker, "/export:glNormal3iv=C:\\Windows\\System32\\opengl32.glNormal3iv,@193")
#pragma comment(linker, "/export:glNormal3s=C:\\Windows\\System32\\opengl32.glNormal3s,@194")
#pragma comment(linker, "/export:glNormal3sv=C:\\Windows\\System32\\opengl32.glNormal3sv,@195")
#pragma comment(linker, "/export:glNormalPointer=C:\\Windows\\System32\\opengl32.glNormalPointer,@196")
#pragma comment(linker, "/export:glOrtho=C:\\Windows\\System32\\opengl32.glOrtho,@197")
#pragma comment(linker, "/export:glPassThrough=C:\\Windows\\System32\\opengl32.glPassThrough,@198")
#pragma comment(linker, "/export:glPixelMapfv=C:\\Windows\\System32\\opengl32.glPixelMapfv,@199")
#pragma comment(linker, "/export:glPixelMapuiv=C:\\Windows\\System32\\opengl32.glPixelMapuiv,@200")
#pragma comment(linker, "/export:glPixelMapusv=C:\\Windows\\System32\\opengl32.glPixelMapusv,@201")
#pragma comment(linker, "/export:glPixelStoref=C:\\Windows\\System32\\opengl32.glPixelStoref,@202")
#pragma comment(linker, "/export:glPixelStorei=C:\\Windows\\System32\\opengl32.glPixelStorei,@203")
#pragma comment(linker, "/export:glPixelTransferf=C:\\Windows\\System32\\opengl32.glPixelTransferf,@204")
#pragma comment(linker, "/export:glPixelTransferi=C:\\Windows\\System32\\opengl32.glPixelTransferi,@205")
#pragma comment(linker, "/export:glPixelZoom=C:\\Windows\\System32\\opengl32.glPixelZoom,@206")
#pragma comment(linker, "/export:glPointSize=C:\\Windows\\System32\\opengl32.glPointSize,@207")
#pragma comment(linker, "/export:glPolygonMode=C:\\Windows\\System32\\opengl32.glPolygonMode,@208")
#pragma comment(linker, "/export:glPolygonOffset=C:\\Windows\\System32\\opengl32.glPolygonOffset,@209")
#pragma comment(linker, "/export:glPolygonStipple=C:\\Windows\\System32\\opengl32.glPolygonStipple,@210")
#pragma comment(linker, "/export:glPopAttrib=C:\\Windows\\System32\\opengl32.glPopAttrib,@211")
#pragma comment(linker, "/export:glPopClientAttrib=C:\\Windows\\System32\\opengl32.glPopClientAttrib,@212")
#pragma comment(linker, "/export:glPopMatrix=C:\\Windows\\System32\\opengl32.glPopMatrix,@213")
#pragma comment(linker, "/export:glPopName=C:\\Windows\\System32\\opengl32.glPopName,@214")
#pragma comment(linker, "/export:glPrioritizeTextures=C:\\Windows\\System32\\opengl32.glPrioritizeTextures,@215")
#pragma comment(linker, "/export:glPushAttrib=C:\\Windows\\System32\\opengl32.glPushAttrib,@216")
#pragma comment(linker, "/export:glPushClientAttrib=C:\\Windows\\System32\\opengl32.glPushClientAttrib,@217")
#pragma comment(linker, "/export:glPushMatrix=C:\\Windows\\System32\\opengl32.glPushMatrix,@218")
#pragma comment(linker, "/export:glPushName=C:\\Windows\\System32\\opengl32.glPushName,@219")
#pragma comment(linker, "/export:glRasterPos2d=C:\\Windows\\System32\\opengl32.glRasterPos2d,@220")
#pragma comment(linker, "/export:glRasterPos2dv=C:\\Windows\\System32\\opengl32.glRasterPos2dv,@221")
#pragma comment(linker, "/export:glRasterPos2f=C:\\Windows\\System32\\opengl32.glRasterPos2f,@222")
#pragma comment(linker, "/export:glRasterPos2fv=C:\\Windows\\System32\\opengl32.glRasterPos2fv,@223")
#pragma comment(linker, "/export:glRasterPos2i=C:\\Windows\\System32\\opengl32.glRasterPos2i,@224")
#pragma comment(linker, "/export:glRasterPos2iv=C:\\Windows\\System32\\opengl32.glRasterPos2iv,@225")
#pragma comment(linker, "/export:glRasterPos2s=C:\\Windows\\System32\\opengl32.glRasterPos2s,@226")
#pragma comment(linker, "/export:glRasterPos2sv=C:\\Windows\\System32\\opengl32.glRasterPos2sv,@227")
#pragma comment(linker, "/export:glRasterPos3d=C:\\Windows\\System32\\opengl32.glRasterPos3d,@228")
#pragma comment(linker, "/export:glRasterPos3dv=C:\\Windows\\System32\\opengl32.glRasterPos3dv,@229")
#pragma comment(linker, "/export:glRasterPos3f=C:\\Windows\\System32\\opengl32.glRasterPos3f,@230")
#pragma comment(linker, "/export:glRasterPos3fv=C:\\Windows\\System32\\opengl32.glRasterPos3fv,@231")
#pragma comment(linker, "/export:glRasterPos3i=C:\\Windows\\System32\\opengl32.glRasterPos3i,@232")
#pragma comment(linker, "/export:glRasterPos3iv=C:\\Windows\\System32\\opengl32.glRasterPos3iv,@233")
#pragma comment(linker, "/export:glRasterPos3s=C:\\Windows\\System32\\opengl32.glRasterPos3s,@234")
#pragma comment(linker, "/export:glRasterPos3sv=C:\\Windows\\System32\\opengl32.glRasterPos3sv,@235")
#pragma comment(linker, "/export:glRasterPos4d=C:\\Windows\\System32\\opengl32.glRasterPos4d,@1236")
#pragma comment(linker, "/export:glRasterPos4dv=C:\\Windows\\System32\\opengl32.glRasterPos4dv,@237")
#pragma comment(linker, "/export:glRasterPos4f=C:\\Windows\\System32\\opengl32.glRasterPos4f,@238")
#pragma comment(linker, "/export:glRasterPos4fv=C:\\Windows\\System32\\opengl32.glRasterPos4fv,@239")
#pragma comment(linker, "/export:glRasterPos4i=C:\\Windows\\System32\\opengl32.glRasterPos4i,@240")
#pragma comment(linker, "/export:glRasterPos4iv=C:\\Windows\\System32\\opengl32.glRasterPos4iv,@241")
#pragma comment(linker, "/export:glRasterPos4s=C:\\Windows\\System32\\opengl32.glRasterPos4s,@242")
#pragma comment(linker, "/export:glRasterPos4sv=C:\\Windows\\System32\\opengl32.glRasterPos4sv,@243")
#pragma comment(linker, "/export:glReadBuffer=C:\\Windows\\System32\\opengl32.glReadBuffer,@244")
#pragma comment(linker, "/export:glReadPixels=C:\\Windows\\System32\\opengl32.glReadPixels,@245")
#pragma comment(linker, "/export:glRectd=C:\\Windows\\System32\\opengl32.glRectd,@246")
#pragma comment(linker, "/export:glRectdv=C:\\Windows\\System32\\opengl32.glRectdv,@247")
#pragma comment(linker, "/export:glRectf=C:\\Windows\\System32\\opengl32.glRectf,@248")
#pragma comment(linker, "/export:glRectfv=C:\\Windows\\System32\\opengl32.glRectfv,@249")
#pragma comment(linker, "/export:glRecti=C:\\Windows\\System32\\opengl32.glRecti,@250")
#pragma comment(linker, "/export:glRectiv=C:\\Windows\\System32\\opengl32.glRectiv,@251")
#pragma comment(linker, "/export:glRects=C:\\Windows\\System32\\opengl32.glRects,@252")
#pragma comment(linker, "/export:glRectsv=C:\\Windows\\System32\\opengl32.glRectsv,@253")
#pragma comment(linker, "/export:glRenderMode=C:\\Windows\\System32\\opengl32.glRenderMode,@254")
#pragma comment(linker, "/export:glRotated=C:\\Windows\\System32\\opengl32.glRotated,@255")
#pragma comment(linker, "/export:glRotatef=C:\\Windows\\System32\\opengl32.glRotatef,@256")
#pragma comment(linker, "/export:glScaled=C:\\Windows\\System32\\opengl32.glScaled,@257")
#pragma comment(linker, "/export:glScalef=C:\\Windows\\System32\\opengl32.glScalef,@258")
#pragma comment(linker, "/export:glScissor=C:\\Windows\\System32\\opengl32.glScissor,@259")
#pragma comment(linker, "/export:glSelectBuffer=C:\\Windows\\System32\\opengl32.glSelectBuffer,@260")
#pragma comment(linker, "/export:glShadeModel=C:\\Windows\\System32\\opengl32.glShadeModel,@261")
#pragma comment(linker, "/export:glStencilFunc=C:\\Windows\\System32\\opengl32.glStencilFunc,@262")
#pragma comment(linker, "/export:glStencilMask=C:\\Windows\\System32\\opengl32.glStencilMask,@263")
#pragma comment(linker, "/export:glStencilOp=C:\\Windows\\System32\\opengl32.glStencilOp,@264")
#pragma comment(linker, "/export:glTexCoord1d=C:\\Windows\\System32\\opengl32.glTexCoord1d,@265")
#pragma comment(linker, "/export:glTexCoord1dv=C:\\Windows\\System32\\opengl32.glTexCoord1dv,@266")
#pragma comment(linker, "/export:glTexCoord1f=C:\\Windows\\System32\\opengl32.glTexCoord1f,@267")
#pragma comment(linker, "/export:glTexCoord1fv=C:\\Windows\\System32\\opengl32.glTexCoord1fv,@268")
#pragma comment(linker, "/export:glTexCoord1i=C:\\Windows\\System32\\opengl32.glTexCoord1i,@269")
#pragma comment(linker, "/export:glTexCoord1iv=C:\\Windows\\System32\\opengl32.glTexCoord1iv,@270")
#pragma comment(linker, "/export:glTexCoord1s=C:\\Windows\\System32\\opengl32.glTexCoord1s,@271")
#pragma comment(linker, "/export:glTexCoord1sv=C:\\Windows\\System32\\opengl32.glTexCoord1sv,@272")
#pragma comment(linker, "/export:glTexCoord2d=C:\\Windows\\System32\\opengl32.glTexCoord2d,@273")
#pragma comment(linker, "/export:glTexCoord2dv=C:\\Windows\\System32\\opengl32.glTexCoord2dv,@274")
#pragma comment(linker, "/export:glTexCoord2f=C:\\Windows\\System32\\opengl32.glTexCoord2f,@275")
#pragma comment(linker, "/export:glTexCoord2fv=C:\\Windows\\System32\\opengl32.glTexCoord2fv,@276")
#pragma comment(linker, "/export:glTexCoord2i=C:\\Windows\\System32\\opengl32.glTexCoord2i,@277")
#pragma comment(linker, "/export:glTexCoord2iv=C:\\Windows\\System32\\opengl32.glTexCoord2iv,@278")
#pragma comment(linker, "/export:glTexCoord2s=C:\\Windows\\System32\\opengl32.glTexCoord2s,@279")
#pragma comment(linker, "/export:glTexCoord2sv=C:\\Windows\\System32\\opengl32.glTexCoord2sv,@280")
#pragma comment(linker, "/export:glTexCoord3d=C:\\Windows\\System32\\opengl32.glTexCoord3d,@281")
#pragma comment(linker, "/export:glTexCoord3dv=C:\\Windows\\System32\\opengl32.glTexCoord3dv,@282")
#pragma comment(linker, "/export:glTexCoord3f=C:\\Windows\\System32\\opengl32.glTexCoord3f,@283")
#pragma comment(linker, "/export:glTexCoord3fv=C:\\Windows\\System32\\opengl32.glTexCoord3fv,@284")
#pragma comment(linker, "/export:glTexCoord3i=C:\\Windows\\System32\\opengl32.glTexCoord3i,@285")
#pragma comment(linker, "/export:glTexCoord3iv=C:\\Windows\\System32\\opengl32.glTexCoord3iv,@286")
#pragma comment(linker, "/export:glTexCoord3s=C:\\Windows\\System32\\opengl32.glTexCoord3s,@287")
#pragma comment(linker, "/export:glTexCoord3sv=C:\\Windows\\System32\\opengl32.glTexCoord3sv,@288")
#pragma comment(linker, "/export:glTexCoord4d=C:\\Windows\\System32\\opengl32.glTexCoord4d,@289")
#pragma comment(linker, "/export:glTexCoord4dv=C:\\Windows\\System32\\opengl32.glTexCoord4dv,@290")
#pragma comment(linker, "/export:glTexCoord4f=C:\\Windows\\System32\\opengl32.glTexCoord4f,@291")
#pragma comment(linker, "/export:glTexCoord4fv=C:\\Windows\\System32\\opengl32.glTexCoord4fv,@292")
#pragma comment(linker, "/export:glTexCoord4i=C:\\Windows\\System32\\opengl32.glTexCoord4i,@293")
#pragma comment(linker, "/export:glTexCoord4iv=C:\\Windows\\System32\\opengl32.glTexCoord4iv,@294")
#pragma comment(linker, "/export:glTexCoord4s=C:\\Windows\\System32\\opengl32.glTexCoord4s,@295")
#pragma comment(linker, "/export:glTexCoord4sv=C:\\Windows\\System32\\opengl32.glTexCoord4sv,@296")
#pragma comment(linker, "/export:glTexCoordPointer=C:\\Windows\\System32\\opengl32.glTexCoordPointer,@297")
#pragma comment(linker, "/export:glTexEnvf=C:\\Windows\\System32\\opengl32.glTexEnvf,@298")
#pragma comment(linker, "/export:glTexEnvfv=C:\\Windows\\System32\\opengl32.glTexEnvfv,@299")
#pragma comment(linker, "/export:glTexEnvi=C:\\Windows\\System32\\opengl32.glTexEnvi,@300")
#pragma comment(linker, "/export:glTexEnviv=C:\\Windows\\System32\\opengl32.glTexEnviv,@301")
#pragma comment(linker, "/export:glTexGend=C:\\Windows\\System32\\opengl32.glTexGend,@302")
#pragma comment(linker, "/export:glTexGendv=C:\\Windows\\System32\\opengl32.glTexGendv,@303")
#pragma comment(linker, "/export:glTexGenf=C:\\Windows\\System32\\opengl32.glTexGenf,@304")
#pragma comment(linker, "/export:glTexGenfv=C:\\Windows\\System32\\opengl32.glTexGenfv,@305")
#pragma comment(linker, "/export:glTexGeni=C:\\Windows\\System32\\opengl32.glTexGeni,@306")
#pragma comment(linker, "/export:glTexGeniv=C:\\Windows\\System32\\opengl32.glTexGeniv,@307")
#pragma comment(linker, "/export:glTexImage1D=C:\\Windows\\System32\\opengl32.glTexImage1D,@308")
#pragma comment(linker, "/export:glTexImage2D=C:\\Windows\\System32\\opengl32.glTexImage2D,@309")
#pragma comment(linker, "/export:glTexParameterf=C:\\Windows\\System32\\opengl32.glTexParameterf,@310")
#pragma comment(linker, "/export:glTexParameterfv=C:\\Windows\\System32\\opengl32.glTexParameterfv,@311")
#pragma comment(linker, "/export:glTexParameteri=C:\\Windows\\System32\\opengl32.glTexParameteri,@312")
#pragma comment(linker, "/export:glTexParameteriv=C:\\Windows\\System32\\opengl32.glTexParameteriv,@313")
#pragma comment(linker, "/export:glTexSubImage2D=C:\\Windows\\System32\\opengl32.glTexSubImage2D,@314")
#pragma comment(linker, "/export:glTexSubImage1D=C:\\Windows\\System32\\opengl32.glTexSubImage1D,@315")
#pragma comment(linker, "/export:glTranslated=C:\\Windows\\System32\\opengl32.glTranslated,@316")
#pragma comment(linker, "/export:glTranslatef=C:\\Windows\\System32\\opengl32.glTranslatef,@317")
#pragma comment(linker, "/export:glVertex2d=C:\\Windows\\System32\\opengl32.glVertex2d,@318")
#pragma comment(linker, "/export:glVertex2dv=C:\\Windows\\System32\\opengl32.glVertex2dv,@319")
#pragma comment(linker, "/export:glVertex2f=C:\\Windows\\System32\\opengl32.glVertex2f,@320")
#pragma comment(linker, "/export:glVertex2fv=C:\\Windows\\System32\\opengl32.glVertex2fv,@321")
#pragma comment(linker, "/export:glVertex2i=C:\\Windows\\System32\\opengl32.glVertex2i,@322")
#pragma comment(linker, "/export:glVertex2iv=C:\\Windows\\System32\\opengl32.glVertex2iv,@323")
#pragma comment(linker, "/export:glVertex2s=C:\\Windows\\System32\\opengl32.glVertex2s,@324")
#pragma comment(linker, "/export:glVertex2sv=C:\\Windows\\System32\\opengl32.glVertex2sv,@325")
#pragma comment(linker, "/export:glVertex3d=C:\\Windows\\System32\\opengl32.glVertex3d,@326")
#pragma comment(linker, "/export:glVertex3dv=C:\\Windows\\System32\\opengl32.glVertex3dv,@327")
#pragma comment(linker, "/export:glVertex3f=Shim_glVertex3f,@328")
#pragma comment(linker, "/export:glVertex3fv=C:\\Windows\\System32\\opengl32.glVertex3fv,@329")
#pragma comment(linker, "/export:glVertex3i=C:\\Windows\\System32\\opengl32.glVertex3i,@330")
#pragma comment(linker, "/export:glVertex3iv=C:\\Windows\\System32\\opengl32.glVertex3iv,@331")
#pragma comment(linker, "/export:glVertex3s=C:\\Windows\\System32\\opengl32.glVertex3s,@332")
#pragma comment(linker, "/export:glVertex3sv=C:\\Windows\\System32\\opengl32.glVertex3sv,@333")
#pragma comment(linker, "/export:glVertex4d=C:\\Windows\\System32\\opengl32.glVertex4d,@334")
#pragma comment(linker, "/export:glVertex4dv=C:\\Windows\\System32\\opengl32.glVertex4dv,@335")
#pragma comment(linker, "/export:glVertex4f=C:\\Windows\\System32\\opengl32.glVertex4f,@336")
#pragma comment(linker, "/export:glVertex4fv=C:\\Windows\\System32\\opengl32.glVertex4fv,@337")
#pragma comment(linker, "/export:glVertex4i=C:\\Windows\\System32\\opengl32.glVertex4i,@338")
#pragma comment(linker, "/export:glVertex4iv=C:\\Windows\\System32\\opengl32.glVertex4iv,@339")
#pragma comment(linker, "/export:glVertex4s=C:\\Windows\\System32\\opengl32.glVertex4s,@340")
#pragma comment(linker, "/export:glVertex4sv=C:\\Windows\\System32\\opengl32.glVertex4sv,@341")
#pragma comment(linker, "/export:glVertexPointer=C:\\Windows\\System32\\opengl32.glVertexPointer,@342")
#pragma comment(linker, "/export:glViewport=C:\\Windows\\System32\\opengl32.glViewport,@343")
#pragma comment(linker, "/export:wglChoosePixelFormat=C:\\Windows\\System32\\opengl32.wglChoosePixelFormat,@344")
#pragma comment(linker, "/export:wglCopyContext=C:\\Windows\\System32\\opengl32.wglCopyContext,@345")
#pragma comment(linker, "/export:wglCreateContext=C:\\Windows\\System32\\opengl32.wglCreateContext,@346")
#pragma comment(linker, "/export:wglCreateLayerContext=C:\\Windows\\System32\\opengl32.wglCreateLayerContext,@347")
#pragma comment(linker, "/export:wglDeleteContext=C:\\Windows\\System32\\opengl32.wglDeleteContext,@348")
#pragma comment(linker, "/export:wglDescribeLayerPlane=C:\\Windows\\System32\\opengl32.wglDescribeLayerPlane,@349")
#pragma comment(linker, "/export:wglDescribePixelFormat=C:\\Windows\\System32\\opengl32.wglDescribePixelFormat,@350")
#pragma comment(linker, "/export:wglGetCurrentContext=C:\\Windows\\System32\\opengl32.wglGetCurrentContext,@351")
#pragma comment(linker, "/export:wglGetCurrentDC=C:\\Windows\\System32\\opengl32.wglGetCurrentDC,@352")
#pragma comment(linker, "/export:wglGetDefaultProcAddress=C:\\Windows\\System32\\opengl32.wglGetDefaultProcAddress,@353")
#pragma comment(linker, "/export:wglGetLayerPaletteEntries=C:\\Windows\\System32\\opengl32.wglGetLayerPaletteEntries,@354")
#pragma comment(linker, "/export:wglGetPixelFormat=C:\\Windows\\System32\\opengl32.wglGetPixelFormat,@355")
#pragma comment(linker, "/export:wglGetProcAddress=C:\\Windows\\System32\\opengl32.wglGetProcAddress,@356")
#pragma comment(linker, "/export:wglMakeCurrent=C:\\Windows\\System32\\opengl32.wglMakeCurrent,@357")
#pragma comment(linker, "/export:wglRealizeLayerPalette=C:\\Windows\\System32\\opengl32.wglRealizeLayerPalette,@358")
#pragma comment(linker, "/export:wglSetLayerPaletteEntries=C:\\Windows\\System32\\opengl32.wglSetLayerPaletteEntries,@359")
#pragma comment(linker, "/export:wglSetPixelFormat=C:\\Windows\\System32\\opengl32.wglSetPixelFormat,@360")
#pragma comment(linker, "/export:wglShareLists=C:\\Windows\\System32\\opengl32.wglShareLists,@361")
#pragma comment(linker, "/export:wglSwapBuffers=C:\\Windows\\System32\\opengl32.wglSwapBuffers,@362")
#pragma comment(linker, "/export:wglSwapLayerBuffers=C:\\Windows\\System32\\opengl32.wglSwapLayerBuffers,@363")
#pragma comment(linker, "/export:wglSwapMultipleBuffers=C:\\Windows\\System32\\opengl32.wglSwapMultipleBuffers,@364")
#pragma comment(linker, "/export:wglUseFontBitmapsA=C:\\Windows\\System32\\opengl32.wglUseFontBitmapsA,@365")
#pragma comment(linker, "/export:wglUseFontBitmapsW=C:\\Windows\\System32\\opengl32.wglUseFontBitmapsW,@366")
#pragma comment(linker, "/export:wglUseFontOutlinesA=C:\\Windows\\System32\\opengl32.wglUseFontOutlinesA,@367")
#pragma comment(linker, "/export:wglUseFontOutlinesW=C:\\Windows\\System32\\opengl32.wglUseFontOutlinesW,@368")
//*/