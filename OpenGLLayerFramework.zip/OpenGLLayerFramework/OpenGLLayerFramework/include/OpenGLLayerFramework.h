﻿#pragma once

typedef void (*GenericGLFunc)();

#define OGL_MODULE_NAME		"opengl32.dll"
#define GLFW_MODULE_NAME	"glfw3.dll"
#define GLEW_MODULE_NAME	"glew32.dll"

struct LayerFunction
{
	GenericGLFunc	pFN_HookedFunc;
	GenericGLFunc	pFN_NextFunc;
};

typedef const char** (*Layer_GetFunctionNames)(int*);
typedef GenericGLFunc(*Layer_GetHookedProcAddress)(const char*, GenericGLFunc);
typedef void(*Layer_SetPatchUnPatchFunction)(void* pFn_Patch, void* pFn_UnPatch);
typedef GenericGLFunc(*Layer_SetCallNextInChain)(int32_t iModuleID, void* pFn_CallNextInChain);