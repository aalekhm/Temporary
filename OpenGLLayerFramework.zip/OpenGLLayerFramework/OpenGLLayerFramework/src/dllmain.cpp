﻿#include <Windows.h>
#include <map>
#include <vector>
#include <string>
#include <iostream>
#include <filesystem>
#include <DbgHelp.h>
#include <tlhelp32.h>
#include <MinHook.h>
#include <GL/GL.h>
#include "OpenGLLayerFramework.h"

extern "C"
{
	__declspec(dllexport) void DummyExportFunc()
	{
	}
}

namespace FS = std::filesystem;

struct SLoadedModule
{
	std::string     sModuleName;
	std::string     sExecutableName;
};

HMODULE												g_hOGLModule;
HMODULE												g_hGLFWModule;
std::map<std::string, std::vector<LayerFunction>>	GL_LAYERS;
std::vector<SLoadedModule>							g_vLoadedModules;

#define STEAL_BYTE_COUNT 14
struct HookInfo
{
    std::string         sFunctionName;
    PROC                pFn_OriglProcAddress            = nullptr;
    void*               pFn_HookFunction                = nullptr;
    BYTE*               pTrampoline_StolenOrigBytes     = nullptr;
};

std::map<std::string, HookInfo>     g_HookInfoMap;

// Writes an absolute jump [mov rax, dst; jmp rax]
void WriteAbsoluteJump(BYTE* src, void* dst)
{
    DWORD oldProtect;
    VirtualProtect(src, 14, PAGE_EXECUTE_READWRITE, &oldProtect);

    src[0] = 0x48; // REX.W prefix
    src[1] = 0xB8; // MOV RAX, imm64
    *(void**)(src + 2) = dst;

    src[10] = 0xFF; // JMP RAX
    src[11] = 0xE0;

    src[12] = 0x90; // NOP
    src[13] = 0x90;

    VirtualProtect(src, 14, oldProtect, &oldProtect);
}

void UnPatch(const std::string& sFunctionName)
{
	const auto hookInfoItr = g_HookInfoMap.find(sFunctionName);
	if (hookInfoItr != g_HookInfoMap.end())
	{
		auto& hookInfo = hookInfoItr->second;

		// Write the stolen bytes to original address & call original
		{
			DWORD oldProtect;
			VirtualProtect( hookInfo.pFn_OriglProcAddress, 
							STEAL_BYTE_COUNT, 
							PAGE_EXECUTE_READWRITE, 
							&oldProtect);
			memcpy( hookInfo.pFn_OriglProcAddress, 
					hookInfo.pTrampoline_StolenOrigBytes, 
					STEAL_BYTE_COUNT);
			VirtualProtect( hookInfo.pFn_OriglProcAddress, 
							STEAL_BYTE_COUNT, 
							oldProtect, &oldProtect);
		}
	}
}

void Patch(const std::string& sFunctionName)
{
	const auto hookInfoItr = g_HookInfoMap.find(sFunctionName);
	if (hookInfoItr != g_HookInfoMap.end())
	{
		auto& hookInfo = hookInfoItr->second;

		// Patch original again for future calls
		WriteAbsoluteJump(  (BYTE*)hookInfo.pFn_OriglProcAddress,
							hookInfo.pFn_HookFunction);
	}
}

// Our detour
int WINAPI Hooked_MessageBoxW(HWND hWnd, LPCWSTR lpText, LPCWSTR lpCaption, UINT uType)
{
    int iReturn = 0;

	UnPatch("MessageBoxW");
	{
		// Call to Original
		iReturn = MessageBoxW(hWnd, L"!!! Hooked !!!", lpCaption, uType);
    }
	Patch("MessageBoxW");

    return iReturn;
}

// Creates trampoline: copies prologue + jump back
BYTE* CreateTrampoline(BYTE* pTarget, size_t iStealBtyeCount)
{
    BYTE* pTramp = (BYTE*)VirtualAlloc(  NULL, 
                                        iStealBtyeCount, 
                                        MEM_COMMIT | MEM_RESERVE, 
                                        PAGE_EXECUTE_READWRITE);

    // Steal original instructions
    DWORD oldProtect;
    VirtualProtect( pTramp, 
                    iStealBtyeCount, 
                    PAGE_EXECUTE_READWRITE, 
                    &oldProtect);
    memcpy( pTramp, 
            pTarget, 
            iStealBtyeCount);
    VirtualProtect( pTramp, 
                    iStealBtyeCount, 
                    oldProtect, &oldProtect);

    return pTramp;
}

// Detour Attach
void SimpleDetourAttach(std::string sFunctionName, PROC pFnOrigProcAddress, void* pHookFunction)
{
    const auto hookInfoItr = g_HookInfoMap.find(sFunctionName);
    if (hookInfoItr == g_HookInfoMap.end())
    {
        g_HookInfoMap[sFunctionName].pFn_OriglProcAddress   = pFnOrigProcAddress;
        g_HookInfoMap[sFunctionName].pFn_HookFunction       = pHookFunction;

        // Save trampoline for calling original
        BYTE* pTrampoline_StolenOrigBytes = nullptr;
        pTrampoline_StolenOrigBytes = CreateTrampoline((BYTE*)pFnOrigProcAddress, STEAL_BYTE_COUNT);

        g_HookInfoMap[sFunctionName].pTrampoline_StolenOrigBytes = pTrampoline_StolenOrigBytes;

        // Patch Original
        WriteAbsoluteJump((BYTE*)pFnOrigProcAddress, pHookFunction);
    }
}

void SimpleDetourDetach(std::string sFunctionName)
{
    const auto hookInfoItr = g_HookInfoMap.find(sFunctionName);
    if (hookInfoItr != g_HookInfoMap.end())
    {
        auto& hookInfo = hookInfoItr->second;

        PROC pFnOrigProcAddress             = hookInfo.pFn_OriglProcAddress;
        BYTE* pTrampoline_StolenOrigBytes   = hookInfo.pTrampoline_StolenOrigBytes;
        {
            DWORD oldProtect;
            VirtualProtect( pFnOrigProcAddress, 
                            STEAL_BYTE_COUNT, 
                            PAGE_EXECUTE_READWRITE, 
                            &oldProtect);
            memcpy( pFnOrigProcAddress, 
                    pTrampoline_StolenOrigBytes, 
                    STEAL_BYTE_COUNT);
            VirtualProtect( pFnOrigProcAddress, 
                            STEAL_BYTE_COUNT, 
                            oldProtect, 
                            &oldProtect);

            VirtualFree(    pFnOrigProcAddress, 
                            STEAL_BYTE_COUNT, 
                            MEM_RELEASE);
        }
    }
}

std::vector<SLoadedModule> ListLoadedModules(DWORD processID)
{
    std::vector<SLoadedModule> vLoadedModules;

    HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, processID);
    if (hSnapshot == INVALID_HANDLE_VALUE)
    {
        std::cerr << "Failed to create snapshot." << std::endl;
        return vLoadedModules;
    }

    MODULEENTRY32 me32;
    me32.dwSize = sizeof(MODULEENTRY32);

    if (Module32First(hSnapshot, &me32))
    {
        do
        {
            std::wstring swModule   = me32.szModule;
            std::wstring swExePath  = me32.szExePath;

            vLoadedModules.push_back({  std::string(swModule.begin(), swModule.end()),
                                        std::string(swExePath.begin(), swExePath.end())
                                    });
        } while (Module32Next(hSnapshot, &me32));
    }
    else
    {
        std::cerr << "Failed to enumerate modules." << std::endl;
    }

    CloseHandle(hSnapshot);

    return vLoadedModules;
}

std::string GetModuleForFunction(const char* sFuncName)
{
	std::string sModuleName;
	if (sFuncName != nullptr && strlen(sFuncName) > 0)
	{
		GenericGLFunc pFn = nullptr;
		if (sFuncName != nullptr && strlen(sFuncName) > 0)
		{
			pFn = (GenericGLFunc)wglGetProcAddress(sFuncName);
		}

		for (const auto& loadedModule : g_vLoadedModules)
		{
			std::string sDLLName = loadedModule.sModuleName;
			const char* ss = sDLLName.c_str();
			HMODULE hMod = GetModuleHandleA(sDLLName.c_str());
			if (!hMod) 
			{
				hMod = LoadLibraryA(sDLLName.c_str());
			}
		}
	}

	return sModuleName;
}

void PrintWhereIs(HMODULE hModule)
{
	char sPath[MAX_PATH];
	DWORD iLength = GetModuleFileNameA(hModule, sPath, MAX_PATH);
	if (iLength > 0 && iLength < MAX_PATH)
	{
		std::cout << sPath << std::endl;
	}
}

bool HookIAT(	const char* sModuleName,
				const char* sFunctionName,
				void*		pFN_NewFunc)
{
	bool bHookSuccessful = false;
	HMODULE hCurrExecutableModule	= GetModuleHandle(NULL);										// Current Executable Handle.
	HMODULE hHookModule				= GetModuleHandleA(sModuleName);								// Module to Hook.
	PROC	pFN_HookFunc			= (PROC)GetProcAddress((HMODULE)hHookModule, sFunctionName);	// Address of function to hook.

	PrintWhereIs(hHookModule);

	ULONG iSize;
	PIMAGE_IMPORT_DESCRIPTOR pImageImportDescriptor = (PIMAGE_IMPORT_DESCRIPTOR)ImageDirectoryEntryToData(	hCurrExecutableModule,
																											true,
																											IMAGE_DIRECTORY_ENTRY_IMPORT,
																											&iSize);

	for (; pImageImportDescriptor->Name; pImageImportDescriptor++)
	{
		const char* pDLLName = (const char*)((BYTE*)hCurrExecutableModule + pImageImportDescriptor->Name);
		if (_stricmp(pDLLName, sModuleName) == 0)
		{
			// Import Address Table Hooking
			// https://medium.com/@s12deff/import-address-table-hooking-68d519a1da43
			PIMAGE_THUNK_DATA pImageImportAddressTable	= (PIMAGE_THUNK_DATA)((BYTE*)hCurrExecutableModule + pImageImportDescriptor->FirstThunk);
			PIMAGE_THUNK_DATA pImageImportNameTable		= (PIMAGE_THUNK_DATA)((BYTE*)hCurrExecutableModule + pImageImportDescriptor->OriginalFirstThunk);

			// Search by IAT
			/*
			for (; pImageImportAddressTable->u1.Function; pImageImportAddressTable++)
			{
				std::cout << "searching " << sFunctionName << std::endl;
			
				PROC* pFN_Func = (PROC*)&pImageImportAddressTable->u1.Function;
				if (*pFN_Func == pFN_HookFunc)
				{
					DWORD iOLD_PAGE_ACCESS;
					VirtualProtect(pFN_Func, sizeof(void*), PAGE_EXECUTE_READWRITE, &iOLD_PAGE_ACCESS);
					{
						*pFN_Func = (PROC)pFN_NewFunc;
					}
					VirtualProtect(pFN_Func, sizeof(void*), iOLD_PAGE_ACCESS, &iOLD_PAGE_ACCESS);
			
					std::cout << "HOOKED!" << std::endl;
			
					return;
				}
			}
			*/

			// Search by INT
			for (; pImageImportNameTable->u1.AddressOfData; pImageImportNameTable++, pImageImportAddressTable++)
			{
				PIMAGE_IMPORT_BY_NAME pImportByName = (PIMAGE_IMPORT_BY_NAME)((DWORD_PTR)hCurrExecutableModule + pImageImportNameTable->u1.AddressOfData);

				std::cout << "searching for " << sFunctionName << ", found " << pImportByName->Name << std::endl;

				if (std::string(pImportByName->Name) == sFunctionName)
				{
					PROC* pFN_Func = (PROC*)&pImageImportAddressTable->u1.Function;

					DWORD iOLD_PAGE_ACCESS;
					VirtualProtect(pFN_Func, sizeof(DWORD_PTR), PAGE_READWRITE, &iOLD_PAGE_ACCESS);
					*pFN_Func = (PROC)pFN_NewFunc;
					VirtualProtect(pFN_Func, sizeof(DWORD_PTR), iOLD_PAGE_ACCESS, &iOLD_PAGE_ACCESS);

					bHookSuccessful = true;
					std::cout << "HOOKED!" << std::endl;

					break;
				}
			}
		}
	}

	return bHookSuccessful;
}

GenericGLFunc GetOriginal_OGLFuncAddress(const char* pFuncName)
{
	GenericGLFunc pFn = nullptr;
	if (pFuncName != nullptr && strlen(pFuncName) > 0)
	{
		pFn = (GenericGLFunc)GetProcAddress(g_hOGLModule, pFuncName);
	}

	return pFn;
}

GenericGLFunc GetOriginal_GLFWFuncAddress(const char* pFuncName)
{
	GenericGLFunc pFn = nullptr;
	if (pFuncName != nullptr && strlen(pFuncName) > 0)
	{
		pFn = (GenericGLFunc)GetProcAddress(g_hGLFWModule, pFuncName);
	}

	return pFn;
}

GenericGLFunc GetOriginal_GLEWFuncAddress(const char* pFuncName)
{
	GenericGLFunc pFn = nullptr;
	if (pFuncName != nullptr && strlen(pFuncName) > 0)
	{
		pFn = (GenericGLFunc)wglGetProcAddress(pFuncName);
	}

	return pFn;
}

GenericGLFunc GetOriginal_GLFuncAddress(const char* pFuncName)
{
	GenericGLFunc pFn = nullptr;
							pFn = GetOriginal_OGLFuncAddress(pFuncName);
	if (pFn == nullptr)		pFn = GetOriginal_GLFWFuncAddress(pFuncName);
	if (pFn == nullptr)		pFn = GetOriginal_GLEWFuncAddress(pFuncName);

	return pFn;
}


void LoadLayers()
{
	char*	pLayerEnvironmentPath = nullptr;
	size_t	iEnvironmentPathLength = -1;

	errno_t err = _dupenv_s(&pLayerEnvironmentPath, &iEnvironmentPathLength, "GL_LAYERS_PATH");
	if (iEnvironmentPathLength < 0)
	{
		std::cerr << "GL_LAYERS_PATH not set." << std::endl;
		return;
	}

	std::string				sLayerEnvironmentPath(pLayerEnvironmentPath);
	std::vector<HMODULE>	hLoadedLayerModules;

	for (const auto& dirEntry : FS::directory_iterator(sLayerEnvironmentPath))
	{
		if (dirEntry.path().extension() == ".dll")
		{
			std::string sModuleName = dirEntry.path().string();
			HMODULE hLayerModule = LoadLibraryA(sModuleName.c_str());
			if (hLayerModule)
			{
				hLoadedLayerModules.push_back(hLayerModule);
			}
		}
	}

	for (const auto& hLayerModule : hLoadedLayerModules)
	{
		auto PFN_Layer_GetFunctionNames			= (Layer_GetFunctionNames)			GetProcAddress(hLayerModule, "OGLLayer_GetFunctionNames");
		auto PFN_Layer_GetHookedProcAddress		= (Layer_GetHookedProcAddress)		GetProcAddress(hLayerModule, "OGLLayer_GetHookedProcAddress");
		auto PFN_Layer_SetPatchUnPatchFunction  = (Layer_SetPatchUnPatchFunction)	GetProcAddress(hLayerModule, "OGLLayer_SetPatchUnPatchFunctions");

		if (PFN_Layer_GetFunctionNames && PFN_Layer_GetHookedProcAddress)
		{
			int iFuncCount = 0;
			const char** pFunctionNames = PFN_Layer_GetFunctionNames(&iFuncCount);
			for (int i = 0; i < iFuncCount; ++i)
			{
				std::string sFunctionName = pFunctionNames[i];

				GenericGLFunc pFnNextProcAddress =	GL_LAYERS[sFunctionName].empty()
													? GetOriginal_GLFuncAddress(sFunctionName.c_str())
													: GL_LAYERS[sFunctionName].back().pFN_HookedFunc;

				GenericGLFunc pFnHookedFuncProcAddress = PFN_Layer_GetHookedProcAddress(sFunctionName.c_str(), pFnNextProcAddress);
				PFN_Layer_SetPatchUnPatchFunction(&Patch, &UnPatch);

				//bool						bHookSuccessful = HookIAT(OGL_MODULE_NAME, sFunctionName.c_str(), pFnFuncProcAddress);
				//if(!bHookSuccessful)		bHookSuccessful = HookIAT(GLFW_MODULE_NAME, sFunctionName.c_str(), pFnFuncProcAddress);
				//else if (!bHookSuccessful)	bHookSuccessful = HookIAT(GLEW_MODULE_NAME, sFunctionName.c_str(), pFnFuncProcAddress);

                //SimpleDetourAttach( sFunctionName,
                //                    (PROC)pFnNextProcAddress,
                //                    pFnFuncProcAddress);

				GL_LAYERS[sFunctionName].push_back( { pFnHookedFuncProcAddress, pFnNextProcAddress } );
			}
		}
	}

	for (auto& vLayerFuncs : GL_LAYERS)
	{	
		std::string sFunctionName = vLayerFuncs.first;
		auto& layerFunc = vLayerFuncs.second[0];
        SimpleDetourAttach( sFunctionName,
                            (PROC)layerFunc.pFN_NextFunc,
                            layerFunc.pFN_HookedFunc);

	}
}

//extern "C" __declspec(dllexport) GenericGLFunc GetGLFunction(const char* pFuncName)
//{
//	auto it = GL_LAYERS.find(pFuncName);
//	if (it != GL_LAYERS.end()
//		&&
//		!it->second.empty()
//	) {
//		return it->second.back().pFN_Func;
//	}
//
//	return GetOriginalOpenGLFuncAddress(pFuncName);
//}

// A safe helper: checks if memory at address is readable
bool IsReadable(void* addr, size_t size = 6) {
    MEMORY_BASIC_INFORMATION mbi;
    if (VirtualQuery(addr, &mbi, sizeof(mbi)) == 0)
        return false;
    DWORD protect = mbi.Protect & 0xFF;
    if (protect == PAGE_NOACCESS || protect == PAGE_EXECUTE_WRITECOPY)
        return false;
    return (mbi.State == MEM_COMMIT);
}

// Minimal implementation of detour_skip_jmp
BYTE* detour_skip_jmp(BYTE* code) {
    while (true) {
        if (!IsReadable(code))
            return code; // bail out

        // Check for "jmp rel32"  (E9 offset)
        if (code[0] == 0xE9) {
            int32_t rel = *reinterpret_cast<int32_t*>(code + 1);
            code = code + 5 + rel; // target = next instruction + rel32
            continue;
        }

        // Check for "jmp [disp32]" (FF 25 disp32)
        if (code[0] == 0xFF && code[1] == 0x25) {
            int32_t disp = *reinterpret_cast<int32_t*>(code + 2);
            BYTE** pTarget = reinterpret_cast<BYTE**>(code + 6 + disp);
            if (!IsReadable(pTarget, sizeof(void*)))
                return code;
            code = *pTarget; // follow pointer
            continue;
        }

        // On x64: sometimes "mov rax, imm64; jmp rax"
        if (code[0] == 0x48 && code[1] == 0xB8) {
            void* target = *reinterpret_cast<void**>(code + 2);
            if (code[10] == 0xFF && code[11] == 0xE0) {
                code = reinterpret_cast<BYTE*>(target);
                continue;
            }
        }

        // Not a known jump pattern → done
        break;
    }
    return code;
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved)
{
	if (ul_reason_for_call == DLL_PROCESS_ATTACH)
	{
		g_hOGLModule		= LoadLibraryA(OGL_MODULE_NAME);
		g_hGLFWModule		= LoadLibraryA(GLFW_MODULE_NAME);

		/*
        {
            MessageBoxW(NULL, L"Original", L"Demo", MB_OK);

            PROC pProcAddress = (PROC)GetProcAddress(GetModuleHandleW(L"user32.dll"), "MessageBoxW");
            SimpleDetourAttach( "MessageBoxW",
                                pProcAddress,
                                &Hooked_MessageBoxW);

            MessageBoxW(NULL, L"Original", L"Demo", MB_OK);
            MessageBoxW(NULL, L"Original", L"Demo", MB_OK);

            SimpleDetourDetach("MessageBoxW");
            MessageBoxW(NULL, L"Original", L"Demo", MB_OK);
        }
		*/

        /*
		{
			g_vLoadedModules	= ListLoadedModules(GetCurrentProcessId());
			std::cout << GetModuleForFunction("glCreateShader");

			HMODULE user32 = LoadLibraryA("user32.dll");
			//void* pMsgBox = GetProcAddress(user32, "MessageBoxA");
			void* pMsgBox = wglGetProcAddress("glCreateShader");
			std::cout << "MessageBoxA export address: " << pMsgBox << "\n";

			realEntry_glCreateShader = (PROC*)detour_skip_jmp(reinterpret_cast<BYTE*>(pMsgBox));
			std::cout << "Resolved real implementation: " << (void*)realEntry_glCreateShader << "\n";

			void* pHooked = Hooked_g_pFnNext_glCreateShader;
			SimpleDetourAttach((void**)&orig_glCreateShader, (BYTE*)realEntry_glCreateShader, pHooked);

			//DWORD iOLD_PAGE_ACCESS;
			//VirtualProtect(realEntry, sizeof(DWORD_PTR), PAGE_READWRITE, &iOLD_PAGE_ACCESS);
			//*realEntry = (PROC)pHooked;
			//VirtualProtect(realEntry, sizeof(DWORD_PTR), iOLD_PAGE_ACCESS, &iOLD_PAGE_ACCESS);

			// Call it normally to confirm it's safe
			//MessageBoxA_t fn = reinterpret_cast<MessageBoxA_t>(realEntry);
			//fn(NULL, "Hello from resolved entry!", "Detour Skip JMP", MB_OK);
			//
			glCreateShader_t fn = reinterpret_cast<glCreateShader_t>(realEntry_glCreateShader);
			GLuint vs = fn(0x8B31);
			vs = fn(0x8B31);
			vs = fn(0x8B31);
			bool b = true;
		}
        */

		LoadLayers();
	}

	return TRUE;
}