
#include <stdlib.h>
#include "Engine/GameEngine.h"
#include "Common/RandomAccessFile.h"
#include <iostream>
#include <vector>
#include <Windows.h>
#include <tlhelp32.h>

#define USE_PROGRAMMABLE_PIPELINE 0
#define OPENGL32_PATH   "C:\\WINDOWS\\SYSTEM32\\OPENGL32.dll"

struct SLoadedModules
{
    std::string     sModuleName;
    std::string     sExecutableName;
};

std::vector<SLoadedModules> ListLoadedModules(DWORD processID)
{
    std::vector<SLoadedModules> vLoadedModules;

    HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, processID);
    if (hSnapshot == INVALID_HANDLE_VALUE)
    {
        std::cerr << "Failed to create snapshot." << std::endl;
        return vLoadedModules;
    }

    MODULEENTRY32 me32;
    me32.dwSize = sizeof(MODULEENTRY32);

    if (Module32First(hSnapshot, &me32))
    {
        do
        {
            std::wstring swModule   = me32.szModule;
            std::wstring swExePath  = me32.szExePath;

            vLoadedModules.push_back({  std::string(swModule.begin(), swModule.end()),
                                        std::string(swExePath.begin(), swExePath.end())
                                    });
        } while (Module32Next(hSnapshot, &me32));
    }
    else
    {
        std::cerr << "Failed to enumerate modules." << std::endl;
    }

    CloseHandle(hSnapshot);

    return vLoadedModules;
}

bool IsValidOpenGL()
{
    bool bIsOpenGLFromSystem32 = false;
    DWORD pid = GetCurrentProcessId();
    std::vector<SLoadedModules> vLoadedModules = ListLoadedModules(pid);
    for (auto sLoadedModule : vLoadedModules)
    {
        if ((strcmp(sLoadedModule.sExecutableName.c_str(), OPENGL32_PATH) == 0))
        {
            bIsOpenGLFromSystem32 = true;
            break;
        }
    }

    return bIsOpenGLFromSystem32;
}

#if (USE_PROGRAMMABLE_PIPELINE == 1)
bool checkShaderLinkStatus(GLuint iSharedID)
{
    int iSuccess;
    char infoLog[512];
    glGetProgramiv(iSharedID, GL_LINK_STATUS, &iSuccess);
    if (iSuccess == 0)
    {
        glGetShaderInfoLog(iSharedID, 512, NULL, infoLog);
        std::cout << "checkShaderCompileStatus COMPILATION_FAILED\n" << infoLog << std::endl;
    }

    return (iSuccess > 0);
}

bool checkShaderCompileStatus(GLuint iSharedID, GLuint iStatusType)
{
    int iSuccess;
    char infoLog[512];
    glGetShaderiv(iSharedID, iStatusType, &iSuccess);
    if (iSuccess == 0)
    {
        glGetShaderInfoLog(iSharedID, 512, NULL, infoLog);
        std::cout << "checkShaderCompileStatus COMPILATION_FAILED\n" << infoLog << std::endl;
    }

    return (iSuccess > 0);
}

bool compileShader(const char* sVertexShaderFile, int& iShaderID, int iShaderType)
{
    std::unique_ptr<RandomAccessFile> pRaf = std::make_unique<RandomAccessFile>();
    std::string sVertexShaderSrc = pRaf->readAll(sVertexShaderFile);
    const char* sVertexShaderSrc_cstr = sVertexShaderSrc.c_str();
    {
        iShaderID = glCreateShader(iShaderType);
        glShaderSource(iShaderID, 1, &sVertexShaderSrc_cstr, NULL);
        glCompileShader(iShaderID);

        return checkShaderCompileStatus(iShaderID, GL_COMPILE_STATUS);
    }
}

bool linkShaders(GLuint iVertexShaderID, GLuint iFragShaderID, GLuint& iShaderProgramID)
{
    // link shaders
    iShaderProgramID = glCreateProgram();
    glAttachShader(iShaderProgramID, iVertexShaderID);
    glAttachShader(iShaderProgramID, iFragShaderID);
    glLinkProgram(iShaderProgramID);

    return checkShaderLinkStatus(iShaderProgramID);
}

bool initShaders(const char* sVertexShaderFile, const char* sFragShaderFile, GLuint& iSimpleShaderProgramIDOUT)
{
    bool bReturn = false;

    // build and compile our shader program
    int iSimpleVertexShaderID, iSimpleFragShaderID;
    if (compileShader(sVertexShaderFile, iSimpleVertexShaderID, GL_VERTEX_SHADER))
    {
        if (compileShader(sFragShaderFile, iSimpleFragShaderID, GL_FRAGMENT_SHADER))
        {
            if (linkShaders(iSimpleVertexShaderID, iSimpleFragShaderID, iSimpleShaderProgramIDOUT))
            {
                bReturn = true;
            }
        }
    }

    glDeleteShader(iSimpleVertexShaderID);
    glDeleteShader(iSimpleFragShaderID);

    return bReturn;
}
#endif

class MyEngine : public GameEngine
{
	public:
		MyEngine()
		{
			createWindow(480, 320, "GLApp");
		}

		virtual void onCreate()
		{
#if (USE_PROGRAMMABLE_PIPELINE == 1)
            if (initShaders("..\\Content\\simpleVert.txt", 
                            "..\\Content\\simpleFrag.txt", 
                            m_iSimpleShaderProgramID)
            ) {
                setupScene();
            }
#else
            if (IsValidOpenGL())
            {
                LoadLibraryA("OpenGLLayerFramework.dll");
                setupScene();
            }
            else
            {
                MessageBoxW(NULL, L"Invalid Opengl32.dll", L"Error", MB_OK);
                exit(1);
            }
#endif
		}

		virtual void onUpdate(uint32_t iDeltaTimeMs, uint64_t lElapsedTime)
		{
            updateScene(iDeltaTimeMs, lElapsedTime);
		}

		virtual void onDestroy()
		{

		}

	protected:
        void setupScene()
        {
#if (USE_PROGRAMMABLE_PIPELINE == 1)
            float aVertices[] = 
            {
                // Positions        // Colors
                -0.5f, -0.5f, 0.0f, 1.0f, 0.0f, 0.0f,   // Bottom-left (Red)
                 0.5f, -0.5f, 0.0f, 0.0f, 1.0f, 0.0f,   // Bottom-right (Green)
                 0.0f,  0.5f, 0.0f, 0.0f, 0.0f, 1.0f    // Top (Blue)
            };

            unsigned int iVBO;
            glGenVertexArrays(1, &m_iVAO);
            glGenBuffers(1, &iVBO);

            glBindVertexArray(m_iVAO);

            glBindBuffer(GL_ARRAY_BUFFER, iVBO);
            glBufferData(GL_ARRAY_BUFFER, sizeof(aVertices), aVertices, GL_STATIC_DRAW);

            // Position attribute
            glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
            glEnableVertexAttribArray(0);

            // Color attribute
            glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)(3 * sizeof(float)));
            glEnableVertexAttribArray(1);
#else
            m_fXPosition = 0.0;
            m_iDirection = 1;
            m_iSwayRate = 1.0f/5000;

            // Bottom-left
            m_vTriangleVertices.push_back(m_fXPosition - 0.5f);
            m_vTriangleVertices.push_back(-0.5f);
            m_vTriangleVertices.push_back(0.0f);
            // Bottom-right
            m_vTriangleVertices.push_back(m_fXPosition + 0.5f);
            m_vTriangleVertices.push_back(-0.5f);
            m_vTriangleVertices.push_back(0.0f);
            // Top
            m_vTriangleVertices.push_back(m_fXPosition);
            m_vTriangleVertices.push_back(0.5f);
            m_vTriangleVertices.push_back(0.0f);

            // Bottom-left
            m_vTriangleVertexColours.push_back(1.0f);
            m_vTriangleVertexColours.push_back(0.0f);
            m_vTriangleVertexColours.push_back(0.0f);
            // Bottom-right
            m_vTriangleVertexColours.push_back(0.0f);
            m_vTriangleVertexColours.push_back(1.0f);
            m_vTriangleVertexColours.push_back(0.0f);
            // Top
            m_vTriangleVertexColours.push_back(0.0f);
            m_vTriangleVertexColours.push_back(0.0f);
            m_vTriangleVertexColours.push_back(1.0f);
#endif
        }

        void updateScene(uint32_t iDeltaTimeMs, uint64_t lElapsedTime)
        {
#if (USE_PROGRAMMABLE_PIPELINE == 1)
            glUseProgram(m_iSimpleShaderProgramID);
            glBindVertexArray(m_iVAO);
            glDrawArrays(GL_TRIANGLES, 0, 3);
#else
            switch (m_iDirection)
            {
                case 1:
                    if (m_fXPosition >= 0.5f)   m_iDirection = -1;
                break;
                case -1:
                    if (m_fXPosition <= -0.5f)   m_iDirection = 1;
                break;
            }
            m_fXPosition += (iDeltaTimeMs * m_iSwayRate) * m_iDirection;

            glClearColor(0.25f, 0.25f, 0.25f, 1.0f);
            glClear(GL_COLOR_BUFFER_BIT);

            glBegin(GL_TRIANGLES);
            {
                glVertex3f(m_fXPosition - 0.5f, m_vTriangleVertices[1], m_vTriangleVertices[2]);
                glColor3f(m_vTriangleVertexColours[0], m_vTriangleVertexColours[1], m_vTriangleVertexColours[2]);

                glVertex3f(m_fXPosition + 0.5f, m_vTriangleVertices[4], m_vTriangleVertices[5]);
                glColor3f(m_vTriangleVertexColours[3], m_vTriangleVertexColours[4], m_vTriangleVertexColours[5]);

                glVertex3f(m_fXPosition, m_vTriangleVertices[7], m_vTriangleVertices[8]);
                glColor3f(m_vTriangleVertexColours[6], m_vTriangleVertexColours[7], m_vTriangleVertexColours[8]);
            }
            glEnd();
#endif
        }
	private:
#if (USE_PROGRAMMABLE_PIPELINE == 1)
        GLuint      m_iSimpleShaderProgramID = -1;
        GLuint      m_iVAO;
#else
        std::vector<GLfloat>    m_vTriangleVertices;
        std::vector<GLfloat>    m_vTriangleVertexColours;

        float                   m_fXPosition;
        int                     m_iDirection;
        float                   m_iSwayRate;
#endif
};

int main(int argc, char** argv)
{
	MyEngine me;

	exit(EXIT_SUCCESS);
}
