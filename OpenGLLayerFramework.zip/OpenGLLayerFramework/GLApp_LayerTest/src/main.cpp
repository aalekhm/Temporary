
#include <stdlib.h>
#include "Engine/GameEngine.h"
#include "Common/RandomAccessFile.h"
#include <iostream>
#include <vector>
#include <Windows.h>
#include <tlhelp32.h>

#define USE_PROGRAMMABLE_PIPELINE   0
#define USE_TEXTURE_SCENE           0
#define OPENGL32_PATH   "C:\\WINDOWS\\SYSTEM32\\OPENGL32.dll"

struct SLoadedModules
{
    std::string     sModuleName;
    std::string     sExecutableName;
};

std::vector<SLoadedModules> ListLoadedModules(DWORD processID)
{
    std::vector<SLoadedModules> vLoadedModules;

    HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, processID);
    if (hSnapshot == INVALID_HANDLE_VALUE)
    {
        std::cerr << "Failed to create snapshot." << std::endl;
        return vLoadedModules;
    }

    MODULEENTRY32 me32;
    me32.dwSize = sizeof(MODULEENTRY32);

    if (Module32First(hSnapshot, &me32))
    {
        do
        {
            std::wstring swModule   = me32.szModule;
            std::wstring swExePath  = me32.szExePath;

            vLoadedModules.push_back({  std::string(swModule.begin(), swModule.end()),
                                        std::string(swExePath.begin(), swExePath.end())
                                    });
        } while (Module32Next(hSnapshot, &me32));
    }
    else
    {
        std::cerr << "Failed to enumerate modules." << std::endl;
    }

    CloseHandle(hSnapshot);

    return vLoadedModules;
}

bool IsValidOpenGL()
{
    bool bIsOpenGLFromSystem32 = false;
    DWORD pid = GetCurrentProcessId();
    std::vector<SLoadedModules> vLoadedModules = ListLoadedModules(pid);
    for (auto sLoadedModule : vLoadedModules)
    {
        if ((strcmp(sLoadedModule.sExecutableName.c_str(), OPENGL32_PATH) == 0))
        {
            bIsOpenGLFromSystem32 = true;
            break;
        }
    }

    return bIsOpenGLFromSystem32;
}

#if (USE_PROGRAMMABLE_PIPELINE == 1)
bool checkShaderLinkStatus(GLuint iSharedID)
{
    int iSuccess;
    char infoLog[512];
    glGetProgramiv(iSharedID, GL_LINK_STATUS, &iSuccess);
    if (iSuccess == 0)
    {
        glGetShaderInfoLog(iSharedID, 512, NULL, infoLog);
        std::cout << "checkShaderCompileStatus COMPILATION_FAILED\n" << infoLog << std::endl;
    }

    return (iSuccess > 0);
}

bool checkShaderCompileStatus(GLuint iSharedID, GLuint iStatusType)
{
    int iSuccess;
    char infoLog[512];
    glGetShaderiv(iSharedID, iStatusType, &iSuccess);
    if (iSuccess == 0)
    {
        glGetShaderInfoLog(iSharedID, 512, NULL, infoLog);
        std::cout << "checkShaderCompileStatus COMPILATION_FAILED\n" << infoLog << std::endl;
    }

    return (iSuccess > 0);
}

bool compileShader(const char* sVertexShaderFile, int& iShaderID, int iShaderType)
{
    std::unique_ptr<RandomAccessFile> pRaf = std::make_unique<RandomAccessFile>();
    std::string sVertexShaderSrc = pRaf->readAll(sVertexShaderFile);
    const char* sVertexShaderSrc_cstr = sVertexShaderSrc.c_str();
    {
        iShaderID = glCreateShader(iShaderType);
        glShaderSource(iShaderID, 1, &sVertexShaderSrc_cstr, NULL);
        glCompileShader(iShaderID);

        return checkShaderCompileStatus(iShaderID, GL_COMPILE_STATUS);
    }
}

bool linkShaders(GLuint iVertexShaderID, GLuint iFragShaderID, GLuint& iShaderProgramID)
{
    // link shaders
    iShaderProgramID = glCreateProgram();
    glAttachShader(iShaderProgramID, iVertexShaderID);
    glAttachShader(iShaderProgramID, iFragShaderID);
    glLinkProgram(iShaderProgramID);

    return checkShaderLinkStatus(iShaderProgramID);
}

bool initShaders(const char* sVertexShaderFile, const char* sFragShaderFile, GLuint& iSimpleShaderProgramIDOUT)
{
    bool bReturn = false;

    // build and compile our shader program
    int iSimpleVertexShaderID, iSimpleFragShaderID;
    if (compileShader(sVertexShaderFile, iSimpleVertexShaderID, GL_VERTEX_SHADER))
    {
        if (compileShader(sFragShaderFile, iSimpleFragShaderID, GL_FRAGMENT_SHADER))
        {
            if (linkShaders(iSimpleVertexShaderID, iSimpleFragShaderID, iSimpleShaderProgramIDOUT))
            {
                bReturn = true;
            }
        }
    }

    glDeleteShader(iSimpleVertexShaderID);
    glDeleteShader(iSimpleFragShaderID);

    return bReturn;
}
#endif

class MyEngine : public GameEngine
{
	public:
		MyEngine()
		{
			createWindow(960, 640, "GLApp");
		}

		virtual void onCreate()
		{
            LoadLibraryA("OpenGLLayerFramework.dll");
            m_iRenderCount = 0;
#if (USE_PROGRAMMABLE_PIPELINE == 1)
#if(USE_TEXTURE_SCENE == 1)
            if (initShaders("..\\Content\\simpleTextureVert.txt",
                            "..\\Content\\simpleTextureFrag.txt",
                            m_iSimpleShaderProgramID)
            ) {
                m_iMaxRenderCount = 50;
                setupScene_Texture();
            }
#else
            if (initShaders("..\\Content\\simpleVert.txt", 
                            "..\\Content\\simpleFrag.txt", 
                            m_iSimpleShaderProgramID)
            ) {
                m_iMaxRenderCount = 300;
                setupScene_Triangle();
            }
#endif
#else
            if (IsValidOpenGL())
            {
                m_iMaxRenderCount = 300;
                setupScene_Triangle();
            }
            else
            {
                MessageBoxW(NULL, L"Invalid Opengl32.dll", L"Error", MB_OK);
                exit(1);
            }
#endif
		}

		virtual void onUpdate(uint32_t iDeltaTimeMs, uint64_t lElapsedTime)
		{
#if(USE_TEXTURE_SCENE == 1)
            updateScene_Texture(iDeltaTimeMs, lElapsedTime);
#else
            updateScene_Triangle(iDeltaTimeMs, lElapsedTime);
#endif
		}

		virtual void onDestroy()
		{

		}

	protected:
#if (USE_PROGRAMMABLE_PIPELINE == 1)
#if (USE_TEXTURE_SCENE == 1)
        void setupScene_Texture()
        {
            // --- Geometry
            float verts[] = 
            {
                // pos       // uv
                -0.5f, -0.5f, 0.0f,  0.f, 0.f,
                 0.5f, -0.5f, 0.0f,  1.f, 0.f,
                 0.5f,  0.5f, 0.0f,  1.f, 1.f,
                -0.5f,  0.5f, 0.0f,  0.f, 1.f
            };
            unsigned int idx[] = { 0, 1, 2, 2, 3, 0 };

            GLuint vbo, ebo;
            ::glGenVertexArrays(1, &m_iVAO);
            ::glBindVertexArray(m_iVAO);

            ::glGenBuffers(1, &vbo);
            ::glBindBuffer(GL_ARRAY_BUFFER, vbo);
            ::glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);

            ::glGenBuffers(1, &ebo);
            ::glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);
            ::glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(idx), idx, GL_STATIC_DRAW);

            ::glEnableVertexAttribArray(0);
            ::glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)0);
            ::glEnableVertexAttribArray(1);
            ::glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(3 * sizeof(float)));

            // --- Texture
            GLuint tex;
            ::glGenTextures(1, &tex);
            ::glActiveTexture(GL_TEXTURE0);
            ::glBindTexture(GL_TEXTURE_2D, tex);

            // Simple checkerboard
            const int TEXSZ = 4;
            unsigned char checker[TEXSZ * TEXSZ * 3];
            for (int y = 0; y < TEXSZ; y++) 
            {
                for (int x = 0; x < TEXSZ; x++) 
                {
                    int c = ((x ^ y) & 1) ? 255 : 0;
                    checker[(y * TEXSZ + x) * 3 + 0] = (unsigned char)c;
                    checker[(y * TEXSZ + x) * 3 + 1] = (unsigned char)(255 - c);
                    checker[(y * TEXSZ + x) * 3 + 2] = 0;
                }
            }

            ::glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, TEXSZ, TEXSZ, 0, GL_RGB, GL_UNSIGNED_BYTE, checker);
            ::glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
            ::glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

            // --- FBO
            GLuint fbo;
            ::glGenFramebuffers(1, &fbo);
            ::glBindFramebuffer(GL_FRAMEBUFFER, fbo);
            ::glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, tex, 0);
            ::glBindFramebuffer(GL_FRAMEBUFFER, 0);

            // --- Uniform locations
            m_uniformLoc_MVP = ::glGetUniformLocation(m_iSimpleShaderProgramID, "uMVP");
            m_uniformLoc_Tint = ::glGetUniformLocation(m_iSimpleShaderProgramID, "uTint");
            m_uniformLoc_Tex = ::glGetUniformLocation(m_iSimpleShaderProgramID, "uTex");
        }
#endif
#endif
        void setupScene_Triangle()
        {
            m_fOffsetX = 0.0;
            m_iDirection = 1;
            m_iSwayRate = 1.0f / 5000;

#if (USE_PROGRAMMABLE_PIPELINE == 1)
            float aVertices[] = 
            {
                // Positions        // Colors
                -0.5, -0.5f, 0.0f, 1.0f, 0.0f, 0.0f,   // Bottom-left (Red)
                 0.5, -0.5f, 0.0f, 0.0f, 1.0f, 0.0f,   // Bottom-right (Green)
                 0.0,  0.5f, 0.0f, 0.0f, 0.0f, 1.0f    // Top (Blue)
            };

            unsigned int iVBO;
            glGenVertexArrays(1, &m_iVAO);
            glGenBuffers(1, &iVBO);

            glBindVertexArray(m_iVAO);

            glBindBuffer(GL_ARRAY_BUFFER, iVBO);
            glBufferData(GL_ARRAY_BUFFER, sizeof(aVertices), aVertices, GL_STATIC_DRAW);

            // Position attribute
            glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
            glEnableVertexAttribArray(0);

            // Color attribute
            glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)(3 * sizeof(float)));
            glEnableVertexAttribArray(1);
#else
            // Bottom-left
            m_vTriangleVertices.push_back(m_fOffsetX - 0.5f);
            m_vTriangleVertices.push_back(-0.5f);
            m_vTriangleVertices.push_back(0.0f);
            // Bottom-right
            m_vTriangleVertices.push_back(m_fOffsetX + 0.5f);
            m_vTriangleVertices.push_back(-0.5f);
            m_vTriangleVertices.push_back(0.0f);
            // Top
            m_vTriangleVertices.push_back(m_fOffsetX);
            m_vTriangleVertices.push_back(0.5f);
            m_vTriangleVertices.push_back(0.0f);

            // Bottom-left
            m_vTriangleVertexColours.push_back(1.0f);
            m_vTriangleVertexColours.push_back(0.0f);
            m_vTriangleVertexColours.push_back(0.0f);
            // Bottom-right
            m_vTriangleVertexColours.push_back(0.0f);
            m_vTriangleVertexColours.push_back(1.0f);
            m_vTriangleVertexColours.push_back(0.0f);
            // Top
            m_vTriangleVertexColours.push_back(0.0f);
            m_vTriangleVertexColours.push_back(0.0f);
            m_vTriangleVertexColours.push_back(1.0f);
#endif
        }

#if (USE_PROGRAMMABLE_PIPELINE == 1)
#if (USE_TEXTURE_SCENE == 1)
        void updateScene_Texture(uint32_t iDeltaTimeMs, uint64_t lElapsedTime)
        {
            // Render loop (capture a few frames)
            if (m_iRenderCount < m_iMaxRenderCount)
            {
                float t = m_iRenderCount / 50.0f;
                ::glViewport(0, 0, 800, 600);
                ::glClearColor(1.0f, 1.0f, 0.0f, 1.0f);
                ::glClear(GL_COLOR_BUFFER_BIT);

                ::glUseProgram(m_iSimpleShaderProgramID);

                // Uniforms
                //float tint[4] = { 1.0f, t, 1.0f - t, 1.0f };
                //Uniform4fv(logger, uTint, 4, tint); -> Revisit
                ::glUniform4f(m_uniformLoc_Tint, 1.0f, t, 1.0f - t, 1.0f);

                float ident[16] = {
                    1,0,0,0,  0,1,0,0,
                    0,0,1,0,  0,0,0,1
                };
                ::glUniformMatrix4fv(m_uniformLoc_MVP, 1, GL_FALSE, ident);

                ::glUniform1i(m_uniformLoc_Tex, 0);

                // State changes
                ::glEnable(GL_BLEND);
                ::glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

                ::glBindVertexArray(m_iVAO);
                ::glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);

                ::glDisable(GL_BLEND);

                m_iRenderCount++;
            }
            else
            {
                exit(0);
            }
        }
#endif
#endif
        void updateScene_Triangle(uint32_t iDeltaTimeMs, uint64_t lElapsedTime)
        {
            if (m_iRenderCount < m_iMaxRenderCount)
            {
                switch (m_iDirection)
                {
                    case 1:
                        if (m_fOffsetX >= 0.5f)   m_iDirection = -1;
                    break;
                    case -1:
                        if (m_fOffsetX <= -0.5f)   m_iDirection = 1;
                    break;
                }
                m_fOffsetX += (iDeltaTimeMs * m_iSwayRate) * m_iDirection;

                float time = (float)glfwGetTime();
                float m_fOffsetX = sinf(time) * 0.5f;

#if (USE_PROGRAMMABLE_PIPELINE == 1)
                glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
                glClear(GL_COLOR_BUFFER_BIT);

                glUseProgram(m_iSimpleShaderProgramID);
                {
                    GLint uniform_fOffsetLoc = glGetUniformLocation(m_iSimpleShaderProgramID, "fOffsetX");
                    glUniform1f(uniform_fOffsetLoc, m_fOffsetX);
                }
                glBindVertexArray(m_iVAO);
                glDrawArrays(GL_TRIANGLES, 0, 3);
#else
                glClearColor(1.0f, 1.0f, 1.0f, 0.0f);
                glClear(GL_COLOR_BUFFER_BIT);

                glBegin(GL_TRIANGLES);
                {
                    glColor3f(m_vTriangleVertexColours[0], m_vTriangleVertexColours[1], m_vTriangleVertexColours[2]);
                    glVertex3f(m_fOffsetX - 0.5f, m_vTriangleVertices[1], m_vTriangleVertices[2]);

                    glColor3f(m_vTriangleVertexColours[3], m_vTriangleVertexColours[4], m_vTriangleVertexColours[5]);
                    glVertex3f(m_fOffsetX + 0.5f, m_vTriangleVertices[4], m_vTriangleVertices[5]);

                    glColor3f(m_vTriangleVertexColours[6], m_vTriangleVertexColours[7], m_vTriangleVertexColours[8]);
                    glVertex3f(m_fOffsetX, m_vTriangleVertices[7], m_vTriangleVertices[8]);
                }
                glEnd();
#endif
                m_iRenderCount++;
            }
            else
            {
                exit(0);
            }
        }
	private:
        int32_t     m_iRenderCount = 0;
        int32_t     m_iMaxRenderCount = 0;
#if (USE_PROGRAMMABLE_PIPELINE == 1)
        GLuint      m_iSimpleShaderProgramID = -1;
        GLuint      m_iVAO;

        GLint       m_uniformLoc_MVP;
        GLint       m_uniformLoc_Tint;
        GLint       m_uniformLoc_Tex;
#else
        std::vector<GLfloat>    m_vTriangleVertices;
        std::vector<GLfloat>    m_vTriangleVertexColours;
#endif
        float                   m_fOffsetX;
        int                     m_iDirection;
        float                   m_iSwayRate;
};


int main(int argc, char** argv)
{
	MyEngine me;

	exit(EXIT_SUCCESS);
}
