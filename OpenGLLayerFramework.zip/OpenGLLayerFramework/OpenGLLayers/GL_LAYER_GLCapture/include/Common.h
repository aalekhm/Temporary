#pragma once
#include <Windows.h>
#include <intrin.h>
#include <string>
#include <gl/GL.h>
#include <iostream>

bool endsWith(const std::string& fullString, const std::string& ending) 
{
    if (ending.size() > fullString.size()) 
	{
        return false; // Suffix cannot be longer than the main string
    }

    // Compare the substring at the end of fullString with the ending string
    return fullString.compare(fullString.size() - ending.size(), ending.size(), ending) == 0;
}

bool startsWith(const std::string& fullString, const std::string& starting)
{
    if (starting.size() > fullString.size())
    {
        return false; // Suffix cannot be longer than the main string
    }

    // Compare the substring at the start of fullString with the starting string
    return fullString.compare(0, starting.size(), starting) == 0;
}

#define IS_CALLED_FROM_AN_EXECUTABLE(__bYesItsCalledFromAnExecutable__) \
{ \
	__bYesItsCalledFromAnExecutable__ = true; \
	void* ret = _ReturnAddress(); \
	MEMORY_BASIC_INFORMATION mbi{}; \
	VirtualQuery(ret, &mbi, sizeof(mbi)); \
 \
	char moduleName[MAX_PATH] = {}; \
	if (GetModuleFileNameA((HMODULE)mbi.AllocationBase, moduleName, MAX_PATH)) \
	{ \
		std::string sModuleName = moduleName; \
		if (endsWith(sModuleName, ".dll")) \
		{ \
			__bYesItsCalledFromAnExecutable__ = false; \
		} \
	} \
} \

#define CHECK_AND_CALL(__glCall__) \
bool bItsCalledFromAnExecutable = true; \
IS_CALLED_FROM_AN_EXECUTABLE(bItsCalledFromAnExecutable) \
if (bItsCalledFromAnExecutable) \
{\
	__glCall__;\
}\

#define CALL_NEXT_IN_CHAIN(__glCall__, __ModuleID__, __FUNC_DEFN__, ...)							\
    do {																							\
		GenericGLFunc pFnNext = (GenericGLFunc)(*g_pFn_CallNextInChain)(#__glCall__, __ModuleID__); \
		g_pFnNext_##__glCall__ = __FUNC_DEFN__##pFnNext;											\
		if(g_pFnNext_##__glCall__) g_pFnNext_##__glCall__(__VA_ARGS__);								\
    } while (0);																					\

#define CALL_NEXT_IN_CHAIN_RET(__retValue__, __glCall__, __ModuleID__, __FUNC_DEFN__, ...)			\
    do {																							\
		GenericGLFunc pFnNext = (GenericGLFunc)(*g_pFn_CallNextInChain)(#__glCall__, __ModuleID__); \
		g_pFnNext_##__glCall__ = __FUNC_DEFN__##pFnNext;											\
		if(g_pFnNext_##__glCall__) __retValue__ = g_pFnNext_##__glCall__(__VA_ARGS__);				\
    } while (0);																					\
