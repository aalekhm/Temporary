﻿#include "gltrace/gltrace.hpp"
#include "Common.h"

typedef void (*GenericGLFunc)();
static GenericGLFunc(*g_pFn_CallNextInChain)(const std::string&, int32_t)	= nullptr;
static int32_t g_iLayerPosition												= -1;

const char* functionsToHook[] = {	"glColor3f", 
									"glClearColor", 
									"glClear", 
									"glBegin", 
									"glVertex3f", 
									"glEnd", 
									"glfwPollEvents",

									"glViewport",
									"glGenVertexArrays",
									"glBindVertexArray",
									"glGenBuffers",
									"glBindBuffer",
									"glBufferData",
									"glEnableVertexAttribArray",
									"glVertexAttribPointer",
									"glCreateShader",
									"glShaderSource",
									"glCompileShader",
									"glCreateProgram",
									"glAttachShader",
									"glLinkProgram",
									"glDeleteShader",
									"glUseProgram",
									"glDrawArrays",
									"glDrawElements",
									"glGenTextures",
									"glBindTexture",
									"glTexImage2D",
									"glTexParameteri",
									"glActiveTexture",
									"glGenFramebuffers",
									"glBindFramebuffer",
									"glFramebufferTexture2D",
									"glUniform1i", 
									"glUniform1f", 
									"glUniform2f", 
									"glUniform3f", 
									"glUniform4f", 
									"glUniform4fv",
									"glUniformMatrix4fv",
									"glGetUniformLocation",
									"glEnable",
									"glDisable",
									"glBlendFunc",
									"glDepthFunc",
									"glCullFace"
};

const int	iFunctionsToHookCount = 45;

static void (*g_pFnNext_glColor3f)					(GLfloat red, GLfloat green, GLfloat blue) = nullptr;
static void (*g_pFnNext_glClearColor)				(GLclampf red, GLclampf green, GLclampf blue, GLclampf alpha) = nullptr;
static void (*g_pFnNext_glClear)					(GLbitfield mask) = nullptr;
static void (*g_pFnNext_glBegin)					(GLenum mode) = nullptr;
static void (*g_pFnNext_glVertex3f)					(GLfloat x, GLfloat y, GLfloat z) = nullptr;
static void (*g_pFnNext_glEnd)						() = nullptr;
static void (*g_pFnNext_glfwPollEvents)				() = nullptr;

static void (*g_pFnNext_glViewport)					(int x, int y, int w, int h) = nullptr;

static void (*g_pFnNext_glGenVertexArrays)			(int n, unsigned* arrays) = nullptr;
static void (*g_pFnNext_glBindVertexArray)			(unsigned vao) = nullptr;
static void (*g_pFnNext_glGenBuffers)				(int n, unsigned* buffers) = nullptr;
static void (*g_pFnNext_glBindBuffer)				(uint32_t target, unsigned buffer) = nullptr;
static void (*g_pFnNext_glBufferData)				(uint32_t target, ptrdiff_t size, const void* data, uint32_t usage) = nullptr;
static void (*g_pFnNext_glEnableVertexAttribArray)	(unsigned index) = nullptr;
static void (*g_pFnNext_glVertexAttribPointer)		(unsigned index, int size, uint32_t type, bool normalized, int stride, const void* pointer) = nullptr;
static GLuint(*g_pFnNext_glCreateShader)			(GLenum type) = nullptr;
static void (*g_pFnNext_glShaderSource)				(GLuint shader, GLsizei count, const GLchar** strings, const GLint* lengths) = nullptr;
static void (*g_pFnNext_glCompileShader)			(unsigned shader) = nullptr;
static GLuint(*g_pFnNext_glCreateProgram)			() = nullptr;
static void (*g_pFnNext_glAttachShader)				(unsigned program, unsigned shader) = nullptr;
static void (*g_pFnNext_glLinkProgram)				(unsigned program) = nullptr;
static void (*g_pFnNext_glUseProgram)				(unsigned program) = nullptr;
static void (*g_pFnNext_glDeleteShader)				(unsigned program) = nullptr;
static void (*g_pFnNext_glDrawArrays)				(uint32_t mode, int first, int count) = nullptr;
static void (*g_pFnNext_glDrawElements)				(uint32_t mode, int count, uint32_t type, const void* indices) = nullptr;

static void (*g_pFnNext_glGenTextures)				(int n, unsigned* textures) = nullptr;
static void (*g_pFnNext_glBindTexture)				(uint32_t target, unsigned tex) = nullptr;
static void (*g_pFnNext_glTexImage2D)				(uint32_t target, int level, int internalFormat, int width, int height, int border, uint32_t format, uint32_t type, const void* data) = nullptr;
static void (*g_pFnNext_glTexParameteri)			(uint32_t target, uint32_t pname, int param) = nullptr;
static void (*g_pFnNext_glActiveTexture)			(uint32_t texture) = nullptr;

static void (*g_pFnNext_glGenFramebuffers)			(int n, unsigned* fbos) = nullptr;
static void (*g_pFnNext_glBindFramebuffer)			(uint32_t target, unsigned fbo) = nullptr;
static void (*g_pFnNext_glFramebufferTexture2D)		(uint32_t target, uint32_t attachment, uint32_t textarget, unsigned texture, int level) = nullptr;

static void (*g_pFnNext_glUniform1i)				(int location, int v0) = nullptr;
static void (*g_pFnNext_glUniform1f)				(int location, float v0) = nullptr;
static void (*g_pFnNext_glUniform2f)				(int location, float x, float y) = nullptr;
static void (*g_pFnNext_glUniform3f)				(int location, float x, float y, float z) = nullptr;
static void (*g_pFnNext_glUniform4f)				(int location, float x, float y, float z, float w) = nullptr;
static void (*g_pFnNext_glUniform4fv)				(int location, int count, const float* value) = nullptr;
static void (*g_pFnNext_glUniformMatrix4fv)			(int location, int count, bool transpose, const float* value) = nullptr;
static GLint(*g_pFnNext_glGetUniformLocation)		(GLuint program, const GLchar* name) = nullptr;

static void (*g_pFnNext_glEnable)					(uint32_t cap) = nullptr;
static void (*g_pFnNext_glDisable)					(uint32_t cap) = nullptr;
static void (*g_pFnNext_glBlendFunc)				(uint32_t sfactor, uint32_t dfactor) = nullptr;
static void (*g_pFnNext_glDepthFunc)				(uint32_t func) = nullptr;
static void (*g_pFnNext_glCullFace)					(uint32_t mode) = nullptr;

#define CAPTURE_FILE "..\\x64\\Debug\\capture.gltrace"
gltrace::Logger logger(CAPTURE_FILE);

void APIENTRY Hooked_g_pFnNext_glColor3f(GLfloat red, GLfloat green, GLfloat blue)
{
	CHECK_AND_CALL(gltrace::glColor3f(logger, red, green, blue))

	CALL_NEXT_IN_CHAIN(glColor3f, g_iLayerPosition, (void (*)(GLfloat, GLfloat, GLfloat)), green, blue, red);
}

void APIENTRY Hooked_g_pFnNext_glClear(GLbitfield mask)
{
	CHECK_AND_CALL(gltrace::glClear(logger, mask))
	
	CALL_NEXT_IN_CHAIN(glClear, g_iLayerPosition, (void (*)(GLbitfield)), mask);
}

void APIENTRY Hooked_g_pFnNext_glBegin(GLenum mode)
{
	CHECK_AND_CALL(gltrace::glBegin(logger, mode))

	CALL_NEXT_IN_CHAIN(glBegin, g_iLayerPosition, (void (*)(GLenum)), mode);
}

void APIENTRY Hooked_g_pFnNext_glVertex3f(GLfloat x, GLfloat y, GLfloat z)
{
	CHECK_AND_CALL(gltrace::glVertex3f(logger, x, y, z))

	CALL_NEXT_IN_CHAIN(glVertex3f, g_iLayerPosition, (void (*)(GLfloat, GLfloat, GLfloat)), x, y, z);
}

void APIENTRY Hooked_g_pFnNext_glEnd()
{
	CHECK_AND_CALL(gltrace::glEnd(logger))

	CALL_NEXT_IN_CHAIN(glEnd, g_iLayerPosition, (void (*)()));
}

static uint32_t g_iFrameMarker = 0;
void APIENTRY Hooked_g_pFnNext_glfwPollEvents()
{
	CHECK_AND_CALL(gltrace::glfwPollEvents(logger))

	CALL_NEXT_IN_CHAIN(glfwPollEvents, g_iLayerPosition, (void (*)()));
}

void APIENTRY Hooked_g_pFnNext_glViewport(int x, int y, int w, int h)
{
	CHECK_AND_CALL(gltrace::glViewport(logger, x, y, w, h))

	CALL_NEXT_IN_CHAIN(glViewport, g_iLayerPosition, (void (*)(int, int, int, int)), x, y, w, h);
}

void APIENTRY Hooked_g_pFnNext_glClearColor(float r, float g, float b, float a)
{
	CHECK_AND_CALL(gltrace::glClearColor(logger, r, g, b, a))

	CALL_NEXT_IN_CHAIN(glClearColor, g_iLayerPosition, (void (*)(GLclampf, GLclampf, GLclampf, GLclampf)), r, g, b, a);
}

void APIENTRY Hooked_g_pFnNext_glGenVertexArrays(int n, unsigned* arrays) 
{
	CHECK_AND_CALL(gltrace::glGenVertexArrays(logger, n, arrays))

	CALL_NEXT_IN_CHAIN(glGenVertexArrays, g_iLayerPosition, (void (*)(int, unsigned*)), n, arrays);
}

void APIENTRY Hooked_g_pFnNext_glBindVertexArray(unsigned vao) 
{
	CHECK_AND_CALL(gltrace::glBindVertexArray(logger, vao))

	CALL_NEXT_IN_CHAIN(glBindVertexArray, g_iLayerPosition, (void (*)(unsigned)), vao);
}

void APIENTRY Hooked_g_pFnNext_glGenBuffers(int n, unsigned* buffers) 
{
	CHECK_AND_CALL(gltrace::glGenBuffers(logger, n, buffers))

	CALL_NEXT_IN_CHAIN(glGenBuffers, g_iLayerPosition, (void (*)(int, unsigned*)), n, buffers);
}

void APIENTRY Hooked_g_pFnNext_glBindBuffer(uint32_t target, unsigned buffer) 
{
	CHECK_AND_CALL(gltrace::glBindBuffer(logger, target, buffer))

	CALL_NEXT_IN_CHAIN(glBindBuffer, g_iLayerPosition, (void (*)(uint32_t, unsigned)), target, buffer);
}

void APIENTRY Hooked_g_pFnNext_glBufferData(uint32_t target, ptrdiff_t size, const void* data, uint32_t usage) 
{
	CHECK_AND_CALL(gltrace::glBufferData(logger, target, size, data, usage))

	CALL_NEXT_IN_CHAIN(glBufferData, g_iLayerPosition, (void (*)(uint32_t, ptrdiff_t, const void*, uint32_t)), target, size, data, usage);
}

void APIENTRY Hooked_g_pFnNext_glEnableVertexAttribArray(unsigned index) 
{
	CHECK_AND_CALL(gltrace::glEnableVertexAttribArray(logger, index))

	CALL_NEXT_IN_CHAIN(glEnableVertexAttribArray, g_iLayerPosition, (void (*)(unsigned)), index);
}

void APIENTRY Hooked_g_pFnNext_glVertexAttribPointer(unsigned index, int size, uint32_t type, bool normalized, int stride, const void* pointer) 
{
	CHECK_AND_CALL(gltrace::glVertexAttribPointer(logger, index, size, type, normalized, stride, pointer))

	CALL_NEXT_IN_CHAIN(glVertexAttribPointer, g_iLayerPosition, (void (*)(unsigned, int, uint32_t, bool, int, const void*)), index, size, type, normalized, stride, pointer);
}

unsigned APIENTRY Hooked_g_pFnNext_glCreateShader(uint32_t type)
{
	unsigned sRet{};
	CHECK_AND_CALL(gltrace::glCreateShader(logger, sRet, type))
		
	CALL_NEXT_IN_CHAIN_RET(sRet, glCreateShader, g_iLayerPosition, (GLuint(*)(GLenum)), type);
	return sRet;
}

void APIENTRY Hooked_g_pFnNext_glShaderSource(GLuint shader, GLsizei count, const GLchar** strings, const GLint* lengths)
{
	CHECK_AND_CALL(gltrace::glShaderSource(logger, shader, std::string(*strings)))

	CALL_NEXT_IN_CHAIN(glShaderSource, g_iLayerPosition, (void (*)(GLuint, GLsizei, const GLchar**, const GLint*)), shader, count, strings, lengths);
}

void APIENTRY Hooked_g_pFnNext_glCompileShader(unsigned shader)
{
	CHECK_AND_CALL(gltrace::glCompileShader(logger, shader))

	CALL_NEXT_IN_CHAIN(glCompileShader, g_iLayerPosition, (void (*)(unsigned)), shader);
}

unsigned APIENTRY Hooked_g_pFnNext_glCreateProgram()
{
	unsigned progId{};
	CHECK_AND_CALL(gltrace::glCreateProgram(logger, progId))

	CALL_NEXT_IN_CHAIN_RET(progId, glCreateProgram, g_iLayerPosition, (GLuint(*)()));
	return progId;
}

void APIENTRY Hooked_g_pFnNext_glAttachShader(unsigned program, unsigned shader)
{
	CHECK_AND_CALL(gltrace::glAttachShader(logger, program, shader))

	CALL_NEXT_IN_CHAIN(glAttachShader, g_iLayerPosition, (void (*)(unsigned, unsigned)), program, shader);
}

void APIENTRY Hooked_g_pFnNext_glLinkProgram(unsigned program)
{
	CHECK_AND_CALL(gltrace::glLinkProgram(logger, program))

	CALL_NEXT_IN_CHAIN(glLinkProgram, g_iLayerPosition, (void (*)(unsigned)), program);
}

void APIENTRY Hooked_g_pFnNext_glUseProgram(unsigned program)
{
	CHECK_AND_CALL(gltrace::glUseProgram(logger, program))

	CALL_NEXT_IN_CHAIN(glUseProgram, g_iLayerPosition, (void (*)(unsigned)), program);
}

void APIENTRY Hooked_g_pFnNext_glDeleteShader(unsigned program)
{
	CHECK_AND_CALL(gltrace::glDeleteShader(logger, program))

	CALL_NEXT_IN_CHAIN(glDeleteShader, g_iLayerPosition, (void (*)(unsigned)), program);
}

void APIENTRY Hooked_g_pFnNext_glDrawArrays(uint32_t mode, int first, int count)
{
	CHECK_AND_CALL(gltrace::glDrawArrays(logger, mode, first, count))

	CALL_NEXT_IN_CHAIN(glDrawArrays, g_iLayerPosition, (void (*)(uint32_t, int, int)), mode, first, count);
}

void APIENTRY Hooked_g_pFnNext_glDrawElements(uint32_t mode, int count, uint32_t type, const void* indices)
{
	CHECK_AND_CALL(gltrace::glDrawElements(logger, mode, count, type, indices))

	CALL_NEXT_IN_CHAIN(glDrawElements, g_iLayerPosition, (void (*)(uint32_t, int, uint32_t, const void*)), mode, count, type, indices);
}

void APIENTRY Hooked_g_pFnNext_glGenTextures(int n, unsigned* textures)
{
	CHECK_AND_CALL(gltrace::glGenTextures(logger, n, textures))

	CALL_NEXT_IN_CHAIN(glGenTextures, g_iLayerPosition, (void (*)(int, unsigned*)), n, textures);
}

void APIENTRY Hooked_g_pFnNext_glBindTexture(uint32_t target, unsigned tex)
{
	CHECK_AND_CALL(gltrace::glBindTexture(logger, target, tex))

	CALL_NEXT_IN_CHAIN(glBindTexture, g_iLayerPosition, (void (*)(uint32_t, unsigned)), target, tex);
}

void APIENTRY Hooked_g_pFnNext_glTexImage2D(uint32_t target, int level, int internalFormat, int width, int height, int border, uint32_t format, uint32_t type, const void* data)
{
	CHECK_AND_CALL(gltrace::glTexImage2D(logger, target, level, internalFormat, width, height, border, format, type, data))

	CALL_NEXT_IN_CHAIN(glTexImage2D, g_iLayerPosition, (void (*)(uint32_t, int, int, int, int, int, uint32_t, uint32_t, const void*)), target, level, internalFormat, width, height, border, format, type, data);
}

void APIENTRY Hooked_g_pFnNext_glTexParameteri(uint32_t target, uint32_t pname, int param)
{
	CHECK_AND_CALL(gltrace::glTexParameteri(logger, target, pname, param))

	CALL_NEXT_IN_CHAIN(glTexParameteri, g_iLayerPosition, (void (*)(uint32_t, uint32_t, int)), target, pname, param);
}

void APIENTRY Hooked_g_pFnNext_glActiveTexture(uint32_t texture)
{
	CHECK_AND_CALL(gltrace::glActiveTexture(logger, texture))

	CALL_NEXT_IN_CHAIN(glActiveTexture, g_iLayerPosition, (void (*)(uint32_t)), texture);
}

void APIENTRY Hooked_g_pFnNext_glGenFramebuffers(int n, unsigned* fbos)
{
	CHECK_AND_CALL(gltrace::glGenFramebuffers(logger, n, fbos))

	CALL_NEXT_IN_CHAIN(glGenFramebuffers, g_iLayerPosition, (void (*)(int n, unsigned* fbos)), n, fbos);
}

void APIENTRY Hooked_g_pFnNext_glBindFramebuffer(uint32_t target, unsigned fbo)
{
	CHECK_AND_CALL(gltrace::glBindFramebuffer(logger, target, fbo))

	CALL_NEXT_IN_CHAIN(glBindFramebuffer, g_iLayerPosition, (void (*)(uint32_t target, unsigned fbo)), target, fbo);
}

void APIENTRY Hooked_g_pFnNext_glFramebufferTexture2D(uint32_t target, uint32_t attachment, uint32_t textarget, unsigned texture, int level)
{
	CHECK_AND_CALL(gltrace::glFramebufferTexture2D(logger, target, attachment, textarget, texture, level))

	CALL_NEXT_IN_CHAIN(glFramebufferTexture2D, g_iLayerPosition, (void (*)(uint32_t target, uint32_t attachment, uint32_t textarget, unsigned texture, int level)), target, attachment, textarget, texture, level);
}

void APIENTRY Hooked_g_pFnNext_glUniform1i(int location, int v0)
{
	CHECK_AND_CALL(gltrace::glUniform1i(logger, location, v0))

	CALL_NEXT_IN_CHAIN(glUniform1i, g_iLayerPosition, (void (*)(int location, int v0)), location, v0);
}

void APIENTRY Hooked_g_pFnNext_glUniform1f(int location, float v0)
{
	CHECK_AND_CALL(gltrace::glUniform1f(logger, location, v0))

	CALL_NEXT_IN_CHAIN(glUniform1f, g_iLayerPosition, (void (*)(int location, float v0)), location, v0);
}

void APIENTRY Hooked_g_pFnNext_glUniform2f(int location, float x, float y)
{
	CHECK_AND_CALL(gltrace::glUniform2f(logger, location, x, y))

	CALL_NEXT_IN_CHAIN(glUniform2f, g_iLayerPosition, (void (*)(int location, float x, float y)), location, x, y);
}

void APIENTRY Hooked_g_pFnNext_glUniform3f(int location, float x, float y, float z)
{
	CHECK_AND_CALL(gltrace::glUniform3f(logger, location, x, y, z))

	CALL_NEXT_IN_CHAIN(glUniform3f, g_iLayerPosition, (void (*)(int location, float x, float y, float z)), location, x, y, z);
}

void APIENTRY Hooked_g_pFnNext_glUniform4f(int location, float x, float y, float z, float w)
{
	CHECK_AND_CALL(gltrace::glUniform4f(logger, location, x, y, z, w))

	CALL_NEXT_IN_CHAIN(glUniform4f, g_iLayerPosition, (void (*)(int location, float x, float y, float z, float w)), location, x, y, z, w);
}

void APIENTRY Hooked_g_pFnNext_glUniform4fv(int location, int count, const float* value)
{
	CHECK_AND_CALL(gltrace::glUniform4fv(logger, location, count, value))

	CALL_NEXT_IN_CHAIN(glUniform4fv, g_iLayerPosition, (void (*)(int location, int count, const float* value)), location, count, value);
}

void APIENTRY Hooked_g_pFnNext_glUniformMatrix4fv(int location, int count, bool transpose, const float* value)
{
	CHECK_AND_CALL(gltrace::glUniformMatrix4fv(logger, location, count, transpose, value))

	CALL_NEXT_IN_CHAIN(glUniformMatrix4fv, g_iLayerPosition, (void (*)(int location, int count, bool transpose, const float* value)), location, count, transpose, value);
}

GLint APIENTRY Hooked_g_pFnNext_glGetUniformLocation(GLuint program, const GLchar* name)
{
	GLint iUniformLoc{};
	CHECK_AND_CALL(gltrace::glGetUniformLocation(logger, iUniformLoc, program, name))

	CALL_NEXT_IN_CHAIN_RET(iUniformLoc, glGetUniformLocation, g_iLayerPosition, (GLint(*)(GLuint program, const GLchar * name)), program, name);
	return iUniformLoc;
}

void APIENTRY Hooked_g_pFnNext_glEnable(uint32_t cap)
{
	CHECK_AND_CALL(gltrace::glEnable(logger, cap))

	CALL_NEXT_IN_CHAIN(glEnable, g_iLayerPosition, (void (*)(uint32_t cap)), cap);
}

void APIENTRY Hooked_g_pFnNext_glDisable(uint32_t cap)
{
	CHECK_AND_CALL(gltrace::glDisable(logger, cap))

	CALL_NEXT_IN_CHAIN(glDisable, g_iLayerPosition, (void (*)(uint32_t cap)), cap);
}

void APIENTRY Hooked_g_pFnNext_glBlendFunc(uint32_t sfactor, uint32_t dfactor)
{
	CHECK_AND_CALL(gltrace::glBlendFunc(logger, sfactor, dfactor))

	CALL_NEXT_IN_CHAIN(glBlendFunc, g_iLayerPosition, (void (*)(uint32_t sfactor, uint32_t dfactor)), sfactor, dfactor);
}

void APIENTRY Hooked_g_pFnNext_glDepthFunc(uint32_t func)
{
	CHECK_AND_CALL(gltrace::glDepthFunc(logger, func))

	CALL_NEXT_IN_CHAIN(glDepthFunc, g_iLayerPosition, (void (*)(uint32_t func)), func);
}

void APIENTRY Hooked_g_pFnNext_glCullFace(uint32_t mode)
{
	CHECK_AND_CALL(gltrace::glCullFace(logger, mode))

	CALL_NEXT_IN_CHAIN(glCullFace, g_iLayerPosition, (void (*)(uint32_t mode)), mode);
}

/////////////////////////////////////////////////////////////////////////////////////

extern "C" __declspec(dllexport) void OGLLayer_SetNextInChain(int32_t iLayerPosition, void* pFn_CallNextInChain)
{
	g_iLayerPosition = iLayerPosition;
	g_pFn_CallNextInChain = (GenericGLFunc (*)(const std::string&, int32_t))pFn_CallNextInChain;
}

extern "C" __declspec(dllexport) const char** OGLLayer_GetFunctionNames(int* iCount)
{
	*iCount = iFunctionsToHookCount;
	return functionsToHook;
}

extern "C" __declspec(dllexport) void* OGLLayer_GetHookedProcAddress(const char* pFuncName, void* pFnNext)
{
	if (strcmp(pFuncName, "glColor3f") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glColor3f;
	}
	else
	if (strcmp(pFuncName, "glClearColor") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glClearColor;
	}
	else
	if (strcmp(pFuncName, "glClear") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glClear;
	}
	else
	if (strcmp(pFuncName, "glBegin") == 0)
	{	
		return (void*)&Hooked_g_pFnNext_glBegin;
	}
	else
	if (strcmp(pFuncName, "glVertex3f") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glVertex3f;
	}
	else
	if (strcmp(pFuncName, "glEnd") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glEnd;
	}
	else
	if (strcmp(pFuncName, "glfwPollEvents") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glfwPollEvents;
	}
	else
	if (strcmp(pFuncName, "glViewport") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glViewport;
	}
	else
	if (strcmp(pFuncName, "glGenVertexArrays") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glGenVertexArrays;
	}
	else
	if (strcmp(pFuncName, "glBindVertexArray") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glBindVertexArray;
	}
	else
	if (strcmp(pFuncName, "glGenBuffers") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glGenBuffers;
	}
	else
	if (strcmp(pFuncName, "glBindBuffer") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glBindBuffer;
	}
	else
	if (strcmp(pFuncName, "glBufferData") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glBufferData;
	}
	else
	if (strcmp(pFuncName, "glEnableVertexAttribArray") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glEnableVertexAttribArray;
	}
	else
	if (strcmp(pFuncName, "glVertexAttribPointer") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glVertexAttribPointer;
	}
	else
	if (strcmp(pFuncName, "glVertexAttribPointer") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glVertexAttribPointer;
	}
	else
	if (strcmp(pFuncName, "glCreateShader") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glCreateShader;
	}
	else
	if (strcmp(pFuncName, "glShaderSource") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glShaderSource;
	}
	else
	if (strcmp(pFuncName, "glCompileShader") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glCompileShader;
	}
	else
	if (strcmp(pFuncName, "glCreateProgram") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glCreateProgram;
	}
	else
	if (strcmp(pFuncName, "glAttachShader") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glAttachShader;
	}
	else
	if (strcmp(pFuncName, "glLinkProgram") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glLinkProgram;
	}
	else
	if (strcmp(pFuncName, "glUseProgram") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glUseProgram;
	}
	else
	if (strcmp(pFuncName, "glDeleteShader") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glDeleteShader;
	}
	else
	if (strcmp(pFuncName, "glDrawArrays") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glDrawArrays;
	}
	else
	if (strcmp(pFuncName, "glDrawElements") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glDrawElements;
	}
	else
	if (strcmp(pFuncName, "glGenTextures") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glGenTextures;
	}
	else
	if (strcmp(pFuncName, "glBindTexture") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glBindTexture;
	}
	else
	if (strcmp(pFuncName, "glTexImage2D") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glTexImage2D;
	}
	else
	if (strcmp(pFuncName, "glTexParameteri") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glTexParameteri;
	}
	else
	if (strcmp(pFuncName, "glActiveTexture") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glActiveTexture;
	}
	else
	if (strcmp(pFuncName, "glGenFramebuffers") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glGenFramebuffers;
	}
	else
	if (strcmp(pFuncName, "glBindFramebuffer") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glBindFramebuffer;
	}
	else
	if (strcmp(pFuncName, "glFramebufferTexture2D") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glFramebufferTexture2D;
	}
	else
	if (strcmp(pFuncName, "glUniform1i") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glUniform1i;
	}
	else
	if (strcmp(pFuncName, "glUniform1f") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glUniform1f;
	}
	else
	if (strcmp(pFuncName, "glUniform2f") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glUniform2f;
	}
	else
	if (strcmp(pFuncName, "glUniform3f") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glUniform3f;
	}
	else
	if (strcmp(pFuncName, "glUniform4f") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glUniform4f;
	}
	else
	if (strcmp(pFuncName, "glUniform4fv") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glUniform4fv;
	}
	else
	if (strcmp(pFuncName, "glUniformMatrix4fv") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glUniformMatrix4fv;
	}
	else
	if (strcmp(pFuncName, "glGetUniformLocation") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glGetUniformLocation;
	}
	else
	if (strcmp(pFuncName, "glEnable") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glEnable;
	}
	else
	if (strcmp(pFuncName, "glDisable") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glDisable;
	}
	else
	if (strcmp(pFuncName, "glBlendFunc") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glBlendFunc;
	}
	else
	if (strcmp(pFuncName, "glDepthFunc") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glDepthFunc;
	}
	else
	if (strcmp(pFuncName, "glCullFace") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glCullFace;
	}

	return nullptr;
}
