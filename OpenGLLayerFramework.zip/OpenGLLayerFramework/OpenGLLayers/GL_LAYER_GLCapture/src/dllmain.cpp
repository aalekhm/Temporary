﻿#include "gltrace/gltrace.hpp"
#include <Windows.h>
#include <gl/GL.h>
#include <iostream>

static void (*g_pFn_Patch)(const std::string&)		= nullptr;
static void (*g_pFn_UnPatch)(const std::string&)	= nullptr;

const char* functionsToHook[] = { "glColor3f", "glClearColor", "glClear", "glBegin", "glVertex3f", "glEnd", "glfwPollEvents", "glCreateShader" };
const int	iFunctionsToHookCount = 8;

static void (*g_pFnNext_glColor3f)		(GLfloat red, GLfloat green, GLfloat blue) = nullptr;
static void (*g_pFnNext_glClearColor)	(GLclampf red, GLclampf green, GLclampf blue, GLclampf alpha) = nullptr;
static void (*g_pFnNext_glClear)		(GLbitfield mask) = nullptr;
static void (*g_pFnNext_glBegin)		(GLenum mode) = nullptr;
static void (*g_pFnNext_glVertex3f)		(GLfloat x, GLfloat y, GLfloat z) = nullptr;
static void (*g_pFnNext_glEnd)			() = nullptr;
static void (*g_pFnNext_glfwPollEvents)	() = nullptr;

static void (*g_pFnNext_glCreateShader)	(uint32_t type) = nullptr;

#define CAPTURE_FILE "..\\x64\\Debug\\capture_1.gltrace"
gltrace::Logger logger(CAPTURE_FILE);

void APIENTRY Hooked_g_pFnNext_glColor3f(GLfloat red, GLfloat green, GLfloat blue)
{
	gltrace::glColor3f(logger, green, blue, red);

	if (g_pFnNext_glColor3f == ::glColor3f)
	{
		(*g_pFn_UnPatch)("glColor3f");
		::glColor3f(red, green, blue);
		(*g_pFn_Patch)("glColor3f");
	}
	//else
	//{
		//if (g_pFnNext_glColor3f) g_pFnNext_glColor3f(green, blue, red);
	//}
}

void APIENTRY Hooked_g_pFnNext_glClearColor(GLclampf red, GLclampf green, GLclampf blue, GLclampf alpha)
{
	gltrace::glClearColor(logger, red, green, blue, alpha);

	(*g_pFn_UnPatch)("glClearColor");
	::glClearColor(red, green, blue, alpha);
	(*g_pFn_Patch)("glClearColor");

	//if (g_pFnNext_glClearColor) g_pFnNext_glClearColor(red, green, blue, alpha);
}

void APIENTRY Hooked_g_pFnNext_glClear(GLbitfield mask)
{
	gltrace::glClear(logger, mask);

	(*g_pFn_UnPatch)("glClear");
	::glClear(mask);
	(*g_pFn_Patch)("glClear");

	//if (g_pFnNext_glClear) g_pFnNext_glClear(mask);
}

void APIENTRY Hooked_g_pFnNext_glBegin(GLenum mode)
{
	gltrace::glBegin(logger, mode);

	(*g_pFn_UnPatch)("glBegin");
	::glBegin(mode);
	(*g_pFn_Patch)("glBegin");

	//if (g_pFnNext_glBegin) g_pFnNext_glBegin(mode);
}

void APIENTRY Hooked_g_pFnNext_glVertex3f(GLfloat x, GLfloat y, GLfloat z)
{
	gltrace::glVertex3f(logger, y, x, z);

	(*g_pFn_UnPatch)("glVertex3f");
	::glVertex3f(y, x, z);
	(*g_pFn_Patch)("glVertex3f");

	//if (g_pFnNext_glVertex3f) g_pFnNext_glVertex3f(y, x, z);
}

void APIENTRY Hooked_g_pFnNext_glEnd()
{
	gltrace::glEnd(logger);

	(*g_pFn_UnPatch)("glEnd");
	::glEnd();
	(*g_pFn_Patch)("glEnd");

	//if (g_pFnNext_glEnd) g_pFnNext_glEnd();
}

static uint32_t g_iFrameMarker = 0;
void APIENTRY Hooked_g_pFnNext_glfwPollEvents()
{
	gltrace::glfwPollEvents(logger, g_iFrameMarker++);

	(*g_pFn_UnPatch)("glfwPollEvents");
	::glfwPollEvents();
	(*g_pFn_Patch)("glfwPollEvents");

	//if (g_pFnNext_glfwPollEvents) g_pFnNext_glfwPollEvents();
}

void APIENTRY Hooked_g_pFnNext_glCreateShader(uint32_t type)
{
	gltrace::glCreateShader(logger, type);

	(*g_pFn_UnPatch)("glCreateShader");
	::glCreateShader(type);
	(*g_pFn_Patch)("glCreateShader");

	//if (g_pFnNext_glCreateShader) g_pFnNext_glCreateShader(type);
}

/////////////////////////////////////////////////////////////////////////////////////

extern "C" __declspec(dllexport) void OGLLayer_SetPatchUnPatchFunctions(void* pFn_Patch, void* pFn_UnPatch)
{
	g_pFn_Patch		= (void (*)(const std::string&))pFn_Patch;
	g_pFn_UnPatch	= (void (*)(const std::string&))pFn_UnPatch;
}

extern "C" __declspec(dllexport) const char** OGLLayer_GetFunctionNames(int* iCount)
{
	*iCount = iFunctionsToHookCount;
	return functionsToHook;
}

extern "C" __declspec(dllexport) void* OGLLayer_GetHookedProcAddress(const char* pFuncName, void* pFnNext)
{
	if (strcmp(pFuncName, "glColor3f") == 0)
	{
		g_pFnNext_glColor3f = (void (*)(GLfloat, GLfloat, GLfloat))pFnNext;
		return (void*)&Hooked_g_pFnNext_glColor3f;
	}
	else
	if (strcmp(pFuncName, "glClearColor") == 0)
	{
		g_pFnNext_glClearColor = (void (*)(GLclampf, GLclampf, GLclampf, GLclampf))pFnNext;
		return (void*)&Hooked_g_pFnNext_glClearColor;
	}
	else
	if (strcmp(pFuncName, "glClear") == 0)
	{
		g_pFnNext_glClear = (void (*)(GLbitfield))pFnNext;
		return (void*)&Hooked_g_pFnNext_glClear;
	}
	else
	if (strcmp(pFuncName, "glBegin") == 0)
	{
		g_pFnNext_glBegin = (void (*)(GLenum))pFnNext;
		return (void*)&Hooked_g_pFnNext_glBegin;
	}
	else
	if (strcmp(pFuncName, "glVertex3f") == 0)
	{
		g_pFnNext_glVertex3f = (void (*)(GLfloat, GLfloat, GLfloat))pFnNext;
		return (void*)&Hooked_g_pFnNext_glVertex3f;
	}
	else
	if (strcmp(pFuncName, "glEnd") == 0)
	{
		g_pFnNext_glEnd = (void (*)())pFnNext;
		return (void*)&Hooked_g_pFnNext_glEnd;
	}
	else
	if (strcmp(pFuncName, "glfwPollEvents") == 0)
	{
		g_pFnNext_glfwPollEvents = (void (*)())pFnNext;
		return (void*)&Hooked_g_pFnNext_glfwPollEvents;
	}

	else
	if (strcmp(pFuncName, "glCreateShader") == 0)
	{
		g_pFnNext_glCreateShader = (void (*)(uint32_t))pFnNext;
		return (void*)&Hooked_g_pFnNext_glCreateShader;
	}
	
	return nullptr;
}
