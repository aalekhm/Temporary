﻿#include "gltrace/gltrace.hpp"
#include <Windows.h>
#include <gl/GL.h>
#include <iostream>

static void (*g_pFn_Patch)(const std::string&)		= nullptr;
static void (*g_pFn_UnPatch)(const std::string&)	= nullptr;

const char* functionsToHook[] = {	"glColor3f", 
									"glClearColor", 
									"glClear", 
									"glBegin", 
									"glVertex3f", 
									"glEnd", 
									"glfwPollEvents",

									"glViewport",
									"glGenVertexArrays",
									"glBindVertexArray",
									"glGenBuffers",
									"glBindBuffer",
									"glBufferData",
									"glEnableVertexAttribArray",
									"glVertexAttribPointer",
									"glCreateShader",
									"glShaderSource",
									"glCompileShader",
									"glCreateProgram",
									"glAttachShader",
									"glLinkProgram",
									"glUseProgram",
									"glDrawArrays",
									"glDrawElements",
									"glGenTextures",
									"glBindTexture",
									"glTexImage2D",
									"glTexParameteri",
									"glActiveTexture",
									"glGenFramebuffers",
									"glBindFramebuffer",
									"glFramebufferTexture2D",
									"glUniform1i", 
									"glUniform1f", 
									"glUniform2f", 
									"glUniform3f", 
									"glUniform4f", 
									"glUniform4fv",
									"glUniformMatrix4fv",
									"glGetUniformLocation",
									"glEnable",
									"glDisable",
									"glBlendFunc",
									"glDepthFunc",
									"glCullFace"
};

const int	iFunctionsToHookCount = 45;

static void (*g_pFnNext_glColor3f)					(GLfloat red, GLfloat green, GLfloat blue) = nullptr;
static void (*g_pFnNext_glClearColor)				(GLclampf red, GLclampf green, GLclampf blue, GLclampf alpha) = nullptr;
static void (*g_pFnNext_glClear)					(GLbitfield mask) = nullptr;
static void (*g_pFnNext_glBegin)					(GLenum mode) = nullptr;
static void (*g_pFnNext_glVertex3f)					(GLfloat x, GLfloat y, GLfloat z) = nullptr;
static void (*g_pFnNext_glEnd)						() = nullptr;
static void (*g_pFnNext_glfwPollEvents)				() = nullptr;

static void (*g_pFnNext_glViewport)					(int x, int y, int w, int h) = nullptr;

static void (*g_pFnNext_glGenVertexArrays)			(int n, unsigned* arrays) = nullptr;
static void (*g_pFnNext_glBindVertexArray)			(unsigned vao) = nullptr;
static void (*g_pFnNext_glGenBuffers)				(int n, unsigned* buffers) = nullptr;
static void (*g_pFnNext_glBindBuffer)				(uint32_t target, unsigned buffer) = nullptr;
static void (*g_pFnNext_glBufferData)				(uint32_t target, ptrdiff_t size, const void* data, uint32_t usage) = nullptr;
static void (*g_pFnNext_glEnableVertexAttribArray)	(unsigned index) = nullptr;
static void (*g_pFnNext_glVertexAttribPointer)		(unsigned index, int size, uint32_t type, bool normalized, int stride, const void* pointer) = nullptr;
static void (*g_pFnNext_glCreateShader)				(uint32_t type) = nullptr;
static void (*g_pFnNext_glShaderSource)				(unsigned shader, const std::string& src) = nullptr;
static void (*g_pFnNext_glCompileShader)			(unsigned shader) = nullptr;
static void (*g_pFnNext_glCreateProgram)			() = nullptr;
static void (*g_pFnNext_glAttachShader)				(unsigned program, unsigned shader) = nullptr;
static void (*g_pFnNext_glLinkProgram)				(unsigned program) = nullptr;
static void (*g_pFnNext_glUseProgram)				(unsigned program) = nullptr;
static void (*g_pFnNext_glDrawArrays)				(uint32_t mode, int first, int count) = nullptr;
static void (*g_pFnNext_glDrawElements)				(uint32_t mode, int count, uint32_t type, const void* indices) = nullptr;

static void (*g_pFnNext_glGenTextures)				(int n, unsigned* textures) = nullptr;
static void (*g_pFnNext_glBindTexture)				(uint32_t target, unsigned tex) = nullptr;
static void (*g_pFnNext_glTexImage2D)				(uint32_t target, int level, int internalFormat, int width, int height, int border, uint32_t format, uint32_t type, const void* data) = nullptr;
static void (*g_pFnNext_glTexParameteri)			(uint32_t target, uint32_t pname, int param) = nullptr;
static void (*g_pFnNext_glActiveTexture)			(uint32_t texture) = nullptr;

static void (*g_pFnNext_glGenFramebuffers)			(int n, unsigned* fbos) = nullptr;
static void (*g_pFnNext_glBindFramebuffer)			(uint32_t target, unsigned fbo) = nullptr;
static void (*g_pFnNext_glFramebufferTexture2D)		(uint32_t target, uint32_t attachment, uint32_t textarget, unsigned texture, int level) = nullptr;

static void (*g_pFnNext_glUniform1i)				(int location, int v0) = nullptr;
static void (*g_pFnNext_glUniform1f)				(int location, float v0) = nullptr;
static void (*g_pFnNext_glUniform2f)				(int location, float x, float y) = nullptr;
static void (*g_pFnNext_glUniform3f)				(int location, float x, float y, float z) = nullptr;
static void (*g_pFnNext_glUniform4f)				(int location, float x, float y, float z, float w) = nullptr;
static void (*g_pFnNext_glUniform4fv)				(int location, int count, const float* value) = nullptr;
static void (*g_pFnNext_glUniformMatrix4fv)			(int location, int count, bool transpose, const float* value) = nullptr;
static void (*g_pFnNext_glGetUniformLocation)		(GLuint program, const GLchar* name) = nullptr;

static void (*g_pFnNext_glEnable)					(uint32_t cap) = nullptr;
static void (*g_pFnNext_glDisable)					(uint32_t cap) = nullptr;
static void (*g_pFnNext_glBlendFunc)				(uint32_t sfactor, uint32_t dfactor) = nullptr;
static void (*g_pFnNext_glDepthFunc)				(uint32_t func) = nullptr;
static void (*g_pFnNext_glCullFace)					(uint32_t mode) = nullptr;

#define CAPTURE_FILE "..\\x64\\Debug\\capture_1.gltrace"
gltrace::Logger logger(CAPTURE_FILE);

void APIENTRY Hooked_g_pFnNext_glColor3f(GLfloat red, GLfloat green, GLfloat blue)
{
	gltrace::glColor3f(logger, green, blue, red);

	if (g_pFnNext_glColor3f == ::glColor3f)
	{
		(*g_pFn_UnPatch)("glColor3f");
		::glColor3f(red, green, blue);
		(*g_pFn_Patch)("glColor3f");
	}
	//else
	//{
		//if (g_pFnNext_glColor3f) g_pFnNext_glColor3f(green, blue, red);
	//}
}

void APIENTRY Hooked_g_pFnNext_glClear(GLbitfield mask)
{
	gltrace::glClear(logger, mask);

	(*g_pFn_UnPatch)("glClear");
	::glClear(mask);
	(*g_pFn_Patch)("glClear");

	//if (g_pFnNext_glClear) g_pFnNext_glClear(mask);
}

void APIENTRY Hooked_g_pFnNext_glBegin(GLenum mode)
{
	gltrace::glBegin(logger, mode);

	(*g_pFn_UnPatch)("glBegin");
	::glBegin(mode);
	(*g_pFn_Patch)("glBegin");

	//if (g_pFnNext_glBegin) g_pFnNext_glBegin(mode);
}

void APIENTRY Hooked_g_pFnNext_glVertex3f(GLfloat x, GLfloat y, GLfloat z)
{
	gltrace::glVertex3f(logger, y, x, z);

	(*g_pFn_UnPatch)("glVertex3f");
	::glVertex3f(y, x, z);
	(*g_pFn_Patch)("glVertex3f");

	//if (g_pFnNext_glVertex3f) g_pFnNext_glVertex3f(y, x, z);
}

void APIENTRY Hooked_g_pFnNext_glEnd()
{
	gltrace::glEnd(logger);

	(*g_pFn_UnPatch)("glEnd");
	::glEnd();
	(*g_pFn_Patch)("glEnd");

	//if (g_pFnNext_glEnd) g_pFnNext_glEnd();
}

static uint32_t g_iFrameMarker = 0;
void APIENTRY Hooked_g_pFnNext_glfwPollEvents()
{
	gltrace::glfwPollEvents(logger, g_iFrameMarker++);

	(*g_pFn_UnPatch)("glfwPollEvents");
	::glfwPollEvents();
	(*g_pFn_Patch)("glfwPollEvents");

	//if (g_pFnNext_glfwPollEvents) g_pFnNext_glfwPollEvents();
}

void APIENTRY Hooked_g_pFnNext_glViewport(int x, int y, int w, int h)
{
	(*g_pFn_UnPatch)("glViewport");
	::glViewport(x, y, w, h);
	(*g_pFn_Patch)("glViewport");

	gltrace::glViewport(logger, x, y, w, h);
}

void APIENTRY Hooked_g_pFnNext_glClearColor(float r, float g, float b, float a)
{
	(*g_pFn_UnPatch)("glClearColor");
	::glClearColor(r, g, b, a);
	(*g_pFn_Patch)("glClearColor");

	gltrace::glClearColor(logger, r, g, b, a);
}

void APIENTRY Hooked_g_pFnNext_glGenVertexArrays(int n, unsigned* arrays) 
{
	(*g_pFn_UnPatch)("glGenVertexArrays");
	::glGenVertexArrays(n, arrays);
	(*g_pFn_Patch)("glGenVertexArrays");

	gltrace::glGenVertexArrays(logger, n, arrays);
}

void APIENTRY Hooked_g_pFnNext_glBindVertexArray(unsigned vao) 
{
	(*g_pFn_UnPatch)("glBindVertexArray");
	::glBindVertexArray(vao);
	(*g_pFn_Patch)("glBindVertexArray");

	gltrace::glBindVertexArray(logger, vao);
}

void APIENTRY Hooked_g_pFnNext_glGenBuffers(int n, unsigned* buffers) 
{
	(*g_pFn_UnPatch)("glGenBuffers");
	::glGenBuffers(n, buffers);
	(*g_pFn_Patch)("glGenBuffers");

	gltrace::glGenBuffers(logger, n, buffers);
}

void APIENTRY Hooked_g_pFnNext_glBindBuffer(uint32_t target, unsigned buffer) 
{
	(*g_pFn_UnPatch)("glBindBuffer");
	::glBindBuffer(target, buffer);
	(*g_pFn_Patch)("glBindBuffer");

	gltrace::glBindBuffer(logger, target, buffer);
}

void APIENTRY Hooked_g_pFnNext_glBufferData(uint32_t target, ptrdiff_t size, const void* data, uint32_t usage) 
{
	(*g_pFn_UnPatch)("glBufferData");
	::glBufferData(target, size, data, usage);
	(*g_pFn_Patch)("glBufferData");

	gltrace::glBufferData(logger, target, size, data, usage);
}

void APIENTRY Hooked_g_pFnNext_glEnableVertexAttribArray(unsigned index) 
{
	gltrace::glEnableVertexAttribArray(logger, index);

	(*g_pFn_UnPatch)("glEnableVertexAttribArray");
	::glEnableVertexAttribArray(index);
	(*g_pFn_Patch)("glEnableVertexAttribArray");
}

void APIENTRY Hooked_g_pFnNext_glVertexAttribPointer(unsigned index, int size, uint32_t type, bool normalized, int stride, const void* pointer) 
{
	(*g_pFn_UnPatch)("glVertexAttribPointer");
	::glVertexAttribPointer(index, size, type, normalized, stride, pointer);
	(*g_pFn_Patch)("glVertexAttribPointer");

	gltrace::glVertexAttribPointer(logger, index, size, type, normalized, stride, pointer);
}

unsigned APIENTRY Hooked_g_pFnNext_glCreateShader(uint32_t type)
{
	(*g_pFn_UnPatch)("glCreateShader");
	unsigned sRet = ::glCreateShader(type);
	(*g_pFn_Patch)("glCreateShader");

	gltrace::glCreateShader(logger, sRet, type);

	return sRet;
}

void APIENTRY Hooked_g_pFnNext_glShaderSource(GLuint shader, GLsizei count, const GLchar** strings, const GLint* lengths)
{
	(*g_pFn_UnPatch)("glShaderSource");
	::glShaderSource(shader, count, strings, NULL);
	(*g_pFn_Patch)("glShaderSource");

	gltrace::glShaderSource(logger, shader, std::string(*strings));
}

void APIENTRY Hooked_g_pFnNext_glCompileShader(unsigned shader)
{
	(*g_pFn_UnPatch)("glCompileShader");
	::glCompileShader(shader);
	(*g_pFn_Patch)("glCompileShader");

	gltrace::glCompileShader(logger, shader);
}

unsigned APIENTRY Hooked_g_pFnNext_glCreateProgram()
{
	(*g_pFn_UnPatch)("glCreateProgram");
	unsigned progId = ::glCreateProgram();
	(*g_pFn_Patch)("glCreateProgram");

	gltrace::glCreateProgram(logger, progId);

	return progId;
}

void APIENTRY Hooked_g_pFnNext_glAttachShader(unsigned program, unsigned shader)
{
	(*g_pFn_UnPatch)("glAttachShader");
	::glAttachShader(program, shader);
	(*g_pFn_Patch)("glAttachShader");

	gltrace::glAttachShader(logger, program, shader);
}

void APIENTRY Hooked_g_pFnNext_glLinkProgram(unsigned program)
{
	(*g_pFn_UnPatch)("glLinkProgram");
	::glLinkProgram(program);
	(*g_pFn_Patch)("glLinkProgram");

	gltrace::glLinkProgram(logger, program);
}

void APIENTRY Hooked_g_pFnNext_glUseProgram(unsigned program)
{
	(*g_pFn_UnPatch)("glUseProgram");
	::glUseProgram(program);
	(*g_pFn_Patch)("glUseProgram");

	gltrace::glUseProgram(logger, program);
}

void APIENTRY Hooked_g_pFnNext_glDrawArrays(uint32_t mode, int first, int count)
{
	(*g_pFn_UnPatch)("glDrawArrays");
	::glDrawArrays(mode, first, count);
	(*g_pFn_Patch)("glDrawArrays");

	gltrace::glDrawArrays(logger, mode, first, count);
}

void APIENTRY Hooked_g_pFnNext_glDrawElements(uint32_t mode, int count, uint32_t type, const void* indices)
{
	(*g_pFn_UnPatch)("glDrawElements");
	::glDrawElements(mode, count, type, indices);
	(*g_pFn_Patch)("glDrawElements");

	gltrace::glDrawElements(logger, mode, count, type, indices);
}

void APIENTRY Hooked_g_pFnNext_glGenTextures(int n, unsigned* textures)
{
	(*g_pFn_UnPatch)("glGenTextures");
	::glGenTextures(n, textures);
	(*g_pFn_Patch)("glGenTextures");

	gltrace::glGenTextures(logger, n, textures);
}

void APIENTRY Hooked_g_pFnNext_glBindTexture(uint32_t target, unsigned tex)
{
	(*g_pFn_UnPatch)("glBindTexture");
	::glBindTexture(target, tex);
	(*g_pFn_Patch)("glBindTexture");

	gltrace::glBindTexture(logger, target, tex);
}

void APIENTRY Hooked_g_pFnNext_glTexImage2D(uint32_t target, int level, int internalFormat, int width, int height, int border, uint32_t format, uint32_t type, const void* data)
{
	(*g_pFn_UnPatch)("glTexImage2D");
	::glTexImage2D(target, level, internalFormat, width, height, border, format, type, data);
	(*g_pFn_Patch)("glTexImage2D");

	gltrace::glTexImage2D(logger, target, level, internalFormat, width, height, border, format, type, data);
}

void APIENTRY Hooked_g_pFnNext_glTexParameteri(uint32_t target, uint32_t pname, int param)
{
	(*g_pFn_UnPatch)("glTexParameteri");
	::glTexParameteri(target, pname, param);
	(*g_pFn_Patch)("glTexParameteri");

	gltrace::glTexParameteri(logger, target, pname, param);
}

void APIENTRY Hooked_g_pFnNext_glActiveTexture(uint32_t texture)
{
	(*g_pFn_UnPatch)("glActiveTexture");
	::glActiveTexture(texture);
	(*g_pFn_Patch)("glActiveTexture");

	gltrace::glActiveTexture(logger, texture);
}

void APIENTRY Hooked_g_pFnNext_glGenFramebuffers(int n, unsigned* fbos)
{
	(*g_pFn_UnPatch)("glGenFramebuffers");
	::glGenFramebuffers(n, fbos);
	(*g_pFn_Patch)("glGenFramebuffers");

	gltrace::glGenFramebuffers(logger, n, fbos);
}

void APIENTRY Hooked_g_pFnNext_glBindFramebuffer(uint32_t target, unsigned fbo)
{
	(*g_pFn_UnPatch)("glBindFramebuffer");
	::glBindFramebuffer(target, fbo);
	(*g_pFn_Patch)("glBindFramebuffer");

	gltrace::glBindFramebuffer(logger, target, fbo);
}

void APIENTRY Hooked_g_pFnNext_glFramebufferTexture2D(uint32_t target, uint32_t attachment, uint32_t textarget, unsigned texture, int level)
{
	(*g_pFn_UnPatch)("glFramebufferTexture2D");
	::glFramebufferTexture2D(target, attachment, textarget, texture, level);
	(*g_pFn_Patch)("glFramebufferTexture2D");

	gltrace::glFramebufferTexture2D(logger, target, attachment, textarget, texture, level);
}

void APIENTRY Hooked_g_pFnNext_glUniform1i(int location, int v0)
{
	(*g_pFn_UnPatch)("glUniform1i");
	::glUniform1i(location, v0);
	(*g_pFn_Patch)("glUniform1i");

	gltrace::glUniform1i(logger, location, v0);
}

void APIENTRY Hooked_g_pFnNext_glUniform1f(int location, float v0)
{
	(*g_pFn_UnPatch)("glUniform1f");
	::glUniform1f(location, v0);
	(*g_pFn_Patch)("glUniform1f");

	gltrace::glUniform1f(logger, location, v0);
}

void APIENTRY Hooked_g_pFnNext_glUniform2f(int location, float x, float y)
{
	(*g_pFn_UnPatch)("glUniform2f");
	::glUniform2f(location, x, y);
	(*g_pFn_Patch)("glUniform2f");

	gltrace::glUniform2f(logger, location, x, y);
}

void APIENTRY Hooked_g_pFnNext_glUniform3f(int location, float x, float y, float z)
{
	(*g_pFn_UnPatch)("glUniform3f");
	::glUniform3f(location, x, y, z);
	(*g_pFn_Patch)("glUniform3f");

	gltrace::glUniform3f(logger, location, x, y, z);
}

void APIENTRY Hooked_g_pFnNext_glUniform4f(int location, float x, float y, float z, float w)
{
	(*g_pFn_UnPatch)("glUniform4f");
	::glUniform4f(location, x, y, z, w);
	(*g_pFn_Patch)("glUniform4f");

	gltrace::glUniform4f(logger, location, x, y, z, w);
}

void APIENTRY Hooked_g_pFnNext_glUniform4fv(int location, int count, const float* value)
{
	(*g_pFn_UnPatch)("glUniform4fv");
	::glUniform4fv(location, count, value);
	(*g_pFn_Patch)("glUniform4fv");

	gltrace::glUniform4fv(logger, location, count, value);
}

void APIENTRY Hooked_g_pFnNext_glUniformMatrix4fv(int location, int count, bool transpose, const float* value)
{
	(*g_pFn_UnPatch)("glUniformMatrix4fv");
	::glUniformMatrix4fv(location, count, transpose, value);
	(*g_pFn_Patch)("glUniformMatrix4fv");

	gltrace::glUniformMatrix4fv(logger, location, count, transpose, value);
}

void APIENTRY Hooked_g_pFnNext_glGetUniformLocation(GLuint program, const GLchar* name)
{
	(*g_pFn_UnPatch)("glGetUniformLocation");
	GLint iUniformLoc = ::glGetUniformLocation(program, name);
	(*g_pFn_Patch)("glGetUniformLocation");

	gltrace::glGetUniformLocation(logger, iUniformLoc, program, name);
}

void APIENTRY Hooked_g_pFnNext_glEnable(uint32_t cap)
{
	(*g_pFn_UnPatch)("glEnable");
	::glEnable(cap);
	(*g_pFn_Patch)("glEnable");

	gltrace::glEnable(logger, cap);
}

void APIENTRY Hooked_g_pFnNext_glDisable(uint32_t cap)
{
	(*g_pFn_UnPatch)("glDisable");
	::glDisable(cap);
	(*g_pFn_Patch)("glDisable");

	gltrace::glDisable(logger, cap);
}

void APIENTRY Hooked_g_pFnNext_glBlendFunc(uint32_t sfactor, uint32_t dfactor)
{
	(*g_pFn_UnPatch)("glBlendFunc");
	::glBlendFunc(sfactor, dfactor);
	(*g_pFn_Patch)("glBlendFunc");

	gltrace::glBlendFunc(logger, sfactor, dfactor);
}

void APIENTRY Hooked_g_pFnNext_glDepthFunc(uint32_t func)
{
	(*g_pFn_UnPatch)("glDepthFunc");
	::glDepthFunc(func);
	(*g_pFn_Patch)("glDepthFunc");

	gltrace::glDepthFunc(logger, func);
}

void APIENTRY Hooked_g_pFnNext_glCullFace(uint32_t mode)
{
	(*g_pFn_UnPatch)("glCullFace");
	::glCullFace(mode);
	(*g_pFn_Patch)("glCullFace");

	gltrace::glCullFace(logger, mode);
}

/////////////////////////////////////////////////////////////////////////////////////

extern "C" __declspec(dllexport) void OGLLayer_SetPatchUnPatchFunctions(void* pFn_Patch, void* pFn_UnPatch)
{
	g_pFn_Patch		= (void (*)(const std::string&))pFn_Patch;
	g_pFn_UnPatch	= (void (*)(const std::string&))pFn_UnPatch;
}

extern "C" __declspec(dllexport) const char** OGLLayer_GetFunctionNames(int* iCount)
{
	*iCount = iFunctionsToHookCount;
	return functionsToHook;
}

extern "C" __declspec(dllexport) void* OGLLayer_GetHookedProcAddress(const char* pFuncName, void* pFnNext)
{
	if (strcmp(pFuncName, "glColor3f") == 0)
	{
		g_pFnNext_glColor3f = (void (*)(GLfloat, GLfloat, GLfloat))pFnNext;
		return (void*)&Hooked_g_pFnNext_glColor3f;
	}
	else
	if (strcmp(pFuncName, "glClearColor") == 0)
	{
		g_pFnNext_glClearColor = (void (*)(GLclampf, GLclampf, GLclampf, GLclampf))pFnNext;
		return (void*)&Hooked_g_pFnNext_glClearColor;
	}
	else
	if (strcmp(pFuncName, "glClear") == 0)
	{
		g_pFnNext_glClear = (void (*)(GLbitfield))pFnNext;
		return (void*)&Hooked_g_pFnNext_glClear;
	}
	else
	if (strcmp(pFuncName, "glBegin") == 0)
	{
		g_pFnNext_glBegin = (void (*)(GLenum))pFnNext;
		return (void*)&Hooked_g_pFnNext_glBegin;
	}
	else
	if (strcmp(pFuncName, "glVertex3f") == 0)
	{
		g_pFnNext_glVertex3f = (void (*)(GLfloat, GLfloat, GLfloat))pFnNext;
		return (void*)&Hooked_g_pFnNext_glVertex3f;
	}
	else
	if (strcmp(pFuncName, "glEnd") == 0)
	{
		g_pFnNext_glEnd = (void (*)())pFnNext;
		return (void*)&Hooked_g_pFnNext_glEnd;
	}
	else
	if (strcmp(pFuncName, "glfwPollEvents") == 0)
	{
		g_pFnNext_glfwPollEvents = (void (*)())pFnNext;
		return (void*)&Hooked_g_pFnNext_glfwPollEvents;
	}
	else
	if (strcmp(pFuncName, "glViewport") == 0)
	{
		g_pFnNext_glViewport = (void (*)(int, int, int, int))pFnNext;
		return (void*)&Hooked_g_pFnNext_glViewport;
	}
	else
	if (strcmp(pFuncName, "glGenVertexArrays") == 0)
	{
		g_pFnNext_glGenVertexArrays = (void (*)(int, unsigned*))pFnNext;
		return (void*)&Hooked_g_pFnNext_glGenVertexArrays;
	}
	else
	if (strcmp(pFuncName, "glBindVertexArray") == 0)
	{
		g_pFnNext_glBindVertexArray = (void (*)(unsigned))pFnNext;
		return (void*)&Hooked_g_pFnNext_glBindVertexArray;
	}
	else
	if (strcmp(pFuncName, "glGenBuffers") == 0)
	{
		g_pFnNext_glGenBuffers = (void (*)(int, unsigned*))pFnNext;
		return (void*)&Hooked_g_pFnNext_glGenBuffers;
	}
	else
	if (strcmp(pFuncName, "glBindBuffer") == 0)
	{
		g_pFnNext_glBindBuffer = (void (*)(uint32_t, unsigned))pFnNext;
		return (void*)&Hooked_g_pFnNext_glBindBuffer;
	}
	else
	if (strcmp(pFuncName, "glBufferData") == 0)
	{
		g_pFnNext_glBufferData = (void (*)(uint32_t, ptrdiff_t, const void*, uint32_t))pFnNext;
		return (void*)&Hooked_g_pFnNext_glBufferData;
	}
	else
	if (strcmp(pFuncName, "glEnableVertexAttribArray") == 0)
	{
		g_pFnNext_glEnableVertexAttribArray = (void (*)(unsigned))pFnNext;
		return (void*)&Hooked_g_pFnNext_glEnableVertexAttribArray;
	}
	else
	if (strcmp(pFuncName, "glVertexAttribPointer") == 0)
	{
		g_pFnNext_glVertexAttribPointer = (void (*)(unsigned, int, uint32_t, bool, int, const void*))pFnNext;
		return (void*)&Hooked_g_pFnNext_glVertexAttribPointer;
	}
	else
	if (strcmp(pFuncName, "glVertexAttribPointer") == 0)
	{
		g_pFnNext_glVertexAttribPointer = (void (*)(unsigned, int, uint32_t, bool, int, const void*))pFnNext;
		return (void*)&Hooked_g_pFnNext_glVertexAttribPointer;
	}
	else
	if (strcmp(pFuncName, "glCreateShader") == 0)
	{
		g_pFnNext_glCreateShader = (void (*)(uint32_t))pFnNext;
		return (void*)&Hooked_g_pFnNext_glCreateShader;
	}
	else
	if (strcmp(pFuncName, "glShaderSource") == 0)
	{
		g_pFnNext_glShaderSource = (void (*)(unsigned, const std::string&))pFnNext;
		return (void*)&Hooked_g_pFnNext_glShaderSource;
	}
	else
	if (strcmp(pFuncName, "glCompileShader") == 0)
	{
		g_pFnNext_glCompileShader = (void (*)(unsigned))pFnNext;
		return (void*)&Hooked_g_pFnNext_glCompileShader;
	}
	else
	if (strcmp(pFuncName, "glCreateProgram") == 0)
	{
		g_pFnNext_glCreateProgram = (void (*)())pFnNext;
		return (void*)&Hooked_g_pFnNext_glCreateProgram;
	}
	else
	if (strcmp(pFuncName, "glAttachShader") == 0)
	{
		g_pFnNext_glAttachShader = (void (*)(unsigned, unsigned))pFnNext;
		return (void*)&Hooked_g_pFnNext_glAttachShader;
	}
	else
	if (strcmp(pFuncName, "glLinkProgram") == 0)
	{
		g_pFnNext_glLinkProgram = (void (*)(unsigned))pFnNext;
		return (void*)&Hooked_g_pFnNext_glLinkProgram;
	}
	else
	if (strcmp(pFuncName, "glUseProgram") == 0)
	{
		g_pFnNext_glUseProgram = (void (*)(unsigned))pFnNext;
		return (void*)&Hooked_g_pFnNext_glUseProgram;
	}
	else
	if (strcmp(pFuncName, "glDrawArrays") == 0)
	{
		g_pFnNext_glDrawArrays = (void (*)(uint32_t, int, int))pFnNext;
		return (void*)&Hooked_g_pFnNext_glDrawArrays;
	}
	else
	if (strcmp(pFuncName, "glDrawElements") == 0)
	{
		g_pFnNext_glDrawElements = (void (*)(uint32_t, int, uint32_t, const void*))pFnNext;
		return (void*)&Hooked_g_pFnNext_glDrawElements;
	}
	else
	if (strcmp(pFuncName, "glGenTextures") == 0)
	{
		g_pFnNext_glGenTextures = (void (*)(int, unsigned*))pFnNext;
		return (void*)&Hooked_g_pFnNext_glGenTextures;
	}
	else
	if (strcmp(pFuncName, "glBindTexture") == 0)
	{
		g_pFnNext_glBindTexture = (void (*)(uint32_t, unsigned))pFnNext;
		return (void*)&Hooked_g_pFnNext_glBindTexture;
	}
	else
	if (strcmp(pFuncName, "glTexImage2D") == 0)
	{
		g_pFnNext_glTexImage2D = (void (*)(uint32_t, int, int, int, int, int, uint32_t, uint32_t, const void*))pFnNext;
		return (void*)&Hooked_g_pFnNext_glTexImage2D;
	}
	else
	if (strcmp(pFuncName, "glTexParameteri") == 0)
	{
		g_pFnNext_glTexParameteri = (void (*)(uint32_t, uint32_t, int))pFnNext;
		return (void*)&Hooked_g_pFnNext_glTexParameteri;
	}
	else
	if (strcmp(pFuncName, "glActiveTexture") == 0)
	{
		g_pFnNext_glActiveTexture = (void (*)(uint32_t))pFnNext;
		return (void*)&Hooked_g_pFnNext_glActiveTexture;
	}
	else
	if (strcmp(pFuncName, "glGenFramebuffers") == 0)
	{
		g_pFnNext_glGenFramebuffers = (void (*)(int n, unsigned* fbos))pFnNext;
		return (void*)&Hooked_g_pFnNext_glGenFramebuffers;
	}
	else
	if (strcmp(pFuncName, "glBindFramebuffer") == 0)
	{
		g_pFnNext_glBindFramebuffer = (void (*)(uint32_t target, unsigned fbo))pFnNext;
		return (void*)&Hooked_g_pFnNext_glBindFramebuffer;
	}
	else
	if (strcmp(pFuncName, "glFramebufferTexture2D") == 0)
	{
		g_pFnNext_glFramebufferTexture2D = (void (*)(uint32_t target, uint32_t attachment, uint32_t textarget, unsigned texture, int level))pFnNext;
		return (void*)&Hooked_g_pFnNext_glFramebufferTexture2D;
	}
	else
	if (strcmp(pFuncName, "glUniform1i") == 0)
	{
		g_pFnNext_glUniform1i = (void (*)(int location, int v0))pFnNext;
		return (void*)&Hooked_g_pFnNext_glUniform1i;
	}
	else
	if (strcmp(pFuncName, "glUniform1f") == 0)
	{
		g_pFnNext_glUniform1f = (void (*)(int location, float v0))pFnNext;
		return (void*)&Hooked_g_pFnNext_glUniform1f;
	}
	else
	if (strcmp(pFuncName, "glUniform2f") == 0)
	{
		g_pFnNext_glUniform2f = (void (*)(int location, float x, float y))pFnNext;
		return (void*)&Hooked_g_pFnNext_glUniform2f;
	}
	else
	if (strcmp(pFuncName, "glUniform3f") == 0)
	{
		g_pFnNext_glUniform3f = (void (*)(int location, float x, float y, float z))pFnNext;
		return (void*)&Hooked_g_pFnNext_glUniform3f;
	}
	else
	if (strcmp(pFuncName, "glUniform4f") == 0)
	{
		g_pFnNext_glUniform4f = (void (*)(int location, float x, float y, float z, float w))pFnNext;
		return (void*)&Hooked_g_pFnNext_glUniform4f;
	}
	else
	if (strcmp(pFuncName, "glUniform4fv") == 0)
	{
		g_pFnNext_glUniform4fv = (void (*)(int location, int count, const float* value))pFnNext;
		return (void*)&Hooked_g_pFnNext_glUniform4fv;
	}
	else
	if (strcmp(pFuncName, "glUniformMatrix4fv") == 0)
	{
		g_pFnNext_glUniformMatrix4fv = (void (*)(int location, int count, bool transpose, const float* value))pFnNext;
		return (void*)&Hooked_g_pFnNext_glUniformMatrix4fv;
	}
	else
	if (strcmp(pFuncName, "glGetUniformLocation") == 0)
	{
		g_pFnNext_glGetUniformLocation = (void (*)(GLuint program, const GLchar * name))pFnNext;
		return (void*)&Hooked_g_pFnNext_glGetUniformLocation;
	}
	else
	if (strcmp(pFuncName, "glEnable") == 0)
	{
		g_pFnNext_glEnable = (void (*)(uint32_t cap))pFnNext;
		return (void*)&Hooked_g_pFnNext_glEnable;
	}
	else
	if (strcmp(pFuncName, "glDisable") == 0)
	{
		g_pFnNext_glDisable = (void (*)(uint32_t cap))pFnNext;
		return (void*)&Hooked_g_pFnNext_glDisable;
	}
	else
	if (strcmp(pFuncName, "glBlendFunc") == 0)
	{
		g_pFnNext_glBlendFunc = (void (*)(uint32_t sfactor, uint32_t dfactor))pFnNext;
		return (void*)&Hooked_g_pFnNext_glBlendFunc;
	}
	else
	if (strcmp(pFuncName, "glDepthFunc") == 0)
	{
		g_pFnNext_glDepthFunc = (void (*)(uint32_t func))pFnNext;
		return (void*)&Hooked_g_pFnNext_glDepthFunc;
	}
	else
	if (strcmp(pFuncName, "glCullFace") == 0)
	{
		g_pFnNext_glCullFace = (void (*)(uint32_t mode))pFnNext;
		return (void*)&Hooked_g_pFnNext_glCullFace;
	}

	return nullptr;
}
