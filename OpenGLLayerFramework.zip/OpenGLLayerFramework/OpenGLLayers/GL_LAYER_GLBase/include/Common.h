#pragma once
#include <Windows.h>
#include <string>
#include <gl/GL.h>

#define UNPATCH_CALL_PATCH(__glCall__, ...) \
    do {                                    \
        (*g_pFn_UnPatch)(#__glCall__);      \
        ::__glCall__(__VA_ARGS__);          \
        (*g_pFn_Patch)(#__glCall__);        \
    } while (0);							\

#define UNPATCH_CALL_PATCH_RET(__retVar__, glCall, ...)     \
    do {                                                        \
        (*g_pFn_UnPatch)(#glCall);                          \
        __retVar__ = ::glCall(__VA_ARGS__);                 \
        (*g_pFn_Patch)(#glCall);                            \
    } while (0)                                                 \
