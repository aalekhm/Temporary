﻿#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include "Common.h"

typedef void (*GenericGLFunc)();
static void (*g_pFn_Patch)(const std::string&)								= nullptr;
static void (*g_pFn_UnPatch)(const std::string&)							= nullptr;

const char* functionsToHook[] = {	"glColor3f", 
									"glClearColor", 
									"glClear", 
									"glBegin", 
									"glVertex3f", 
									"glEnd", 
									"glfwPollEvents",

									"glViewport",
									"glGenVertexArrays",
									"glBindVertexArray",
									"glGenBuffers",
									"glBindBuffer",
									"glBufferData",
									"glEnableVertexAttribArray",
									"glVertexAttribPointer",
									"glCreateShader",
									"glShaderSource",
									"glCompileShader",
									"glCreateProgram",
									"glAttachShader",
									"glLinkProgram",
									"glDeleteShader",
									"glUseProgram",
									"glDrawArrays",
									"glDrawElements",
									"glGenTextures",
									"glBindTexture",
									"glTexImage2D",
									"glTexParameteri",
									"glActiveTexture",
									"glGenFramebuffers",
									"glBindFramebuffer",
									"glFramebufferTexture2D",
									"glUniform1i", 
									"glUniform1f", 
									"glUniform2f", 
									"glUniform3f", 
									"glUniform4f", 
									"glUniform4fv",
									"glUniformMatrix4fv",
									"glGetUniformLocation",
									"glEnable",
									"glDisable",
									"glBlendFunc",
									"glDepthFunc",
									"glCullFace"
};

const int	iFunctionsToHookCount = 45;

void APIENTRY Hooked_g_pFnNext_glColor3f(GLfloat red, GLfloat green, GLfloat blue)
{
	UNPATCH_CALL_PATCH(glColor3f, red, green, blue);
}

void APIENTRY Hooked_g_pFnNext_glClear(GLbitfield mask)
{
	UNPATCH_CALL_PATCH(glClear, mask);
}

void APIENTRY Hooked_g_pFnNext_glBegin(GLenum mode)
{
	UNPATCH_CALL_PATCH(glBegin, mode);
}

void APIENTRY Hooked_g_pFnNext_glVertex3f(GLfloat x, GLfloat y, GLfloat z)
{
	UNPATCH_CALL_PATCH(glVertex3f, x, y, z);
}

void APIENTRY Hooked_g_pFnNext_glEnd()
{
	UNPATCH_CALL_PATCH(glEnd);
}

void APIENTRY Hooked_g_pFnNext_glfwPollEvents()
{
	UNPATCH_CALL_PATCH(glfwPollEvents);
}

void APIENTRY Hooked_g_pFnNext_glViewport(int x, int y, int w, int h)
{
	UNPATCH_CALL_PATCH(glViewport, x, y, w, h);
}

void APIENTRY Hooked_g_pFnNext_glClearColor(float r, float g, float b, float a)
{
	UNPATCH_CALL_PATCH(glClearColor, r, g, b, a);
}

void APIENTRY Hooked_g_pFnNext_glGenVertexArrays(int n, unsigned* arrays) 
{
	UNPATCH_CALL_PATCH(glGenVertexArrays, n, arrays);
}

void APIENTRY Hooked_g_pFnNext_glBindVertexArray(unsigned vao) 
{
	UNPATCH_CALL_PATCH(glBindVertexArray, vao);
}

void APIENTRY Hooked_g_pFnNext_glGenBuffers(int n, unsigned* buffers) 
{
	UNPATCH_CALL_PATCH(glGenBuffers, n, buffers);
}

void APIENTRY Hooked_g_pFnNext_glBindBuffer(uint32_t target, unsigned buffer) 
{
	UNPATCH_CALL_PATCH(glBindBuffer, target, buffer);
}

void APIENTRY Hooked_g_pFnNext_glBufferData(uint32_t target, ptrdiff_t size, const void* data, uint32_t usage) 
{
	UNPATCH_CALL_PATCH(glBufferData, target, size, data, usage);
}

void APIENTRY Hooked_g_pFnNext_glEnableVertexAttribArray(unsigned index) 
{
	UNPATCH_CALL_PATCH(glEnableVertexAttribArray, index);
}

void APIENTRY Hooked_g_pFnNext_glVertexAttribPointer(unsigned index, int size, uint32_t type, bool normalized, int stride, const void* pointer) 
{
	UNPATCH_CALL_PATCH(glVertexAttribPointer, index, size, type, normalized, stride, pointer);
}

unsigned APIENTRY Hooked_g_pFnNext_glCreateShader(uint32_t type)
{
	unsigned sRet;
	UNPATCH_CALL_PATCH_RET(sRet, glCreateShader, type);

	return sRet;
}

void APIENTRY Hooked_g_pFnNext_glShaderSource(GLuint shader, GLsizei count, const GLchar** strings, const GLint* lengths)
{
	UNPATCH_CALL_PATCH(glShaderSource, shader, count, strings, NULL);
}

void APIENTRY Hooked_g_pFnNext_glCompileShader(unsigned shader)
{
	UNPATCH_CALL_PATCH(glCompileShader, shader);
}

unsigned APIENTRY Hooked_g_pFnNext_glCreateProgram()
{
	unsigned progId;
	UNPATCH_CALL_PATCH_RET(progId, glCreateProgram);

	return progId;
}

void APIENTRY Hooked_g_pFnNext_glAttachShader(unsigned program, unsigned shader)
{
	UNPATCH_CALL_PATCH(glAttachShader, program, shader);
}

void APIENTRY Hooked_g_pFnNext_glLinkProgram(unsigned program)
{
	UNPATCH_CALL_PATCH(glLinkProgram, program);
}

void APIENTRY Hooked_g_pFnNext_glUseProgram(unsigned program)
{
	UNPATCH_CALL_PATCH(glUseProgram, program);
}

void APIENTRY Hooked_g_pFnNext_glDeleteShader(unsigned program)
{
	UNPATCH_CALL_PATCH(glDeleteShader, program);
}

void APIENTRY Hooked_g_pFnNext_glDrawArrays(uint32_t mode, int first, int count)
{
	UNPATCH_CALL_PATCH(glDrawArrays, mode, first, count);
}

void APIENTRY Hooked_g_pFnNext_glDrawElements(uint32_t mode, int count, uint32_t type, const void* indices)
{
	UNPATCH_CALL_PATCH(glDrawElements, mode, count, type, (indices == nullptr) ? 0 : indices);
}

void APIENTRY Hooked_g_pFnNext_glGenTextures(int n, unsigned* textures)
{
	UNPATCH_CALL_PATCH(glGenTextures, n, textures);
}

void APIENTRY Hooked_g_pFnNext_glBindTexture(uint32_t target, unsigned tex)
{
	UNPATCH_CALL_PATCH(glBindTexture, target, tex);
}

void APIENTRY Hooked_g_pFnNext_glTexImage2D(uint32_t target, int level, int internalFormat, int width, int height, int border, uint32_t format, uint32_t type, const void* data)
{
	UNPATCH_CALL_PATCH(glTexImage2D, target, level, internalFormat, width, height, border, format, type, data);
}

void APIENTRY Hooked_g_pFnNext_glTexParameteri(uint32_t target, uint32_t pname, int param)
{
	UNPATCH_CALL_PATCH(glTexParameteri, target, pname, param);
}

void APIENTRY Hooked_g_pFnNext_glActiveTexture(uint32_t texture)
{
	UNPATCH_CALL_PATCH(glActiveTexture, texture);
}

void APIENTRY Hooked_g_pFnNext_glGenFramebuffers(int n, unsigned* fbos)
{
	UNPATCH_CALL_PATCH(glGenFramebuffers, n, fbos);
}

void APIENTRY Hooked_g_pFnNext_glBindFramebuffer(uint32_t target, unsigned fbo)
{
	UNPATCH_CALL_PATCH(glBindFramebuffer, target, fbo);
}

void APIENTRY Hooked_g_pFnNext_glFramebufferTexture2D(uint32_t target, uint32_t attachment, uint32_t textarget, unsigned texture, int level)
{
	UNPATCH_CALL_PATCH(glFramebufferTexture2D, target, attachment, textarget, texture, level);
}

void APIENTRY Hooked_g_pFnNext_glUniform1i(int location, int v0)
{
	UNPATCH_CALL_PATCH(glUniform1i, location, v0);
}

void APIENTRY Hooked_g_pFnNext_glUniform1f(int location, float v0)
{
	UNPATCH_CALL_PATCH(glUniform1f, location, v0);
}

void APIENTRY Hooked_g_pFnNext_glUniform2f(int location, float x, float y)
{
	UNPATCH_CALL_PATCH(glUniform2f, location, x, y);
}

void APIENTRY Hooked_g_pFnNext_glUniform3f(int location, float x, float y, float z)
{
	UNPATCH_CALL_PATCH(glUniform3f, location, x, y, z);
}

void APIENTRY Hooked_g_pFnNext_glUniform4f(int location, float x, float y, float z, float w)
{
	UNPATCH_CALL_PATCH(glUniform4f, location, x, y, z, w);
}

void APIENTRY Hooked_g_pFnNext_glUniform4fv(int location, int count, const float* value)
{
	UNPATCH_CALL_PATCH(glUniform4fv, location, count, value);
}

void APIENTRY Hooked_g_pFnNext_glUniformMatrix4fv(int location, int count, bool transpose, const float* value)
{
	UNPATCH_CALL_PATCH(glUniformMatrix4fv, location, count, transpose, value);
}

GLint APIENTRY Hooked_g_pFnNext_glGetUniformLocation(GLuint program, const GLchar* name)
{
	GLint iUniformLoc;
	UNPATCH_CALL_PATCH_RET(iUniformLoc, glGetUniformLocation, program, name);

	return iUniformLoc;
}

void APIENTRY Hooked_g_pFnNext_glEnable(uint32_t cap)
{
	UNPATCH_CALL_PATCH(glEnable, cap);
}

void APIENTRY Hooked_g_pFnNext_glDisable(uint32_t cap)
{
	UNPATCH_CALL_PATCH(glDisable, cap);
}

void APIENTRY Hooked_g_pFnNext_glBlendFunc(uint32_t sfactor, uint32_t dfactor)
{
	UNPATCH_CALL_PATCH(glBlendFunc, sfactor, dfactor);
}

void APIENTRY Hooked_g_pFnNext_glDepthFunc(uint32_t func)
{
	UNPATCH_CALL_PATCH(glDepthFunc, func);
}

void APIENTRY Hooked_g_pFnNext_glCullFace(uint32_t mode)
{
	UNPATCH_CALL_PATCH(glCullFace, mode);
}

/////////////////////////////////////////////////////////////////////////////////////

extern "C" __declspec(dllexport) void OGLLayer_SetNextInChain(int32_t iModuleID, void* pFn_CallNextInChain)
{
}

extern "C" __declspec(dllexport) void OGLLayer_SetPatchUnPatchFunctions(void* pFn_Patch, void* pFn_UnPatch)
{
	g_pFn_Patch		= (void (*)(const std::string&))pFn_Patch;
	g_pFn_UnPatch	= (void (*)(const std::string&))pFn_UnPatch;
}

extern "C" __declspec(dllexport) const char** OGLLayer_GetFunctionNames(int* iCount)
{
	*iCount = iFunctionsToHookCount;
	return functionsToHook;
}

extern "C" __declspec(dllexport) void* OGLLayer_GetHookedProcAddress(const char* pFuncName, void* pFnNext)
{
	if (strcmp(pFuncName, "glColor3f") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glColor3f;
	}
	else
	if (strcmp(pFuncName, "glClearColor") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glClearColor;
	}
	else
	if (strcmp(pFuncName, "glClear") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glClear;
	}
	else
	if (strcmp(pFuncName, "glBegin") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glBegin;
	}
	else
	if (strcmp(pFuncName, "glVertex3f") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glVertex3f;
	}
	else
	if (strcmp(pFuncName, "glEnd") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glEnd;
	}
	else
	if (strcmp(pFuncName, "glfwPollEvents") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glfwPollEvents;
	}
	else
	if (strcmp(pFuncName, "glViewport") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glViewport;
	}
	else
	if (strcmp(pFuncName, "glGenVertexArrays") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glGenVertexArrays;
	}
	else
	if (strcmp(pFuncName, "glBindVertexArray") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glBindVertexArray;
	}
	else
	if (strcmp(pFuncName, "glGenBuffers") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glGenBuffers;
	}
	else
	if (strcmp(pFuncName, "glBindBuffer") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glBindBuffer;
	}
	else
	if (strcmp(pFuncName, "glBufferData") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glBufferData;
	}
	else
	if (strcmp(pFuncName, "glEnableVertexAttribArray") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glEnableVertexAttribArray;
	}
	else
	if (strcmp(pFuncName, "glVertexAttribPointer") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glVertexAttribPointer;
	}
	else
	if (strcmp(pFuncName, "glVertexAttribPointer") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glVertexAttribPointer;
	}
	else
	if (strcmp(pFuncName, "glCreateShader") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glCreateShader;
	}
	else
	if (strcmp(pFuncName, "glShaderSource") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glShaderSource;
	}
	else
	if (strcmp(pFuncName, "glCompileShader") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glCompileShader;
	}
	else
	if (strcmp(pFuncName, "glCreateProgram") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glCreateProgram;
	}
	else
	if (strcmp(pFuncName, "glAttachShader") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glAttachShader;
	}
	else
	if (strcmp(pFuncName, "glLinkProgram") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glLinkProgram;
	}
	else
	if (strcmp(pFuncName, "glUseProgram") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glUseProgram;
	}
	else
	if (strcmp(pFuncName, "glDeleteShader") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glDeleteShader;
	}
	else
	if (strcmp(pFuncName, "glDrawArrays") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glDrawArrays;
	}
	else
	if (strcmp(pFuncName, "glDrawElements") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glDrawElements;
	}
	else
	if (strcmp(pFuncName, "glGenTextures") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glGenTextures;
	}
	else
	if (strcmp(pFuncName, "glBindTexture") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glBindTexture;
	}
	else
	if (strcmp(pFuncName, "glTexImage2D") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glTexImage2D;
	}
	else
	if (strcmp(pFuncName, "glTexParameteri") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glTexParameteri;
	}
	else
	if (strcmp(pFuncName, "glActiveTexture") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glActiveTexture;
	}
	else
	if (strcmp(pFuncName, "glGenFramebuffers") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glGenFramebuffers;
	}
	else
	if (strcmp(pFuncName, "glBindFramebuffer") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glBindFramebuffer;
	}
	else
	if (strcmp(pFuncName, "glFramebufferTexture2D") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glFramebufferTexture2D;
	}
	else
	if (strcmp(pFuncName, "glUniform1i") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glUniform1i;
	}
	else
	if (strcmp(pFuncName, "glUniform1f") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glUniform1f;
	}
	else
	if (strcmp(pFuncName, "glUniform2f") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glUniform2f;
	}
	else
	if (strcmp(pFuncName, "glUniform3f") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glUniform3f;
	}
	else
	if (strcmp(pFuncName, "glUniform4f") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glUniform4f;
	}
	else
	if (strcmp(pFuncName, "glUniform4fv") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glUniform4fv;
	}
	else
	if (strcmp(pFuncName, "glUniformMatrix4fv") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glUniformMatrix4fv;
	}
	else
	if (strcmp(pFuncName, "glGetUniformLocation") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glGetUniformLocation;
	}
	else
	if (strcmp(pFuncName, "glEnable") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glEnable;
	}
	else
	if (strcmp(pFuncName, "glDisable") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glDisable;
	}
	else
	if (strcmp(pFuncName, "glBlendFunc") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glBlendFunc;
	}
	else
	if (strcmp(pFuncName, "glDepthFunc") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glDepthFunc;
	}
	else
	if (strcmp(pFuncName, "glCullFace") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glCullFace;
	}

	return nullptr;
}
