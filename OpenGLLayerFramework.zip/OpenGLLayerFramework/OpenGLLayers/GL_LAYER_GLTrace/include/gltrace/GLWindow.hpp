#pragma once
#include "Common.hpp"

namespace gltrace
{
    struct WindowInitConfig
    {
        int         width = 960;
        int         height = 640;
        const char* title = "mini-gfxr";
        int         glMajor = 3;
        int         glMinor = 3;
        bool        coreProfile = true;
        bool        vsync = true;
    };

    GLFWwindow* initGLFW(const char* sWindowTitle, bool bProgrammable = true);
	void*	InitGLAndWindow(const WindowInitConfig& wCfg, bool bUseProgrammable = true);
	void    PollAndSwap(void* pGlfwWindow);
	bool    WindowShouldClose(void* pGlfwWindow);
	void    DestroyWindow(void* pGlfwWindow);
}
