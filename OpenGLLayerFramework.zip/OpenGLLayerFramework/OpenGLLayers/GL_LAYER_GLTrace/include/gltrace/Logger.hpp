#pragma once
#include "stdio.h"
#include "Common.hpp"
#include "BinaryWriter.hpp"

namespace gltrace
{
    class Logger
    {
        public:
            explicit    Logger(const std::string& sPath);
                        ~Logger();

            bool        Good() const
                        {
                            return m_pWriter && m_pWriter->Good();
                        }

            void        BeginRecord(Op op, uint32_t payloadSize);
            void        WritePayload(const void* data, size_t bytes);
            void        EndRecord();

            template<typename T>
            void        Pod(const T& v)
                        {
                            m_pWriter->Pod(v);
                        }

            void        String(const std::string& s)
                        {
                            m_pWriter->String(s);
                        }
        private:
            std::unique_ptr<BinaryWriter>   m_pWriter;
    };
}