#pragma once
#include "Logger.hpp"

namespace gltrace
{
    void        glColor3f(Logger& L, GLfloat red, GLfloat green, GLfloat blue);
    void        glClearColor(Logger& L, GLclampf red, GLclampf green, GLclampf blue, GLclampf alpha);
    void        glClear(Logger& L, GLbitfield mask);
    void        glBegin(Logger& L, GLenum mode);
    void        glVertex3f(Logger& L, GLfloat x, GLfloat y, GLfloat z);
    void        glEnd(Logger& L);
    void        glfwPollEvents(Logger& L);

    // Capture wrappers
    //void        glColor3f(Logger&, GLfloat red, GLfloat green, GLfloat blue);
    void        glViewport(Logger&, GLint x, GLint y, GLsizei w, GLsizei h);
    void        glGenVertexArrays(Logger&, GLsizei n, GLuint* arrays);
    void        glBindVertexArray(Logger&, GLuint vao);
    void        glGenBuffers(Logger&, GLsizei n, GLuint* buffers);
    void        glBindBuffer(Logger&, GLenum target, GLuint buffer);
    void        glBufferData(Logger&, GLenum target, GLsizeiptr size, const void* data, GLenum usage);
    void        glEnableVertexAttribArray(Logger&, GLuint index);
    void        glVertexAttribPointer(Logger&, GLuint index, GLuint size, GLenum type, bool normalized, GLsizei stride, const void* pointer);
    void        glCreateShader(Logger&, unsigned sRet, GLenum type);
    void        glShaderSource(Logger&, GLuint shader, const std::string& src);
    void        glCompileShader(Logger&, GLuint shader);
    void        glCreateProgram(Logger&, GLuint progId);
    void        glAttachShader(Logger&, GLuint program, GLuint shader);
    void        glLinkProgram(Logger&, GLuint program);
    void        glUseProgram(Logger&, GLuint program);
    void        glDeleteShader(Logger&, GLuint program);
    void        glDrawArrays(Logger&, GLenum mode, GLint first, GLsizei count);
    void        glDrawElements(Logger&, GLenum mode, GLsizei count, GLenum type, const void* indices);

    // Textures
    void        glGenTextures(Logger&, GLsizei n, GLuint* textures);
    void        glBindTexture(Logger&, GLenum target, GLuint tex);
    void        glTexImage2D(Logger&, GLenum target, GLint level, GLint internalFormat, GLsizei width, GLsizei height, GLint border, GLenum format, GLenum type, const void* data);
    void        glTexParameteri(Logger&, GLenum target, GLenum pname, GLint param);
    void        glActiveTexture(Logger&, GLenum texture);

    // Framebuffers
    void        glGenFramebuffers(Logger&, GLsizei n, GLuint* fbos);
    void        glBindFramebuffer(Logger&, GLenum target, GLuint fbo);
    void        glFramebufferTexture2D(Logger&, GLenum target, GLenum attachment, GLenum textarget, GLuint texture, GLint level);

    // Uniforms
    void        glUniform1i(Logger&, GLint location, GLint v0);
    void        glUniform1f(Logger&, GLint location, GLfloat v0);
    void        glUniform2f(Logger&, GLint location, GLfloat x, GLfloat y);
    void        glUniform3f(Logger&, GLint location, GLfloat x, GLfloat y, GLfloat z);
    void        glUniform4f(Logger&, GLint location, GLfloat x, GLfloat y, GLfloat z, GLfloat w);
    void        glUniform4fv(Logger& L, GLint location, GLsizei count, const GLfloat* value);
    void        glUniformMatrix4fv(Logger&, GLint location, GLsizei count, GLboolean transpose, const GLfloat* value);
    GLint       glGetUniformLocation(Logger&, GLuint iUniformLoc, GLuint program, const GLchar* name);

    // State
    void        glEnable(Logger&, GLenum cap);
    void        glDisable(Logger&, GLenum cap);
    void        glBlendFunc(Logger&, GLenum sfactor, GLenum dfactor);
    void        glDepthFunc(Logger&, GLenum func);
    void        glCullFace(Logger&, GLenum mode);

    // Misc
    void        FrameMarker(Logger&);
}
