#pragma once
#include "Logger.hpp"

namespace gltrace
{
    void        glColor3f(Logger& L, GLfloat red, GLfloat green, GLfloat blue);
    void        glClearColor(Logger& L, GLclampf red, GLclampf green, GLclampf blue, GLclampf alpha);
    void        glClear(Logger& L, GLbitfield mask);
    void        glBegin(Logger& L, GLenum mode);
    void        glVertex3f(Logger& L, GLfloat x, GLfloat y, GLfloat z);
    void        glEnd(Logger& L);
    void        glfwPollEvents(Logger& L, uint32_t frameNumber);

    // Capture wrappers
    //void        glColor3f(Logger&, GLfloat red, GLfloat green, GLfloat blue);
    void        glViewport(Logger&, int x, int y, int w, int h);
    void        glClearColor(Logger&, float r, float g, float b, float a);
    //void        glClear(Logger&, uint32_t mask);
    void        glGenVertexArrays(Logger&, int n, unsigned* arrays);
    void        glBindVertexArray(Logger&, unsigned vao);
    void        glGenBuffers(Logger&, int n, unsigned* buffers);
    void        glBindBuffer(Logger&, uint32_t target, unsigned buffer);
    void        glBufferData(Logger&, uint32_t target, ptrdiff_t size, const void* data, uint32_t usage);
    void        glEnableVertexAttribArray(Logger&, unsigned index);
    void        glVertexAttribPointer(Logger&, unsigned index, int size, uint32_t type, bool normalized, int stride, const void* pointer);
    unsigned    glCreateShader(Logger&, uint32_t type);
    void        glShaderSource(Logger&, unsigned shader, const std::string& src);
    void        glCompileShader(Logger&, unsigned shader);
    unsigned    glCreateProgram(Logger&);
    void        glAttachShader(Logger&, unsigned program, unsigned shader);
    void        glLinkProgram(Logger&, unsigned program);
    void        glUseProgram(Logger&, unsigned program);
    void        glDrawArrays(Logger&, uint32_t mode, int first, int count);
    void        glDrawElements(Logger&, uint32_t mode, int count, uint32_t type, const void* indices);

    // Textures
    void        glGenTextures(Logger&, int n, unsigned* textures);
    void        glBindTexture(Logger&, uint32_t target, unsigned tex);
    void        glTexImage2D(Logger&, uint32_t target, int level, int internalFormat, int width, int height, int border, uint32_t format, uint32_t type, const void* data);
    void        glTexParameteri(Logger&, uint32_t target, uint32_t pname, int param);
    void        glActiveTexture(Logger&, uint32_t texture);

    // Framebuffers
    void        glGenFramebuffers(Logger&, int n, unsigned* fbos);
    void        glBindFramebuffer(Logger&, uint32_t target, unsigned fbo);
    void        glFramebufferTexture2D(Logger&, uint32_t target, uint32_t attachment, uint32_t textarget, unsigned texture, int level);

    // Uniforms
    void        glUniform1i(Logger&, int location, int v0);
    void        glUniform1f(Logger&, int location, float v0);
    void        glUniform2f(Logger&, int location, float x, float y);
    void        glUniform3f(Logger&, int location, float x, float y, float z);
    void        glUniform4f(Logger&, int location, float x, float y, float z, float w);
    void        glUniform4fv(Logger& L, int location, int count, const float* value);
    void        glUniformMatrix4fv(Logger&, int location, int count, bool transpose, const float* value);
    GLint       glGetUniformLocation(Logger&, GLuint program, const GLchar* name);

    // State
    void        glEnableCap(Logger&, uint32_t cap);
    void        glDisableCap(Logger&, uint32_t cap);
    void        glBlendFunc(Logger&, uint32_t sfactor, uint32_t dfactor);
    void        glDepthFunc(Logger&, uint32_t func);
    void        glCullFace(Logger&, uint32_t mode);

    // Misc
    void        FrameMarker(Logger&, uint32_t frameNumber);
}
