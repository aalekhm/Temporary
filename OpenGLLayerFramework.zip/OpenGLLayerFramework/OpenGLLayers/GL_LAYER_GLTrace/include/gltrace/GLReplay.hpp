#pragma once
#include "Common.hpp"
#include "BinaryReader.hpp"
#include "PayloadReader.hpp"

namespace gltrace
{
    class Replayer
    {
        public:
            using GlLoader = std::function<void()>;
            explicit    Replayer(const std::string& sPath, std::function<void(void)>& pFrameCallback);
            bool        Good() const 
                        { 
                            return m_pReader && m_pReader->Good();
                        }

            bool        Run();
        private:
            template<typename T> 
            bool        ReadPod(T& v) 
                        { 
                            return m_pReader->Pod(v);
                        }

            bool        ReadString(std::string& s) 
                        { 
                            return m_pReader->String(s);
                        }

            bool        HandleRecordWithReader(     PayloadReader& R, 
                                                    const RecordHeader& rh,
                                                    std::vector<unsigned>& shaderIds,
                                                    std::vector<unsigned>& programIds,
                                                    std::vector<unsigned>& bufferIds,
                                                    std::vector<unsigned>& vaoIds,
                                                    std::vector<unsigned>& textureIds,
                                                    std::vector<unsigned>& fboIds);

            std::function<void(void)>       m_FnOnFrameEnd;
            std::string                     m_sFilename;
            std::unique_ptr<BinaryReader>   m_pReader;

            std::vector<unsigned>           m_vShaderIds;
            std::vector<unsigned>           m_vProgramIds;
            std::vector<unsigned>           m_vBufferIds;
            std::vector<unsigned>           m_vVAOIds;
            std::vector<unsigned>           m_vTextureIds;
            std::vector<unsigned>           m_vFBOIds;
    };
}