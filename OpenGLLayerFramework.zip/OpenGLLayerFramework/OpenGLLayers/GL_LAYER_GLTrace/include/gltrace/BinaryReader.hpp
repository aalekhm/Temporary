#pragma once
#include "stdio.h"
#include <iostream>

namespace gltrace
{
    class BinaryReader
    {
        public:
            explicit BinaryReader(const std::string& path);
                    ~BinaryReader();

            bool    Good() const
                    {
                        return m_pFile != nullptr;
                    }

            size_t  Read(void* dst, size_t bytes);

            template<typename T>
            bool    Pod(T& out)
                    {
                        return Read(&out, sizeof(T)) == sizeof(T);
                    }

            bool    String(std::string& out);
            bool    Eof() const;
        private:
            FILE* m_pFile = nullptr;
    };
}