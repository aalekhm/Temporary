#pragma once
#include "stdio.h"
#include <iostream>
#include <vector>
#include <mutex>

namespace gltrace
{
    class BinaryWriter 
    {
        public:
            explicit BinaryWriter(const std::string& sPath);
                    ~BinaryWriter();

            bool    Good() const 
                    { 
                        return m_pFile != nullptr; 
                    }

            void    Write(const void* pData, size_t iBytes);

            template<typename T>
            void    Pod(const T& v) 
                    { 
                        Write(&v, sizeof(T)); 
                    }

            void    Bytes(const std::vector<uint8_t>& vArray8) 
                    { 
                        if (!vArray8.empty()) 
                        {
                            Write(vArray8.data(), vArray8.size());
                        }
                    }

            void    String(const std::string& s);
            void    Flush();
        private:
            FILE*       m_pFile = nullptr;
            std::mutex  m_Mutex;
    };
}