#pragma once
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <cstdint>
#include <vector>
#include <cstdio>
#include <string>
#include <memory>
#include <functional>
#include <unordered_map>

struct FileHeader
{
    char        magic[6] = { 'G','L','T','R','C','E' };
    uint16_t    version = 2; // bumped
};

struct RecordHeader
{
    uint32_t opcode;
    uint32_t payloadSize;
    //uint64_t timestamp_ns;
    //uint32_t thread_id;
};

struct CapturedRecord 
{
    RecordHeader            header;
    std::vector<uint8_t>    payload; // raw payload bytes (payloadSize bytes)
};

enum class Op : uint32_t
{
    // Base (previous)
    Viewport = 1,
    ClearColor = 2,
    Clear = 3,
    GenVertexArrays = 10,
    BindVertexArray = 11,
    GenBuffers = 12,
    BindBuffer = 13,
    BufferData = 14,
    EnableVertexAttribArray = 15,
    VertexAttribPointer = 16,
    CreateShader = 30,
    ShaderSource = 31,
    CompileShader = 32,
    CreateProgram = 33,
    AttachShader = 34,
    LinkProgram = 35,
    UseProgram = 36,
    DeleteShader = 37,
    DrawArrays = 50,
    DrawElements = 51,

    // Textures
    GenTextures = 60,
    BindTexture = 61,
    TexImage2D = 62,
    TexParameteri = 63,
    ActiveTexture = 64,

    // Framebuffers
    GenFramebuffers = 70,
    BindFramebuffer = 71,
    FramebufferTexture2D = 72,

    // Uniforms (common types)
    Uniform1i = 80,
    Uniform1f = 81,
    Uniform2f = 82,
    Uniform3f = 83,
    Uniform4f = 84,
    UniformMatrix4fv = 85,
    UniformLocation = 86,

    // State capture (enable/disable flags and params)
    EnableCap = 90,
    DisableCap = 91,
    BlendFunc = 92,
    DepthFunc = 93,
    CullFace = 94,

    Uniform4fv = 95,

    glColor3f = 96,
    glClearColor = 97,
    glClear = 98,
    glBegin = 99,
    glVertex3f = 100,
    glEnd = 101,

    // Metadata / frame markers
    FrameMarker = 999,
};

namespace gltrace
{
    class Utils
    {
        public:
            static std::string EnumToString(Op op)
            {
                std::string sReturnEnum;
                switch (op)
                {
                    case Op::Viewport:                  sReturnEnum = "Viewport"; break;
                    case Op::ClearColor:                sReturnEnum = "ClearColor"; break;
                    case Op::Clear:                     sReturnEnum = "Clear"; break;
                    case Op::GenVertexArrays:           sReturnEnum = "GenVertexArrays"; break;
                    case Op::BindVertexArray:           sReturnEnum = "BindVertexArray"; break;
                    case Op::GenBuffers:                sReturnEnum = "GenBuffers"; break;
                    case Op::BindBuffer:                sReturnEnum = "BindBuffer"; break;
                    case Op::BufferData:                sReturnEnum = "BufferData"; break;
                    case Op::EnableVertexAttribArray:   sReturnEnum = "EnableVertexAttribArray"; break;
                    case Op::VertexAttribPointer:       sReturnEnum = "VertexAttribPointer"; break;
                    case Op::CreateShader:              sReturnEnum = "CreateShader"; break;
                    case Op::ShaderSource:              sReturnEnum = "ShaderSource"; break;
                    case Op::CompileShader:             sReturnEnum = "CompileShader"; break;
                    case Op::CreateProgram:             sReturnEnum = "CreateProgram"; break;
                    case Op::AttachShader:              sReturnEnum = "AttachShader"; break;
                    case Op::LinkProgram:               sReturnEnum = "LinkProgram"; break;
                    case Op::DeleteShader:              sReturnEnum = "DeleteShader"; break;
                    case Op::UseProgram:                sReturnEnum = "UseProgram"; break;
                    case Op::DrawArrays:                sReturnEnum = "DrawArrays"; break;
                    case Op::DrawElements:              sReturnEnum = "DrawElements"; break;
                    case Op::GenTextures:               sReturnEnum = "GenTextures"; break;
                    case Op::BindTexture:               sReturnEnum = "BindTexture"; break;
                    case Op::TexImage2D:                sReturnEnum = "TexImage2D"; break;
                    case Op::TexParameteri:             sReturnEnum = "TexParameteri"; break;
                    case Op::ActiveTexture:             sReturnEnum = "ActiveTexture"; break;
                    case Op::GenFramebuffers:           sReturnEnum = "GenFramebuffers"; break;
                    case Op::BindFramebuffer:           sReturnEnum = "BindFramebuffer"; break;
                    case Op::FramebufferTexture2D:      sReturnEnum = "FramebufferTexture2D"; break;
                    case Op::Uniform1i:                 sReturnEnum = "Uniform1i"; break;
                    case Op::Uniform1f:                 sReturnEnum = "Uniform1f"; break;
                    case Op::Uniform2f:                 sReturnEnum = "Uniform2f"; break;
                    case Op::Uniform3f:                 sReturnEnum = "Uniform3f"; break;
                    case Op::Uniform4f:                 sReturnEnum = "Uniform4f"; break;
                    case Op::UniformMatrix4fv:          sReturnEnum = "UniformMatrix4fv"; break;
                    case Op::UniformLocation:           sReturnEnum = "UniformLocation"; break;
                    case Op::EnableCap:                 sReturnEnum = "EnableCap"; break;
                    case Op::DisableCap:                sReturnEnum = "DisableCap"; break;
                    case Op::BlendFunc:                 sReturnEnum = "BlendFunc"; break;
                    case Op::DepthFunc:                 sReturnEnum = "DepthFunc"; break;
                    case Op::CullFace:                  sReturnEnum = "CullFace"; break;
                    case Op::Uniform4fv:                sReturnEnum = "Uniform4fv"; break;
                    case Op::glColor3f:                 sReturnEnum = "glColor3f"; break;
                    case Op::glClearColor:              sReturnEnum = "glClearColor"; break;
                    case Op::glClear:                   sReturnEnum = "glClear"; break;
                    case Op::glBegin:                   sReturnEnum = "glBegin"; break;
                    case Op::glVertex3f:                sReturnEnum = "glVertex3f"; break;
                    case Op::glEnd:                     sReturnEnum = "glEnd"; break;
                    case Op::FrameMarker:               sReturnEnum = "FrameMarker"; break;
                }

                return sReturnEnum;
            }
    };
}