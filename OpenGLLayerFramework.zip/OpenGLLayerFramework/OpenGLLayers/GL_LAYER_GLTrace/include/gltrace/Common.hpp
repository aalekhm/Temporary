#pragma once
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <cstdint>
#include <vector>
#include <cstdio>
#include <string>
#include <memory>
#include <functional>
#include <unordered_map>

struct FileHeader
{
    char        magic[6] = { 'G','L','T','R','C','E' };
    uint16_t    version = 2; // bumped
};

struct RecordHeader
{
    uint32_t opcode;
    uint32_t payloadSize;
    //uint64_t timestamp_ns;
    //uint32_t thread_id;
};

struct CapturedRecord 
{
    RecordHeader            header;
    std::vector<uint8_t>    payload; // raw payload bytes (payloadSize bytes)
};


enum class Op : uint32_t
{
    // Base (previous)
    Viewport = 1,
    ClearColor = 2,
    Clear = 3,
    GenVertexArrays = 10,
    BindVertexArray = 11,
    GenBuffers = 12,
    BindBuffer = 13,
    BufferData = 14,
    EnableVertexAttribArray = 15,
    VertexAttribPointer = 16,
    CreateShader = 30,
    ShaderSource = 31,
    CompileShader = 32,
    CreateProgram = 33,
    AttachShader = 34,
    LinkProgram = 35,
    UseProgram = 36,
    DrawArrays = 50,
    DrawElements = 51,

    // Textures
    GenTextures = 60,
    BindTexture = 61,
    TexImage2D = 62,
    TexParameteri = 63,
    ActiveTexture = 64,

    // Framebuffers
    GenFramebuffers = 70,
    BindFramebuffer = 71,
    FramebufferTexture2D = 72,

    // Uniforms (common types)
    Uniform1i = 80,
    Uniform1f = 81,
    Uniform2f = 82,
    Uniform3f = 83,
    Uniform4f = 84,
    UniformMatrix4fv = 85,
    UniformLocation = 86,

    // State capture (enable/disable flags and params)
    EnableCap = 90,
    DisableCap = 91,
    BlendFunc = 92,
    DepthFunc = 93,
    CullFace = 94,

    Uniform4fv = 95,

    glColor3f = 96,
    glClearColor = 97,
    glClear = 98,
    glBegin = 99,
    glVertex3f = 100,
    glEnd = 101,

    // Metadata / frame markers
    FrameMarker = 999,
};