#pragma once
#include <cstdint>

namespace gltrace
{
    // Minimal payload reader that provides pod/read for replay logic (mirrors BinaryReader)
    class PayloadReader 
    {
        public:
                    PayloadReader(  const uint8_t* pData, 
                                    size_t iSize) 
                    : m_pData(pData)
                    , m_iSize(iSize)
                    , m_iOffset(0)
                    {
                    }

            bool    Read(void* pDst, size_t iBytes) 
                    {
                        if (m_iOffset + iBytes > m_iSize)
                        {
                            return false;
                        }

                        memcpy(pDst, m_pData + m_iOffset, iBytes);
                        m_iOffset += iBytes;

                        return true;
                    }

            template<typename T>
            bool    Pod(T& out) 
                    {
                        return Read(&out, sizeof(T)); 
                    }
        private:
            const uint8_t*  m_pData;
            size_t          m_iSize;
            size_t          m_iOffset;
    };
}