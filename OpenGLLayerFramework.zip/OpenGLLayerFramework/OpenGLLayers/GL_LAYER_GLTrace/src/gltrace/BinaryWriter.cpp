#include "gltrace/BinaryWriter.hpp"
#include "gltrace/Common.hpp"

namespace gltrace
{
    // ---------------- BinaryWriter ----------------
    BinaryWriter::BinaryWriter(const std::string& sPath)
    {
        m_pFile = fopen(sPath.c_str(), "wb");
        if (!m_pFile)
        {
            return;
        }

        FileHeader fh;
        fwrite(&fh, sizeof(fh), 1, m_pFile);
    }

    BinaryWriter::~BinaryWriter()
    {
        if (m_pFile)
        {
            fclose(m_pFile);
        }
    }

    void BinaryWriter::Write(const void* data, size_t bytes)
    {
        std::scoped_lock lk(m_Mutex);
        fwrite(data, 1, bytes, m_pFile);
    }

    void BinaryWriter::String(const std::string& sString)
    {
        uint32_t uILen = (uint32_t)sString.size();
        Write(&uILen, sizeof(uILen));

        if (uILen)
        {
            Write(sString.data(), uILen);
        }
    }

    void BinaryWriter::Flush()
    {
        std::scoped_lock lock(m_Mutex);
        fflush(m_pFile);
    }
}