#include "gltrace/GLReplay.hpp"

namespace gltrace
{
    Replayer::Replayer(const std::string& sFilename, std::function<void(void)>& pFrameCallback)
    : m_sFilename(sFilename), m_FnOnFrameEnd(pFrameCallback), m_pReader(nullptr)
    {
        // open file in binary read mode
        m_pReader = std::make_unique<BinaryReader>(sFilename);

        // validate file header
        FileHeader fh{};
        if (!m_pReader->Pod(fh))
        {
            fprintf(stderr, "Replayer: could not read file header\n");
            m_pReader.reset();
            return;
        }

        if (std::string(fh.magic, 6) != "GLTRCE")
        {
            fprintf(stderr, "Replayer: invalid file magic\n");
            m_pReader.reset();
            return;
        }

        if (fh.version != 2)
        {
            // we bumped to version=2 in last update
            fprintf(stderr, "Replayer: unsupported version %u\n", fh.version);
            m_pReader.reset();
            return;
        }
    }

    // Templated handler: takes a Reader-like object that supports pod(T&) and read(ptr,bytes)
    bool Replayer::HandleRecordWithReader(  PayloadReader& R,
                                            const RecordHeader& rh,
                                            std::vector<unsigned>& vShaderIds,
                                            std::vector<unsigned>& vProgramIds,
                                            std::vector<unsigned>& vBufferIds,
                                            std::vector<unsigned>& vVAOIds,
                                            std::vector<unsigned>& vTextureIds,
                                            std::vector<unsigned>& vFBOIds
    ) {
        auto ensure_size = [&](std::vector<unsigned>& v, unsigned id) 
        { 
            if (id >= v.size()) 
            {
                v.resize(id + 1, 0);
            }
        };

        std::cout << "Op << " << rh.opcode << std::endl;

        switch ((Op)rh.opcode) 
        {
            case Op::Viewport: 
            {
                int x, y, w, h;
                if (!R.Pod(x) || !R.Pod(y) || !R.Pod(w) || !R.Pod(h)) return false;

                glViewport(x, y, w, h); 
            }
            break;
            case Op::ClearColor: 
            case Op::glClearColor:
            { 
                GLclampf r, g, b, a;
                if (!R.Pod(r) || !R.Pod(g) || !R.Pod(b) || !R.Pod(a)) return false;
                
                glClearColor(r, g, b, a);
            }
            break;
            case Op::Clear: 
            case Op::glClear:
            { 
                GLbitfield mask;
                if (!R.Pod(mask)) return false;
                
                glClear(mask);
            }
            break;
            case Op::glColor3f:
            {
                GLfloat r, g, b;
                if (!R.Pod(r) || !R.Pod(g) || !R.Pod(b)) return false;

                glColor3f(r, g, b);
            }
            break;
            case Op::glBegin:
            {
                GLenum mode;
                if (!R.Pod(mode)) return false;

                glBegin(mode);
            }
            break;
            case Op::glEnd:
            {
                glEnd();
            }
            break;
            case Op::GenVertexArrays: 
            {
                int n;
                if (!R.Pod(n)) return false;
                
                std::vector<unsigned> ids(n); 
                for (int i = 0; i < n; ++i)
                {
                    if (!R.Pod(ids[i])) 
                    {
                        return false;
                    }
                }

                std::vector<unsigned> real(n); 
                glGenVertexArrays(n, real.data());
                for (int i = 0; i < n; ++i) 
                { 
                    ensure_size(vVAOIds, ids[i]); vVAOIds[ids[i]] = real[i];
                }
            }
            break;
            case Op::BindVertexArray: 
            { 
                unsigned vao;
                if (!R.Pod(vao)) return false;
                
                unsigned real = vao < vVAOIds.size() ? vVAOIds[vao] : vao;
                
                glBindVertexArray(real);
            }
            break;
            case Op::GenBuffers: 
            {
                int n; 
                if (!R.Pod(n)) return false;
                
                std::vector<unsigned> ids(n); 
                for (int i = 0; i < n; ++i)
                {
                    if (!R.Pod(ids[i]))
                    {
                        return false;
                    }
                }

                std::vector<unsigned> real(n); 
                {
                    glGenBuffers(n, real.data());
                }

                for (int i = 0; i < n; ++i) 
                { 
                    ensure_size(vBufferIds, ids[i]); vBufferIds[ids[i]] = real[i];
                }
            }
            break;
            case Op::BindBuffer: 
            { 
                uint32_t target; 
                unsigned buf; 
                if (!R.Pod(target) || !R.Pod(buf)) return false;
                
                unsigned real = buf < vBufferIds.size() ? vBufferIds[buf] : buf;
                
                glBindBuffer(target, real);
            }
            break;
            case Op::BufferData: 
            {
                uint32_t target; 
                int64_t size; 
                uint32_t usage;
                if (!R.Pod(target) || !R.Pod(size) || !R.Pod(usage)) return false;

                std::vector<uint8_t> tmp((size_t)size);
                if (size > 0)
                {
                    if (!R.Read(tmp.data(), (size_t)size))
                    {
                        return false;
                    }
                }

                glBufferData(target, size, size > 0 ? tmp.data() : nullptr, usage); 
            }
            break;
            case Op::EnableVertexAttribArray: 
            { 
                unsigned idx;                
                if (!R.Pod(idx)) return false;
                
                glEnableVertexAttribArray(idx);
            }
            break;
            case Op::VertexAttribPointer: 
            {
                unsigned index; 
                int size; 
                uint32_t type; 
                uint8_t norm; 
                int stride; 
                uint64_t ptr;
                if (!R.Pod(index) || !R.Pod(size) || !R.Pod(type) || !R.Pod(norm) || !R.Pod(stride) || !R.Pod(ptr)) return false;

                glVertexAttribPointer(index, size, type, (char)norm, stride, (const void*)(uintptr_t)ptr); 
            }
            break;
            case Op::CreateShader: 
            { 
                uint32_t type; 
                unsigned sRetId;
                if (!R.Pod(type) || !R.Pod(sRetId)) return false;
                
                unsigned real = glCreateShader(type); 
                ensure_size(vShaderIds, sRetId); 
                vShaderIds[sRetId] = real;
            }
            break;
            case Op::ShaderSource: 
            { 
                unsigned sh;
                if (!R.Pod(sh)) return false;
                
                uint32_t len = 0; 
                if (!R.Pod(len))
                {
                    return false;
                }
                
                std::string src; 
                src.resize(len); 
                if (len) 
                {
                    if (!R.Read(&src[0], len))
                    {
                        return false;
                    }
                }
                
                unsigned real = sh < vShaderIds.size() ? vShaderIds[sh] : sh;
                
                const char* p = src.c_str(); 
                int ln = (int)src.size(); 
                glShaderSource(real, 1, &p, &ln);
            }
            break;
            case Op::CompileShader: 
            { 
                unsigned sh; 
                if (!R.Pod(sh)) return false;
                
                unsigned real = sh < vShaderIds.size() ? vShaderIds[sh] : sh;
                
                glCompileShader(real); 
            }
            break;
            case Op::CreateProgram: 
            {
                unsigned progId; 
                if (!R.Pod(progId)) return false;
                
                unsigned realCapId = glCreateProgram(); 
                ensure_size(vProgramIds, progId);
                vProgramIds[progId] = realCapId;
            }
            break;
            case Op::AttachShader: 
            { 
                unsigned prog, sh; 
                if (!R.Pod(prog) || !R.Pod(sh)) return false; 
                
                unsigned rp = prog < vProgramIds.size() ? vProgramIds[prog] : prog;
                unsigned rs = sh < vShaderIds.size() ? vShaderIds[sh] : sh; 
                
                glAttachShader(rp, rs); 
            }
            break;
            case Op::LinkProgram: 
            { 
                unsigned prog; 
                if (!R.Pod(prog)) return false; 
                
                unsigned rp = prog < vProgramIds.size() ? vProgramIds[prog] : prog;
                
                glLinkProgram(rp); 
            }
            break;
            case Op::UseProgram: 
            { 
                unsigned prog; 
                if (!R.Pod(prog)) return false; 
                
                unsigned rp = prog < vProgramIds.size() ? vProgramIds[prog] : prog;
                
                glUseProgram(rp); 
            }
            break;
            case Op::DrawArrays: 
            { 
                uint32_t mode; 
                int first, count; 
                if (!R.Pod(mode) || !R.Pod(first) || !R.Pod(count)) return false; 
                
                glDrawArrays(mode, first, count); 
            }
            break;
            case Op::DrawElements: 
            { 
                uint32_t mode; 
                int count; 
                uint32_t type; 
                uint64_t idx; 
                if (!R.Pod(mode) || !R.Pod(count) || !R.Pod(type) || !R.Pod(idx)) return false; 
                
                glDrawElements(mode, count, type, (const void*)(uintptr_t)idx); 
            }
            break;

            // Textures
            case Op::GenTextures: 
            { 
                int n; 
                if (!R.Pod(n)) return false; 
                
                std::vector<unsigned> ids(n); 
                for (int i = 0; i < n; ++i)
                {
                    if (!R.Pod(ids[i])) return false;
                }
                
                std::vector<unsigned> real(n); 
                glGenTextures(n, real.data()); 
                for (int i = 0; i < n; ++i) 
                { 
                    ensure_size(vTextureIds, ids[i]); 
                    vTextureIds[ids[i]] = real[i];
                } 
            }
            break;
            case Op::BindTexture: 
            { 
                uint32_t target; 
                unsigned tid; 
                if (!R.Pod(target) || !R.Pod(tid)) return false; 
                
                unsigned real = tid < vTextureIds.size() ? vTextureIds[tid] : tid;
                
                glBindTexture(target, real); 
            }
            break;
            case Op::TexImage2D: 
            { 
                uint32_t target; 
                int level, internalFormat, width, height, border; 
                uint32_t format, type; 
                if (!R.Pod(target) || !R.Pod(level) || !R.Pod(internalFormat) || !R.Pod(width) || !R.Pod(height) || !R.Pod(border) || !R.Pod(format) || !R.Pod(type)) return false; 
                
                size_t pixelBytes = 4; 
                size_t dataSize = (size_t)width * (size_t)height * pixelBytes; 
                std::vector<uint8_t> tmp(dataSize); 
                if (dataSize > 0)
                {
                    if (!R.Read(tmp.data(), dataSize)) return false;
                }
                
                glTexImage2D(target, level, internalFormat, width, height, border, format, type, dataSize ? tmp.data() : nullptr); 
            }
            break;
            case Op::TexParameteri: 
            { 
                uint32_t target, pname; 
                int param; 
                if (!R.Pod(target) || !R.Pod(pname) || !R.Pod(param)) return false; 
                
                glTexParameteri(target, pname, param); 
            }
            break;
            case Op::ActiveTexture: 
            { 
                uint32_t tex; 
                if (!R.Pod(tex)) return false; 
                
                glActiveTexture(tex); 
            }
            break;

            // FBOs
            case Op::GenFramebuffers: 
            { 
                int n; 
                if (!R.Pod(n)) return false; 
                
                std::vector<unsigned> ids(n); 
                for (int i = 0; i < n; ++i)
                {
                    if (!R.Pod(ids[i])) return false;
                }
                
                std::vector<unsigned> real(n); 
                glGenFramebuffers(n, real.data()); 
                for (int i = 0; i < n; ++i) 
                { 
                    ensure_size(vFBOIds, ids[i]); 
                    vFBOIds[ids[i]] = real[i];
                } 
            }
            break;
            case Op::BindFramebuffer: 
            { 
                uint32_t target; 
                unsigned fbo; 
                if (!R.Pod(target) || !R.Pod(fbo)) return false; 
                
                unsigned real = fbo < vFBOIds.size() ? vFBOIds[fbo] : fbo;

                glBindFramebuffer(target, real); 
            }
            break;
            case Op::FramebufferTexture2D: 
            { 
                uint32_t target, attachment, textarget; 
                unsigned tex; int level; 
                if (!R.Pod(target) || !R.Pod(attachment) || !R.Pod(textarget) || !R.Pod(tex) || !R.Pod(level)) return false; 
                
                unsigned real = tex < vTextureIds.size() ? vTextureIds[tex] : tex;
                
                glFramebufferTexture2D(target, attachment, textarget, real, level); 
            }
            break;

            // Uniforms
            case Op::Uniform1i: 
            { 
                int loc, v0; 
                if (!R.Pod(loc) || !R.Pod(v0)) return false; 
                
                glUniform1i(loc, v0); 
            }
            break;
            case Op::Uniform1f: 
            { 
                int loc; 
                float v0; 
                if (!R.Pod(loc) || !R.Pod(v0)) return false; 
                
                glUniform1f(loc, v0); 
            }
            break;
            case Op::Uniform2f: 
            { 
                int loc; 
                float x, y; 
                if (!R.Pod(loc) || !R.Pod(x) || !R.Pod(y)) return false; 
                
                glUniform2f(loc, x, y); 
            }
            break;
            case Op::Uniform3f: 
            { 
                int loc; 
                float x, y, z; 
                if (!R.Pod(loc) || !R.Pod(x) || !R.Pod(y) || !R.Pod(z)) return false; 
                
                glUniform3f(loc, x, y, z); 
            }
            break;
            case Op::Uniform4f: 
            { 
                int loc; 
                float x, y, z, w; 
                if (!R.Pod(loc) || !R.Pod(x) || !R.Pod(y) || !R.Pod(z) || !R.Pod(w)) return false; 
                
                glUniform4f(loc, x, y, z, w); 
            }
            break;
            case Op::UniformMatrix4fv: 
            { 
                int loc, count; 
                uint8_t t; 
                if (!R.Pod(loc) || !R.Pod(count) || !R.Pod(t)) return false; 
                
                size_t sz = sizeof(float) * 16 * count; 
                std::vector<float> tmp(count * 16); 
                if (sz > 0)
                {
                    if (!R.Read(tmp.data(), sz)) return false;
                }
                
                glUniformMatrix4fv(loc, count, t, tmp.data()); 
            }
            break;
            case Op::UniformLocation:
            {
                GLuint program;
                if (!R.Pod(program)) return false;

                uint32_t iLen = 0;
                if (!R.Pod(iLen))
                {
                    return false;
                }

                std::string name;
                name.resize(iLen);
                if (iLen)
                {
                    if (!R.Read(&name[0], iLen))
                    {
                        return false;
                    }
                }

                GLint iRet = glGetUniformLocation(program, name.c_str());
            }
            break;

            // State
            case Op::EnableCap: 
            { 
                uint32_t cap; 
                if (!R.Pod(cap)) return false; 
                
                glEnable(cap); 
            }
            break;
            case Op::DisableCap: 
            { 
                uint32_t cap; 
                if (!R.Pod(cap)) return false; 
                
                glDisable(cap); 
            }
            break;
            case Op::BlendFunc: 
            { 
                uint32_t sf, df; 
                if (!R.Pod(sf) || !R.Pod(df)) return false; 
                
                glBlendFunc(sf, df); 
            }
            break;
            case Op::DepthFunc: 
            { 
                uint32_t f; 
                if (!R.Pod(f)) return false; 
                
                glDepthFunc(f); 
            }
            break;
            case Op::CullFace: 
            { 
                uint32_t m; 
                if (!R.Pod(m)) return false; 
                
                glCullFace(m); 
            }
            break;

            case Op::FrameMarker: 
            { 
                uint32_t frame; 
                if (!R.Pod(frame)) return false; 
                
                if (m_FnOnFrameEnd)
                {
                    m_FnOnFrameEnd();
                }
                /* marker only */ 
            }
            break;

            default: 
                return false;
        }
        return true;
    }

    bool Replayer::Run() 
    {
        if (!Good())
        {
            return false;
        }

        // 1) Read all records into memory
        std::vector<CapturedRecord> records;
        while (!m_pReader->Eof())
        {
            RecordHeader rh{};
            {
                if (!m_pReader->Pod(rh))
                {
                    break;
                }

                std::cout << "Op: " << rh.opcode << ", Payload = " << rh.payloadSize << std::endl;
                CapturedRecord cr;
                {
                    cr.header = rh;
                    if (rh.payloadSize)
                    {
                        cr.payload.resize(rh.payloadSize);
                        if (m_pReader->Read(cr.payload.data(), rh.payloadSize) != rh.payloadSize) return false;
                    }
                    records.push_back(std::move(cr));
                }
            }
        }

        if (records.empty())
        {
            return true;
        }

        // 2) Partition into frames using FrameMarker opcode as frame terminator
        std::vector<std::vector<CapturedRecord>>    frames;
        std::vector<CapturedRecord>                 current;
        for (size_t i = 0; i < records.size(); ++i) 
        {
            current.push_back(records[i]);
            if ((Op)records[i].header.opcode == Op::FrameMarker) 
            {
                frames.push_back(std::move(current));
                current.clear();
            }
        }

        if (!current.empty()) 
        {
            frames.push_back(std::move(current));
        }

        // 3) Replay frames sequentially. After each frame, present (swap buffers)
        for (size_t f = 0; f < frames.size(); ++f) 
        {
            auto& frame = frames[f];
            for (auto& rec : frame) 
            {
                PayloadReader PR(   rec.payload.empty() ? nullptr : rec.payload.data(), 
                                    rec.payload.size());

                bool bCanHandleRecords = HandleRecordWithReader(    PR, 
                                                                    rec.header, 
                                                                    m_vShaderIds, 
                                                                    m_vProgramIds, 
                                                                    m_vBufferIds, 
                                                                    m_vVAOIds, 
                                                                    m_vTextureIds, 
                                                                    m_vFBOIds);
                if (!bCanHandleRecords)
                {
                    return false;
                }
            }
        }

        return true;
    }
}