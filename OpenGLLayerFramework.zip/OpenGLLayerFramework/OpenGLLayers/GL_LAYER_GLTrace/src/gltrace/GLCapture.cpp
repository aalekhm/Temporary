#pragma once
#include "gltrace/GLCapture.hpp"

namespace gltrace
{
    void glClearColor(Logger& L, GLclampf red, GLclampf green, GLclampf blue, GLclampf alpha)
    {
        L.BeginRecord(Op::glClearColor, sizeof(GLfloat) * 4);
        L.Pod(red);
        L.Pod(green);
        L.Pod(blue);
        L.Pod(alpha);
    }

    void glClear(Logger& L, GLbitfield mask)
    {
        L.BeginRecord(Op::glClear, sizeof(GLbitfield));
        L.Pod(mask);
    }

    void glBegin(Logger& L, GLenum mode)
    {
        L.BeginRecord(Op::glBegin, sizeof(GLenum));
        L.Pod(mode);
    }

    void glVertex3f(Logger& L, GLfloat x, GLfloat y, GLfloat z)
    {
        L.BeginRecord(Op::glVertex3f, sizeof(GLfloat) * 3);
        L.Pod(x);
        L.Pod(y);
        L.Pod(z);
    }

    void glEnd(Logger& L)
    {
        L.BeginRecord(Op::glEnd, 0);
    }

    void glfwPollEvents(Logger& L)
    {
        L.BeginRecord(Op::FrameMarker, 0);
    }

    void glColor3f(Logger& L, GLfloat red, GLfloat green, GLfloat blue)
    {
        //::glColor3f(red, green, blue);
        L.BeginRecord(Op::glColor3f, sizeof(GLfloat) * 3);
        L.Pod(red);
        L.Pod(green);
        L.Pod(blue);
    }

    void glViewport(Logger& L, GLint x, GLint y, GLsizei w, GLsizei h)
    {
        //::glViewport(x, y, w, h);
        L.BeginRecord(Op::Viewport, sizeof(GLint) * 4);
        L.Pod(x);
        L.Pod(y);
        L.Pod(w);
        L.Pod(h);
    }

    void ClearColor(Logger& L, float r, float g, float b, float a)
    {
        //::glClearColor(r, g, b, a);
        L.BeginRecord(Op::ClearColor, sizeof(float) * 4);
        L.Pod(r);
        L.Pod(g);
        L.Pod(b);
        L.Pod(a);
    }

    //void glClear(Logger& L, uint32_t mask)
    //{
    //    ::glClear(mask);
    //    L.BeginRecord(Op::Clear, sizeof(uint32_t));
    //    L.Pod(mask);
    //}

    void glGenVertexArrays(Logger& L, GLsizei n, GLuint* arrays)
    {
        //::glGenVertexArrays(n, arrays);
        L.BeginRecord(Op::GenVertexArrays, sizeof(GLsizei) + sizeof(GLuint) * n);
        L.Pod(n);
        for (int i = 0; i < n; ++i)
        {
            L.Pod(arrays[i]);
        }
    }

    void glBindVertexArray(Logger& L, GLuint vao)
    {
        //::glBindVertexArray(vao);
        L.BeginRecord(Op::BindVertexArray, sizeof(GLuint));
        L.Pod(vao);
    }

    void glGenBuffers(Logger& L, GLsizei n, GLuint* buffers)
    {
        //::glGenBuffers(n, buffers); 
        L.BeginRecord(Op::GenBuffers, sizeof(GLsizei) + sizeof(GLuint) * n);
        L.Pod(n);
        for (int i = 0; i < n; ++i)
        {
            L.Pod(buffers[i]);
        }
    }

    void glBindBuffer(Logger& L, GLenum target, GLuint buffer)
    {
        //::glBindBuffer(target, buffer);
        L.BeginRecord(Op::BindBuffer, sizeof(GLenum) + sizeof(GLuint));
        L.Pod(target);
        L.Pod(buffer);
    }

    void glBufferData(Logger& L, GLenum target, GLsizeiptr size, const void* data, GLenum usage)
    {
        //::glBufferData(target, size, data, usage);
        L.BeginRecord(Op::BufferData, sizeof(GLenum) + sizeof(GLsizeiptr) + sizeof(GLenum) + (GLenum)size);
        L.Pod(target);
        //int64_t s64 = (int64_t)size;
        L.Pod(size);
        L.Pod(usage);
        if (size > 0 && data)
        {
            L.WritePayload(data, (size_t)size);
        }
    }

    void glEnableVertexAttribArray(Logger& L, GLuint index)
    {
        //::glEnableVertexAttribArray(index);
        L.BeginRecord(Op::EnableVertexAttribArray, sizeof(GLuint));
        L.Pod(index);
    }

    void glVertexAttribPointer(Logger& L, GLuint index, GLuint size, GLenum type, bool normalized, GLsizei stride, const void* pointer) 
    {
        //::glVertexAttribPointer(index, size, type, normalized ? 1 : 0, stride, pointer);
        L.BeginRecord(Op::VertexAttribPointer, sizeof(GLsizei) + sizeof(GLuint) * 2 + sizeof(GLenum) + sizeof(uint8_t) + sizeof(uint64_t));
        uint8_t norm = normalized ? 1 : 0;
        uint64_t ptr = (uint64_t)(uintptr_t)pointer;
        L.Pod(index);
        L.Pod(size);
        L.Pod(type);
        L.Pod(norm);
        L.Pod(stride);
        L.Pod(ptr);
    }

    void glCreateShader(Logger& L, unsigned sRet, GLenum type)
    {
        //unsigned s = glCreateShader(type);
        L.BeginRecord(Op::CreateShader, sizeof(unsigned));// +sizeof(GLenum));
        L.Pod(type);
        //L.Pod(sRet);
        //return s;
    }

    void glShaderSource(Logger& L, GLuint shader, const std::string& src)
    {
        const char* p = src.c_str();
        int len = (int)src.size();
        //::glShaderSource(shader, 1, &p, &len);
        L.BeginRecord(Op::ShaderSource, sizeof(GLuint) + sizeof(uint32_t) + len);
        L.Pod(shader);
        L.String(src);
    }

    void glCompileShader(Logger& L, GLuint shader)
    {
        //::glCompileShader(shader);
        L.BeginRecord(Op::CompileShader, sizeof(GLuint));
        L.Pod(shader);
    }

    //unsigned glCreateProgram(Logger& L)
    void glCreateProgram(Logger& L, GLuint progId)
    {
        //unsigned p = ::glCreateProgram();
        L.BeginRecord(Op::CreateProgram, sizeof(GLuint));
        L.Pod(progId);
        //return p;
    }

    void glAttachShader(Logger& L, GLuint program, GLuint shader)
    {
        //::glAttachShader(program, shader);
        L.BeginRecord(Op::AttachShader, sizeof(GLuint) * 2);
        L.Pod(program);
        L.Pod(shader);
    }

    void glLinkProgram(Logger& L, GLuint program)
    {
        //::glLinkProgram(program);
        L.BeginRecord(Op::LinkProgram, sizeof(GLuint));
        L.Pod(program);
    }

    void glUseProgram(Logger& L, GLuint program)
    {
        //::glUseProgram(program);
        L.BeginRecord(Op::UseProgram, sizeof(GLuint));
        L.Pod(program);
    }

    void glDeleteShader(Logger& L, GLuint program)
    {
        //::glDeleteShader(program);
        L.BeginRecord(Op::DeleteShader, sizeof(GLuint));
        L.Pod(program);
    }

    void glDrawArrays(Logger& L, GLenum mode, GLint first, GLsizei count)
    {
        //::glDrawArrays(mode, first, count);
        L.BeginRecord(Op::DrawArrays, sizeof(GLenum) + sizeof(GLint) + sizeof(GLsizei));
        L.Pod(mode);
        L.Pod(first);
        L.Pod(count);
    }

    void glDrawElements(Logger& L, GLenum mode, GLsizei count, GLenum type, const void* indices)
    {
        //::glDrawElements(mode, count, type, indices);
        L.BeginRecord(Op::DrawElements, sizeof(GLenum) * 2 + sizeof(GLsizei) + sizeof(uint64_t));
        uint64_t idx = (uint64_t)(uintptr_t)indices;
        L.Pod(mode);
        L.Pod(count);
        L.Pod(type);
        L.Pod(idx);
    }

    // Textures
    void glGenTextures(Logger& L, GLsizei n, GLuint* textures)
    {
        //::glGenTextures(n, textures);
        L.BeginRecord(Op::GenTextures, sizeof(GLsizei) + sizeof(GLuint) * n);
        L.Pod(n);
        for (int i = 0; i < n; ++i)
        {
            L.Pod(textures[i]);
        }
    }

    void glBindTexture(Logger& L, GLenum target, GLuint tex)
    {
        //::glBindTexture(target, tex);
        L.BeginRecord(Op::BindTexture, sizeof(GLenum) + sizeof(GLuint));
        L.Pod(target);
        L.Pod(tex);
    }

    void glTexImage2D(Logger& L, GLenum target, GLint level, GLint internalFormat, GLsizei width, GLsizei height, GLint border, GLenum format, GLenum type, const void* data)
    {
                                
        //::glTexImage2D(target, level, internalFormat, width, height, border, format, type, data);
        uint32_t pixelBytes = 4; // heuristic for common RGBA8, but we capture 'data' size as width*height*4
        uint32_t dataSize = (uint32_t)width * (uint32_t)height * pixelBytes;
        L.BeginRecord(Op::TexImage2D, sizeof(GLenum) * 3 + sizeof(GLint) * 3 + sizeof(GLsizei) * 2 + dataSize);
        L.Pod(target);
        L.Pod(level);
        L.Pod(internalFormat);
        L.Pod(width);
        L.Pod(height);
        L.Pod(border);
        L.Pod(format);
        L.Pod(type);

        if (dataSize > 0 && data)
        {
            L.WritePayload(data, dataSize);
        }
    }

    void glTexParameteri(Logger& L, GLenum target, GLenum pname, GLint param)
    {
        //::glTexParameteri(target, pname, param);
        L.BeginRecord(Op::TexParameteri, sizeof(GLenum) * 2 + sizeof(GLint));
        L.Pod(target);
        L.Pod(pname);
        L.Pod(param);
    }

    void glActiveTexture(Logger& L, GLenum texture)
    {
        //::glActiveTexture(texture);
        L.BeginRecord(Op::ActiveTexture, sizeof(GLenum));
        L.Pod(texture);
    }

    // Framebuffers
    void glGenFramebuffers(Logger& L, GLsizei n, GLuint* fbos)
    {
        //::glGenFramebuffers(n, fbos);
        L.BeginRecord(Op::GenFramebuffers, sizeof(GLsizei) + sizeof(GLuint) * n);
        L.Pod(n);
        for (int i = 0; i < n; ++i)
        {
            L.Pod(fbos[i]);
        }
    }

    void glBindFramebuffer(Logger& L, uint32_t target, GLuint fbo)
    {
        //::glBindFramebuffer(target, fbo);
        L.BeginRecord(Op::BindFramebuffer, sizeof(target) + sizeof(GLuint));
        L.Pod(target);
        L.Pod(fbo);
    }

    void glFramebufferTexture2D(Logger& L, GLenum target, GLenum attachment, GLenum textarget, GLuint texture, GLint level)
    {
        //::glFramebufferTexture2D(target, attachment, textarget, texture, level);
        L.BeginRecord(Op::FramebufferTexture2D, sizeof(GLenum) * 3 + sizeof(GLuint) + sizeof(GLint));
        L.Pod(target);
        L.Pod(attachment);
        L.Pod(textarget);
        L.Pod(texture);
        L.Pod(level);
    }

    // Uniforms
    void glUniform1i(Logger& L, GLint location, GLint v0)
    {
        //::glUniform1i(location, v0); L.BeginRecord(Op::Uniform1i, sizeof(int) * 2);
        L.BeginRecord(Op::Uniform1i, sizeof(GLint) + sizeof(GLint));
        L.Pod(location);
        L.Pod(v0);
    }

    void glUniform1f(Logger& L, GLint location, GLfloat v0)
    {
        //::glUniform1f(location, v0);
        L.BeginRecord(Op::Uniform1f, sizeof(GLint) + sizeof(float));
        L.Pod(location);
        L.Pod(v0);
    }

    void glUniform2f(Logger& L, GLint location, GLfloat x, GLfloat y)
    {
        //::glUniform2f(location, x, y);
        L.BeginRecord(Op::Uniform2f, sizeof(GLint) + sizeof(GLfloat) * 2);
        L.Pod(location);
        L.Pod(x);
        L.Pod(y);
    }

    void glUniform3f(Logger& L, GLint location, GLfloat x, GLfloat y, GLfloat z)
    {
        //::glUniform3f(location, x, y, z);
        L.BeginRecord(Op::Uniform3f, sizeof(GLint) + sizeof(float) * 3);
        L.Pod(location);
        L.Pod(x);
        L.Pod(y);
        L.Pod(z);
    }

    void glUniform4f(Logger& L, GLint location, GLfloat x, GLfloat y, GLfloat z, GLfloat w)
    {
        //::glUniform4f(location, x, y, z, w);
        L.BeginRecord(Op::Uniform4f, sizeof(GLint) + sizeof(float) * 4);
        L.Pod(location);
        L.Pod(x);
        L.Pod(y);
        L.Pod(z);
        L.Pod(w);
    }

    void glUniform4fv(Logger& L, GLint location, GLsizei count, const GLfloat* value)
    {
        //::glUniform4fv(location, count, value);
        L.BeginRecord(Op::Uniform4fv, sizeof(GLint) + sizeof(GLsizei) + sizeof(GLfloat) * count);
        L.Pod(location);
        L.Pod(count);
        L.WritePayload(value, sizeof(float) * count);
    }

    void glUniformMatrix4fv(Logger& L, GLint location, GLsizei count, GLboolean transpose, const GLfloat* value)
    {
        //::glUniformMatrix4fv(location, count, transpose ? 1 : 0, value);
        L.BeginRecord(Op::UniformMatrix4fv, sizeof(GLint) + sizeof(GLsizei) + sizeof(uint8_t) + sizeof(GLfloat) * 16 * count);
        L.Pod(location);
        L.Pod(count); 
        uint8_t t = transpose ? 1 : 0;
        L.Pod(t);
        L.WritePayload(value, sizeof(GLfloat) * 16 * count);
    }

    GLint glGetUniformLocation(Logger& L, GLuint iUniformLoc, GLuint program, const GLchar* name)
    {
        //GLint iRet = ::glGetUniformLocation(program, name);

        uint32_t iLen = strlen(name);
        uint32_t iTotalSize = /*sizeof(GLuint) + */sizeof(GLuint) + sizeof(uint32_t) + iLen;
        L.BeginRecord(Op::UniformLocation, iTotalSize);
        L.Pod(program);
        L.String(name);
        //L.Pod(iUniformLoc);
        
        return iUniformLoc;
    }

    // State
    void glEnable(Logger& L, GLenum cap)
    {
        //::glEnable(cap);
        L.BeginRecord(Op::EnableCap, sizeof(GLenum));
        L.Pod(cap);
    }

    void glDisable(Logger& L, GLenum cap)
    {
        //::glDisable(cap);
        L.BeginRecord(Op::DisableCap, sizeof(GLenum));
        L.Pod(cap);
    }

    void glBlendFunc(Logger& L, GLenum sfactor, GLenum dfactor)
    {
        //::glBlendFunc(sfactor, dfactor);
        L.BeginRecord(Op::BlendFunc, sizeof(GLenum) * 2);
        L.Pod(sfactor);
        L.Pod(dfactor);
    }

    void glDepthFunc(Logger& L, GLenum func)
    {
        //::glDepthFunc(func);
        L.BeginRecord(Op::DepthFunc, sizeof(GLenum));
        L.Pod(func);
    }

    void glCullFace(Logger& L, GLenum mode)
    {
        //::glCullFace(mode);
        L.BeginRecord(Op::CullFace, sizeof(GLenum));
        L.Pod(mode);
    }

    void FrameMarker(Logger& L)
    {
        L.BeginRecord(Op::FrameMarker, 0);
    }
}
