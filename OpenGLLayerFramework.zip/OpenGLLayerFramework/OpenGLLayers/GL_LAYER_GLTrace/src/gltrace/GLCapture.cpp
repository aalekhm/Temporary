#pragma once
#include "gltrace/GLCapture.hpp"

namespace gltrace
{
    void glColor3f(Logger& L, GLfloat red, GLfloat green, GLfloat blue)
    {
        L.BeginRecord(Op::glColor3f, sizeof(GLfloat) * 3);
        L.Pod(red);
        L.Pod(green);
        L.Pod(blue);
    }

    void glClearColor(Logger& L, GLclampf red, GLclampf green, GLclampf blue, GLclampf alpha)
    {
        L.BeginRecord(Op::glClearColor, sizeof(GLfloat) * 4);
        L.Pod(red);
        L.Pod(green);
        L.Pod(blue);
        L.Pod(alpha);
    }

    void glClear(Logger& L, GLbitfield mask)
    {
        L.BeginRecord(Op::glClear, sizeof(GLbitfield));
        L.Pod(mask);
    }

    void glBegin(Logger& L, GLenum mode)
    {
        L.BeginRecord(Op::glClear, sizeof(GLenum));
        L.Pod(mode);
    }

    void glVertex3f(Logger& L, GLfloat x, GLfloat y, GLfloat z)
    {
        L.BeginRecord(Op::glClearColor, sizeof(GLfloat) * 3);
        L.Pod(x);
        L.Pod(y);
        L.Pod(z);
    }

    void glEnd(Logger& L)
    {
        L.BeginRecord(Op::glEnd, 0);
    }

    void glfwPollEvents(Logger& L, uint32_t frameNumber)
    {
        L.BeginRecord(Op::FrameMarker, 0);
    }

    //void glColor3f(Logger& L, GLfloat red, GLfloat green, GLfloat blue)
    //{
    //    ::glColor3f(red, green, blue);
    //    L.BeginRecord(Op::glColor3f, sizeof(GLfloat) * 3);
    //    L.Pod(red);
    //    L.Pod(green);
    //    L.Pod(blue);
    //}

    void glViewport(Logger& L, int x, int y, int w, int h)
    {
        ::glViewport(x, y, w, h);
        L.BeginRecord(Op::Viewport, sizeof(int) * 4);
        L.Pod(x);
        L.Pod(y);
        L.Pod(w);
        L.Pod(h);
    }

    void ClearColor(Logger& L, float r, float g, float b, float a)
    {
        ::glClearColor(r, g, b, a);
        L.BeginRecord(Op::ClearColor, sizeof(float) * 4);
        L.Pod(r);
        L.Pod(g);
        L.Pod(b);
        L.Pod(a);
    }

    //void glClear(Logger& L, uint32_t mask)
    //{
    //    ::glClear(mask);
    //    L.BeginRecord(Op::Clear, sizeof(uint32_t));
    //    L.Pod(mask);
    //}

    void glGenVertexArrays(Logger& L, int n, unsigned* arrays)
    {
        ::glGenVertexArrays(n, arrays);
        L.BeginRecord(Op::GenVertexArrays, sizeof(int) + sizeof(unsigned) * n);
        L.Pod(n);
        for (int i = 0; i < n; ++i)
        {
            L.Pod(arrays[i]);
        }
    }

    void glBindVertexArray(Logger& L, unsigned vao)
    {
        ::glBindVertexArray(vao);
        L.BeginRecord(Op::BindVertexArray, sizeof(unsigned));
        L.Pod(vao);
    }

    void glGenBuffers(Logger& L, int n, unsigned* buffers)
    {
        ::glGenBuffers(n, buffers); L.BeginRecord(Op::GenBuffers, sizeof(int) + sizeof(unsigned) * n);
        L.Pod(n);
        for (int i = 0; i < n; ++i)
        {
            L.Pod(buffers[i]);
        }
    }

    void glBindBuffer(Logger& L, uint32_t target, unsigned buffer)
    {
        ::glBindBuffer(target, buffer);
        L.BeginRecord(Op::BindBuffer, sizeof(uint32_t) + sizeof(unsigned));
        L.Pod(target);
        L.Pod(buffer);
    }

    void glBufferData(Logger& L, uint32_t target, ptrdiff_t size, const void* data, uint32_t usage)
    {
        ::glBufferData(target, size, data, usage);
        L.BeginRecord(Op::BufferData, sizeof(uint32_t) + sizeof(int64_t) + sizeof(uint32_t) + (uint32_t)size);
        L.Pod(target);
        int64_t s64 = (int64_t)size;
        L.Pod(s64);
        L.Pod(usage);
        if (size > 0 && data)
        {
            L.WritePayload(data, (size_t)size);
        }
    }

    void glEnableVertexAttribArray(Logger& L, unsigned index)
    {
        ::glEnableVertexAttribArray(index);
        L.BeginRecord(Op::EnableVertexAttribArray, sizeof(unsigned));
        L.Pod(index);
    }

    void glVertexAttribPointer(Logger& L, unsigned index, int size, uint32_t type, bool normalized, int stride, const void* pointer)
    {
        ::glVertexAttribPointer(index, size, type, normalized ? 1 : 0, stride, pointer);
        L.BeginRecord(Op::VertexAttribPointer, sizeof(unsigned) + sizeof(int) * 2 + sizeof(uint32_t) + sizeof(uint8_t) + sizeof(uint64_t));
        uint8_t norm = normalized ? 1 : 0;
        uint64_t ptr = (uint64_t)(uintptr_t)pointer;
        L.Pod(index);
        L.Pod(size);
        L.Pod(type);
        L.Pod(norm);
        L.Pod(stride);
        L.Pod(ptr);
    }

    unsigned glCreateShader(Logger& L, uint32_t type)
    {
        unsigned s = ::glCreateShader(type);
        L.BeginRecord(Op::CreateShader, sizeof(uint32_t) + sizeof(unsigned));
        L.Pod(type);
        L.Pod(s);

        return s;
    }

    void glShaderSource(Logger& L, unsigned shader, const std::string& src)
    {
        const char* p = src.c_str();
        int len = (int)src.size();
        ::glShaderSource(shader, 1, &p, &len);
        L.BeginRecord(Op::ShaderSource, sizeof(unsigned) + sizeof(uint32_t) + len);
        L.Pod(shader);
        L.String(src);
    }

    void glCompileShader(Logger& L, unsigned shader)
    {
        ::glCompileShader(shader);
        L.BeginRecord(Op::CompileShader, sizeof(unsigned));
        L.Pod(shader);
    }

    unsigned glCreateProgram(Logger& L)
    {
        unsigned p = ::glCreateProgram();
        L.BeginRecord(Op::CreateProgram, sizeof(unsigned));
        L.Pod(p);
        return p;
    }

    void glAttachShader(Logger& L, unsigned program, unsigned shader)
    {
        ::glAttachShader(program, shader);
        L.BeginRecord(Op::AttachShader, sizeof(unsigned) * 2);
        L.Pod(program);
        L.Pod(shader);
    }

    void glLinkProgram(Logger& L, unsigned program)
    {
        ::glLinkProgram(program);
        L.BeginRecord(Op::LinkProgram, sizeof(unsigned));
        L.Pod(program);
    }

    void glUseProgram(Logger& L, unsigned program)
    {
        ::glUseProgram(program);
        L.BeginRecord(Op::UseProgram, sizeof(unsigned));
        L.Pod(program);
    }

    void glDrawArrays(Logger& L, uint32_t mode, int first, int count)
    {
        ::glDrawArrays(mode, first, count);
        L.BeginRecord(Op::DrawArrays, sizeof(uint32_t) + sizeof(int) * 2);
        L.Pod(mode);
        L.Pod(first);
        L.Pod(count);
    }

    void glDrawElements(Logger& L, uint32_t mode, int count, uint32_t type, const void* indices)
    {
        ::glDrawElements(mode, count, type, indices);
        L.BeginRecord(Op::DrawElements, sizeof(uint32_t) * 2 + sizeof(int) + sizeof(uint64_t));
        uint64_t idx = (uint64_t)(uintptr_t)indices;
        L.Pod(mode);
        L.Pod(count);
        L.Pod(type);
        L.Pod(idx);
    }

    // Textures
    void glGenTextures(Logger& L, int n, unsigned* textures)
    {
        ::glGenTextures(n, textures);
        L.BeginRecord(Op::GenTextures, sizeof(int) + sizeof(unsigned) * n);
        L.Pod(n);
        for (int i = 0; i < n; ++i)
        {
            L.Pod(textures[i]);
        }
    }

    void glBindTexture(Logger& L, uint32_t target, unsigned tex)
    {
        ::glBindTexture(target, tex);
        L.BeginRecord(Op::BindTexture, sizeof(uint32_t) + sizeof(unsigned));
        L.Pod(target);
        L.Pod(tex);
    }

    void glTexImage2D(Logger& L, uint32_t target, int level, int internalFormat, int width, int height, int border, uint32_t format, uint32_t type, const void* data)
    {
        ::glTexImage2D(target, level, internalFormat, width, height, border, format, type, data);
        uint32_t pixelBytes = 4; // heuristic for common RGBA8, but we capture 'data' size as width*height*4
        uint32_t dataSize = (uint32_t)width * (uint32_t)height * pixelBytes;
        L.BeginRecord(Op::TexImage2D, sizeof(uint32_t) * 3 + sizeof(int) * 5 + dataSize);
        L.Pod(target);
        L.Pod(level);
        L.Pod(internalFormat);
        L.Pod(width);
        L.Pod(height);
        L.Pod(border);
        L.Pod(format);
        L.Pod(type);

        if (dataSize > 0 && data)
        {
            L.WritePayload(data, dataSize);
        }
    }

    void glTexParameteri(Logger& L, uint32_t target, uint32_t pname, int param)
    {
        ::glTexParameteri(target, pname, param);
        L.BeginRecord(Op::TexParameteri, sizeof(uint32_t) * 2 + sizeof(int));
        L.Pod(target);
        L.Pod(pname);
        L.Pod(param);
    }

    void glActiveTexture(Logger& L, uint32_t texture)
    {
        ::glActiveTexture(texture);
        L.BeginRecord(Op::ActiveTexture, sizeof(uint32_t));
        L.Pod(texture);
    }

    // Framebuffers
    void glGenFramebuffers(Logger& L, int n, unsigned* fbos)
    {
        ::glGenFramebuffers(n, fbos);
        L.BeginRecord(Op::GenFramebuffers, sizeof(int) + sizeof(unsigned) * n);
        L.Pod(n);
        for (int i = 0; i < n; ++i)
        {
            L.Pod(fbos[i]);
        }
    }

    void glBindFramebuffer(Logger& L, uint32_t target, unsigned fbo)
    {
        ::glBindFramebuffer(target, fbo);
        L.BeginRecord(Op::BindFramebuffer, sizeof(uint32_t) + sizeof(unsigned));
        L.Pod(target);
        L.Pod(fbo);
    }

    void glFramebufferTexture2D(Logger& L, uint32_t target, uint32_t attachment, uint32_t textarget, unsigned texture, int level)
    {
        ::glFramebufferTexture2D(target, attachment, textarget, texture, level);
        L.BeginRecord(Op::FramebufferTexture2D, sizeof(uint32_t) * 3 + sizeof(unsigned) + sizeof(int));
        L.Pod(target);
        L.Pod(attachment);
        L.Pod(textarget);
        L.Pod(texture);
        L.Pod(level);
    }

    // Uniforms
    void glUniform1i(Logger& L, int location, int v0)
    {
        ::glUniform1i(location, v0); L.BeginRecord(Op::Uniform1i, sizeof(int) * 2);
        L.Pod(location);
        L.Pod(v0);
    }

    void glUniform1f(Logger& L, int location, float v0)
    {
        ::glUniform1f(location, v0);
        L.BeginRecord(Op::Uniform1f, sizeof(int) + sizeof(float));
        L.Pod(location);
        L.Pod(v0);
    }

    void glUniform2f(Logger& L, int location, float x, float y)
    {
        ::glUniform2f(location, x, y);
        L.BeginRecord(Op::Uniform2f, sizeof(int) + sizeof(float) * 2);
        L.Pod(location);
        L.Pod(x);
        L.Pod(y);
    }

    void glUniform3f(Logger& L, int location, float x, float y, float z)
    {
        ::glUniform3f(location, x, y, z);
        L.BeginRecord(Op::Uniform3f, sizeof(int) + sizeof(float) * 3);
        L.Pod(location);
        L.Pod(x);
        L.Pod(y);
        L.Pod(z);
    }

    void glUniform4f(Logger& L, int location, float x, float y, float z, float w)
    {
        ::glUniform4f(location, x, y, z, w);
        L.BeginRecord(Op::Uniform4f, sizeof(int) + sizeof(float) * 4);
        L.Pod(location);
        L.Pod(x);
        L.Pod(y);
        L.Pod(z);
        L.Pod(w);
    }

    void glUniform4fv(Logger& L, int location, int count, const float* value)
    {
        ::glUniform4fv(location, count, value);
        L.BeginRecord(Op::Uniform4fv, sizeof(int) + sizeof(int) + sizeof(float) * count);
        L.Pod(location);
        L.Pod(count);
        L.WritePayload(value, sizeof(float) * count);
    }

    void glUniformMatrix4fv(Logger& L, int location, int count, bool transpose, const float* value)
    {
        ::glUniformMatrix4fv(location, count, transpose ? 1 : 0, value);
        L.BeginRecord(Op::UniformMatrix4fv, sizeof(int) + sizeof(int) + sizeof(uint8_t) + sizeof(float) * 16 * count);
        L.Pod(location);
        L.Pod(count); uint8_t t = transpose ? 1 : 0;
        L.Pod(t);
        L.WritePayload(value, sizeof(float) * 16 * count);
    }

    GLint glGetUniformLocation(Logger& L, GLuint program, const GLchar* name)
    {
        GLint iRet = ::glGetUniformLocation(program, name);

        uint32_t iLen = strlen(name);
        uint32_t iTotalSize = sizeof(GLuint) + sizeof(uint32_t) + iLen;
        L.BeginRecord(Op::UniformLocation, iTotalSize);
        L.Pod(program);
        L.String(name);
        //L.Pod(iRet);

        return iRet;
    }

    // State
    void glEnableCap(Logger& L, uint32_t cap)
    {
        ::glEnable(cap);
        L.BeginRecord(Op::EnableCap, sizeof(uint32_t));
        L.Pod(cap);
    }

    void glDisableCap(Logger& L, uint32_t cap)
    {
        ::glDisable(cap);
        L.BeginRecord(Op::DisableCap, sizeof(uint32_t));
        L.Pod(cap);
    }

    void glBlendFunc(Logger& L, uint32_t sfactor, uint32_t dfactor)
    {
        ::glBlendFunc(sfactor, dfactor);
        L.BeginRecord(Op::BlendFunc, sizeof(uint32_t) * 2);
        L.Pod(sfactor);
        L.Pod(dfactor);
    }

    void glDepthFunc(Logger& L, uint32_t func)
    {
        ::glDepthFunc(func);
        L.BeginRecord(Op::DepthFunc, sizeof(uint32_t));
        L.Pod(func);
    }

    void glCullFace(Logger& L, uint32_t mode)
    {
        ::glCullFace(mode);
        L.BeginRecord(Op::CullFace, sizeof(uint32_t));
        L.Pod(mode);
    }

    void FrameMarker(Logger& L, uint32_t frameNumber)
    {
        L.BeginRecord(Op::FrameMarker, sizeof(uint32_t));
        L.Pod(frameNumber);
    }
}
