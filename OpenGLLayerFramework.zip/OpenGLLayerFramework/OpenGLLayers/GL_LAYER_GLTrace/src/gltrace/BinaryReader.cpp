#include "gltrace/BinaryReader.hpp"

namespace gltrace
{
    BinaryReader::BinaryReader(const std::string& path) 
    {
        m_pFile = fopen(path.c_str(), "rb");
        if (!m_pFile)
        {
            return;
        }
    }

    BinaryReader::~BinaryReader() 
    { 
        if (m_pFile)
        {
            fclose(m_pFile);
        }
    }

    size_t BinaryReader::Read(void* dst, size_t bytes) 
    { 
        if (!m_pFile)
        {
            return 0;
        }
        
        return fread(dst, 1, bytes, m_pFile);
    }

    bool BinaryReader::String(std::string& out) 
    { 
        uint32_t len = 0; 
        if (Read(&len, sizeof(len)) != sizeof(len))
        {
            return false;
        }
        
        out.resize(len); 
        if (len)
        {
            return Read(out.data(), len) == len;
        }
        else 
        {
            return true;
        }
    }

    bool BinaryReader::Eof() const 
    { 
        if (!m_pFile)
        {
            return true;
        }
        
        return feof(m_pFile);
    }
}