#include "gltrace/Logger.hpp"
#include "gltrace/Common.hpp"

#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
static uint32_t get_thread_id()
{
    return static_cast<uint32_t>(::GetCurrentThreadId());
}
#else
#include <unistd.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <pthread.h>
static uint32_t get_thread_id() {
#if defined(__APPLE__)
    uint64_t tid; pthread_threadid_np(NULL, &tid); return (uint32_t)tid;
#else
    return (uint32_t)syscall(SYS_gettid);
#endif
}
#endif

namespace gltrace
{
    // ---------------- Logger ----------------
    Logger::Logger(const std::string& sPath) 
    : m_pWriter(std::make_unique<BinaryWriter>(sPath)) 
    {
    }

    Logger::~Logger() 
    {
    }

    static uint64_t now_ns() 
    { 
        using namespace std::chrono; 
        return std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now().time_since_epoch()).count(); 
    }

    void Logger::BeginRecord(Op op, uint32_t payloadSize) 
    {
        std::cout << "Op : " << static_cast<uint32_t>(op) << std::endl;

        RecordHeader rh{};
        {
            rh.opcode       = static_cast<uint32_t>(op);
            rh.payloadSize  = payloadSize;
            //rh.timestamp_ns = now_ns();
            //rh.thread_id    = get_thread_id();
        }

        m_pWriter->Pod(rh);
    }

    void Logger::WritePayload(const void* data, size_t bytes) 
    { 
        m_pWriter->Write(data, bytes);
    }

    void Logger::EndRecord() 
    { 
        m_pWriter->Flush();
    }
}