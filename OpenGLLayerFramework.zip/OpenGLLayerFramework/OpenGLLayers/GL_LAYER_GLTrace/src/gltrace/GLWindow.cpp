#include "gltrace/GLWindow.hpp"

namespace gltrace
{
    GLFWwindow* initGLFW(const char* sWindowTitle, bool bProgrammable)
    {
        if (!glfwInit())
        {
            exit(EXIT_FAILURE);
        }

        if (bProgrammable)
        {
            glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
            glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
            glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
            glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
        }
        else
        {
            glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 2);
            glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 1);
        }

        GLFWwindow* win = glfwCreateWindow(960, 640, sWindowTitle, nullptr, nullptr);
        if (win == nullptr)
        {
            glfwTerminate();
            exit(EXIT_FAILURE);
        }

        // This function makes the OpenGL or OpenGL ES context of the specified window current on the calling thread.
        glfwMakeContextCurrent(win);
        glfwSwapInterval(1);

        // Initialize GLEW
        glewExperimental = GL_TRUE;
        if (glewInit() != GLEW_OK)
        {
            exit(EXIT_FAILURE);
        }

        return win;
    }

    void* InitGLAndWindow(const WindowInitConfig& wCfg, bool bUseProgrammable)
    {
        if (!glfwInit())
        {
            return nullptr;
        }

        if (wCfg.coreProfile)
        {
            if(bUseProgrammable)
            {
                glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, wCfg.glMajor);
                glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, wCfg.glMinor);
                glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
            }
            else
            {
                glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 2);
                glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 1);
            }
        }

        GLFWwindow* win = glfwCreateWindow(wCfg.width, wCfg.height, wCfg.title, nullptr, nullptr);
        if (!win) 
        { 
            glfwTerminate(); return nullptr; 
        }
        
        glfwMakeContextCurrent(win);
        if (wCfg.vsync)
        {
            glfwSwapInterval(1);
        }

        glewExperimental = GL_TRUE;
        if (glewInit() != GLEW_OK)
        { 
            glfwDestroyWindow(win); 
            glfwTerminate(); 
            return nullptr; 
        }
        glViewport(0, 0, wCfg.width, wCfg.height);

        return win;
    }

    void PollAndSwap(void* pGlfwWindow)
    { 
        GLFWwindow* win = (GLFWwindow*)pGlfwWindow;
        glfwSwapBuffers(win); 
        glfwPollEvents();
    }

    bool WindowShouldClose(void* pGlfwWindow)
    { 
        GLFWwindow* win = (GLFWwindow*)pGlfwWindow;
        return glfwWindowShouldClose(win); 
    }

    void DestroyWindow(void* pGlfwWindow)
    { 
        GLFWwindow* win = (GLFWwindow*)pGlfwWindow;
        if (win) 
        { 
            glfwDestroyWindow(win); 
        } 
        
        glfwTerminate(); 
    }
}