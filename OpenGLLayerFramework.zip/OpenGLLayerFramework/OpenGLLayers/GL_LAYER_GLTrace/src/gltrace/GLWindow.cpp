#include "gltrace/GLWindow.hpp"

namespace gltrace
{
    void* InitGLAndWindow(const WindowInitConfig& wCfg) 
    {
        if (!glfwInit())
        {
            return nullptr;
        }

        if (wCfg.coreProfile)
        {
            glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, wCfg.glMajor);
            glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, wCfg.glMinor);
            glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
        }

        GLFWwindow* win = glfwCreateWindow(wCfg.width, wCfg.height, wCfg.title, nullptr, nullptr);
        if (!win) 
        { 
            glfwTerminate(); return nullptr; 
        }
        
        glfwMakeContextCurrent(win);
        if (wCfg.vsync)
        {
            glfwSwapInterval(1);
        }

        glewExperimental = GL_TRUE;
        if (glewInit() != GLEW_OK)
        { 
            glfwDestroyWindow(win); 
            glfwTerminate(); 
            return nullptr; 
        }

        return win;
    }

    void PollAndSwap(void* pGlfwWindow)
    { 
        GLFWwindow* win = (GLFWwindow*)pGlfwWindow;
        glfwPollEvents(); 
        glfwSwapBuffers(win); 
    }

    bool WindowShouldClose(void* pGlfwWindow)
    { 
        GLFWwindow* win = (GLFWwindow*)pGlfwWindow;
        return glfwWindowShouldClose(win); 
    }

    void DestroyWindow(void* pGlfwWindow)
    { 
        GLFWwindow* win = (GLFWwindow*)pGlfwWindow;
        if (win) 
        { 
            glfwDestroyWindow(win); 
        } 
        
        glfwTerminate(); 
    }
}