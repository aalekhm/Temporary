﻿#include <Windows.h>
#include <gl/GL.h>
#include <iostream>

const char* functionsToHook[] = { "glVertex3f" };
const int	iFunctionsToHookCount = 1;
static void (*g_pFnNext_glVertex3f)(GLfloat x, GLfloat y, GLfloat z) = nullptr;

void APIENTRY Hooked_glVertex3f(GLfloat x, GLfloat y, GLfloat z)
{
	if (g_pFnNext_glVertex3f)
	{
		g_pFnNext_glVertex3f(y, x, z);
	}
}

extern "C" __declspec(dllexport) const char** OGLLayer_GetFunctionNames(int* iCount)
{
	*iCount = iFunctionsToHookCount;
	return functionsToHook;
}

extern "C" __declspec(dllexport) void* OGLLayer_GetProcAddress(const char* pFuncName, void* pFnNext)
{
	if (strcmp(pFuncName, "glVertex3f") == 0)
	{
		g_pFnNext_glVertex3f = (void (*)(GLfloat, GLfloat, GLfloat))pFnNext;
		return (void*)&Hooked_glVertex3f;
	}

	return nullptr;
}
