﻿#include <Windows.h>
#include <gl/GL.h>
#include <iostream>

typedef void (*GenericGLFunc)();
static GenericGLFunc(*g_pFn_CallNextInChain)(const std::string&, int32_t) = nullptr;
static int32_t	g_iLayerPosition = -1;

const char* functionsToHook[] = { "glVertex3f" };
const int	iFunctionsToHookCount = 1;
static void (*g_pFnNext_glVertex3f)(GLfloat x, GLfloat y, GLfloat z) = nullptr;

#define CALL_NEXT_IN_CHAIN(__glCall__, __ModuleID__, __FUNC_DEFN__, ...)							\
    do {																							\
		GenericGLFunc pFnNext = (GenericGLFunc)(*g_pFn_CallNextInChain)(#__glCall__, __ModuleID__); \
		g_pFnNext_##__glCall__ = __FUNC_DEFN__##pFnNext;											\
		if(g_pFnNext_##__glCall__) g_pFnNext_##__glCall__(__VA_ARGS__);								\
    } while (0);																					\

void APIENTRY Hooked_g_pFnNext_glVertex3f(GLfloat x, GLfloat y, GLfloat z)
{
	CALL_NEXT_IN_CHAIN(glVertex3f, g_iLayerPosition, (void (*)(GLfloat, GLfloat, GLfloat)), x, y, z);
}

extern "C" __declspec(dllexport) void OGLLayer_SetNextInChain(int32_t iLayerPosition, void* pFn_CallNextInChain)
{
	g_iLayerPosition = iLayerPosition;
	g_pFn_CallNextInChain = (GenericGLFunc(*)(const std::string&, int32_t))pFn_CallNextInChain;
}

extern "C" __declspec(dllexport) const char** OGLLayer_GetFunctionNames(int* iCount)
{
	*iCount = iFunctionsToHookCount;
	return functionsToHook;
}

extern "C" __declspec(dllexport) void* OGLLayer_GetHookedProcAddress(const char* pFuncName, void* pFnNext)
{
	if (strcmp(pFuncName, "glVertex3f") == 0)
	{
		return (void*)&Hooked_g_pFnNext_glVertex3f;
	}

	return nullptr;
}
