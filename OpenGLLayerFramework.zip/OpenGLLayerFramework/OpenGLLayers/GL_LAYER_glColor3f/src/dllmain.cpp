﻿#include <Windows.h>
#include <gl/GL.h>
#include <iostream>

const char* functionsToHook[] = { "glColor3f" };
const int	iFunctionsToHookCount = 1;
static void (*g_pFnNext_glColor3f)(GLfloat red, GLfloat green, GLfloat blue) = nullptr;

void APIENTRY Hooked_glColor3f(GLfloat red, GLfloat green, GLfloat blue)
{
	if (g_pFnNext_glColor3f)
	{
		g_pFnNext_glColor3f(green, blue, red);
	}
}

extern "C" __declspec(dllexport) void OGLLayer_SetPatchUnPatchFunctions(void* pFn_Patch, void* pFn_UnPatch)
{
}

extern "C" __declspec(dllexport) const char** OGLLayer_GetFunctionNames(int* iCount)
{
	*iCount = iFunctionsToHookCount;
	return functionsToHook;
}

extern "C" __declspec(dllexport) void* OGLLayer_GetHookedProcAddress(const char* pFuncName, void* pFnNext)
{
	if (strcmp(pFuncName, "glColor3f") == 0)
	{
		g_pFnNext_glColor3f = (void (*)(GLfloat, GLfloat, GLfloat))pFnNext;
		return (void*)&Hooked_glColor3f;
	}

	return nullptr;
}
