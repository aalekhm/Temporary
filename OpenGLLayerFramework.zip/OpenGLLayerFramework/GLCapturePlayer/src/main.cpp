// ========== file: src/capture_demo.cpp =
#include "gltrace/gltrace.hpp"
#include <Windows.h>
#include <iostream>
#include <vector>
#include <cmath>
#include <GL/GL.h>
#include <GL/glew.h>
//#include <glad/glad.h>

#define CAPTURE_FILE "..\\x64\\Debug\\capture.gltrace"

static const char* vsrc = R"GLSL(
#version 330 core
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec2 aUV;
uniform mat4 uMVP;
out vec2 vUV;
void main() {
    vUV = aUV;
    gl_Position = uMVP * vec4(aPos, 1.0);
}
)GLSL";

static const char* fsrc = R"GLSL(
#version 330 core
in vec2 vUV;
out vec4 FragColor;
uniform sampler2D uTex;
uniform vec4 uTint;
void main() {
    FragColor = texture(uTex, vUV) * uTint;
}
)GLSL";

using namespace gltrace;

#define USE_PROGRAMMABLE_PIPELINE 1
GLFWwindow* _initGLFW(const char* sWindowTitle)
{
    if (!glfwInit())
    {
        exit(EXIT_FAILURE);
    }

#if (USE_PROGRAMMABLE_PIPELINE == 1)
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
#else
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 2);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 1);
#endif

    GLFWwindow* win = glfwCreateWindow(960, 640, sWindowTitle, nullptr, nullptr);
    if (win == nullptr)
    {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }

    // This function makes the OpenGL or OpenGL ES context of the specified window current on the calling thread.
    glfwMakeContextCurrent(win);
    glfwSwapInterval(1);

    // Initialize GLEW
    glewExperimental = GL_TRUE;
    if (glewInit() != GLEW_OK)
    {
        exit(EXIT_FAILURE);
    }

    return win;
}

int main() 
{
    gltrace::WindowInitConfig cfg;
    {
        cfg.title = "Capture Window";
        cfg.vsync = true;
    }

    GLFWwindow* win = _initGLFW("cfg");
    if (!win)
    {
        fprintf(stderr, "Failed to init window+GL\n"); return 1;
    }

    Logger logger(CAPTURE_FILE);
    LoadLibraryA("OpenGLLayerFramework.dll");

    // --- Create shader program
    GLuint vs = ::glCreateShader(GL_VERTEX_SHADER);
    ::glShaderSource(vs, 1, &vsrc, NULL);
    ::glCompileShader(vs);

    GLuint fs = ::glCreateShader(GL_FRAGMENT_SHADER);
    ::glShaderSource(fs, 1, &fsrc, NULL);
    ::glCompileShader(fs);

    GLuint prog = ::glCreateProgram();
    ::glAttachShader(prog, vs);
    ::glAttachShader(prog, fs);
    ::glLinkProgram(prog);

    // --- Geometry
    float verts[] = 
    {
        // pos       // uv
        -0.5f, -0.5f, 0.0f,  0.f, 0.f,
         0.5f, -0.5f, 0.0f,  1.f, 0.f,
         0.5f,  0.5f, 0.0f,  1.f, 1.f,
        -0.5f,  0.5f, 0.0f,  0.f, 1.f
    };
    unsigned int idx[] = { 0, 1, 2, 2, 3, 0 };

    GLuint vao, vbo, ebo;
    ::glGenVertexArrays(1, &vao);
    ::glBindVertexArray(vao);

    ::glGenBuffers(1, &vbo);
    ::glBindBuffer(GL_ARRAY_BUFFER, vbo);
    ::glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);

    ::glGenBuffers(1, &ebo);
    ::glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);
    ::glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(idx), idx, GL_STATIC_DRAW);

    ::glEnableVertexAttribArray(0);
    ::glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)0);
    ::glEnableVertexAttribArray(1);
    ::glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(3 * sizeof(float)));

    // --- Texture
    GLuint tex;
    ::glGenTextures(1, &tex);
    ::glActiveTexture(GL_TEXTURE0);
    ::glBindTexture(GL_TEXTURE_2D, tex);

    // Simple checkerboard
    const int TEXSZ = 4;
    unsigned char checker[TEXSZ * TEXSZ * 3];
    for (int y = 0; y < TEXSZ; y++) 
    {
        for (int x = 0; x < TEXSZ; x++) 
        {
            int c = ((x ^ y) & 1) ? 255 : 0;
            checker[(y * TEXSZ + x) * 3 + 0] = (unsigned char)c;
            checker[(y * TEXSZ + x) * 3 + 1] = (unsigned char)(255 - c);
            checker[(y * TEXSZ + x) * 3 + 2] = 0;
        }
    }

    ::glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, TEXSZ, TEXSZ, 0, GL_RGB, GL_UNSIGNED_BYTE, checker);
    ::glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    ::glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

    // --- FBO
    GLuint fbo;
    ::glGenFramebuffers(1, &fbo);
    ::glBindFramebuffer(GL_FRAMEBUFFER, fbo);
    ::glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, tex, 0);
    ::glBindFramebuffer(GL_FRAMEBUFFER, 0);

    // --- Uniform locations
    GLint uMVP  = ::glGetUniformLocation(prog, "uMVP");
    GLint uTint = ::glGetUniformLocation(prog, "uTint");
    GLint uTex  = ::glGetUniformLocation(prog, "uTex");

    // Render loop (capture a few frames)
    for (int frame = 0; frame < 50; frame++) 
    {
        float t = frame / 50.0f;
        ::glViewport(0, 0, 800, 600);
        ::glClearColor(1.0f, 1.0f, 0.0f, 1.0f);
        ::glClear(GL_COLOR_BUFFER_BIT);

        ::glUseProgram(prog);

        // Uniforms
        //float tint[4] = { 1.0f, t, 1.0f - t, 1.0f };
        //Uniform4fv(logger, uTint, 4, tint); -> Revisit
        ::glUniform4f(uTint, 1.0f, t, 1.0f - t, 1.0f);

        float ident[16] = {
            1,0,0,0,  0,1,0,0,
            0,0,1,0,  0,0,0,1
        };
        ::glUniformMatrix4fv(uMVP, 1, GL_FALSE, ident);

        ::glUniform1i(uTex, 0);

        // State changes
        ::glEnable(GL_BLEND);
        ::glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

        ::glBindVertexArray(vao);
        ::glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);

        ::glDisable(GL_BLEND);

        //GLFWwindow* pWin = (GLFWwindow*)win;
        //::glfwSwapBuffers(pWin);
        //::glfwPollEvents();
        PollAndSwap(win);
    }

    DestroyWindow(win);

    return 0;
}
