// ========== file: src/capture_demo.cpp =
#include "gltrace/gltrace.hpp"
#include <iostream>
#include <vector>
#include <cmath>

#define CAPTURE_FILE "..\\x64\\Debug\\capture_1.gltrace"

static const char* vsrc = R"GLSL(
#version 330 core
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec2 aUV;
uniform mat4 uMVP;
out vec2 vUV;
void main() {
    vUV = aUV;
    gl_Position = uMVP * vec4(aPos, 1.0);
}
)GLSL";

static const char* fsrc = R"GLSL(
#version 330 core
in vec2 vUV;
out vec4 FragColor;
uniform sampler2D uTex;
uniform vec4 uTint;
void main() {
    FragColor = texture(uTex, vUV) * uTint;
}
)GLSL";

using namespace gltrace;

int main() 
{
    gltrace::WindowInitConfig cfg;
    {
        cfg.title = "Capture Window";
        cfg.vsync = true;
    }

    GLFWwindow* win = (GLFWwindow*)gltrace::InitGLAndWindow(cfg);
    if (!win)
    {
        fprintf(stderr, "Failed to init window+GL\n"); return 1;
    }

    Logger logger(CAPTURE_FILE);

    // --- Create shader program
    GLuint vs = gltrace::glCreateShader(logger, GL_VERTEX_SHADER);
    gltrace::glShaderSource(logger, vs, vsrc);
    gltrace::glCompileShader(logger, vs);

    GLuint fs = gltrace::glCreateShader(logger, GL_FRAGMENT_SHADER);
    gltrace::glShaderSource(logger, fs, fsrc);
    gltrace::glCompileShader(logger, fs);

    GLuint prog = gltrace::glCreateProgram(logger);
    gltrace::glAttachShader(logger, prog, vs);
    gltrace::glAttachShader(logger, prog, fs);
    gltrace::glLinkProgram(logger, prog);

    // --- Geometry
    float verts[] = 
    {
        // pos       // uv
        -0.5f, -0.5f, 0.0f,  0.f, 0.f,
         0.5f, -0.5f, 0.0f,  1.f, 0.f,
         0.5f,  0.5f, 0.0f,  1.f, 1.f,
        -0.5f,  0.5f, 0.0f,  0.f, 1.f
    };
    unsigned int idx[] = { 0, 1, 2, 2, 3, 0 };

    GLuint vao, vbo, ebo;
    gltrace::glGenVertexArrays(logger, 1, &vao);
    gltrace::glBindVertexArray(logger, vao);

    gltrace::glGenBuffers(logger, 1, &vbo);
    gltrace::glBindBuffer(logger, GL_ARRAY_BUFFER, vbo);
    gltrace::glBufferData(logger, GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);

    gltrace::glGenBuffers(logger, 1, &ebo);
    gltrace::glBindBuffer(logger, GL_ELEMENT_ARRAY_BUFFER, ebo);
    gltrace::glBufferData(logger, GL_ELEMENT_ARRAY_BUFFER, sizeof(idx), idx, GL_STATIC_DRAW);

    gltrace::glEnableVertexAttribArray(logger, 0);
    gltrace::glVertexAttribPointer(logger, 0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)0);
    gltrace::glEnableVertexAttribArray(logger, 1);
    gltrace::glVertexAttribPointer(logger, 1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(3 * sizeof(float)));

    // --- Texture
    GLuint tex;
    gltrace::glGenTextures(logger, 1, &tex);
    gltrace::glActiveTexture(logger, GL_TEXTURE0);
    gltrace::glBindTexture(logger, GL_TEXTURE_2D, tex);

    // Simple checkerboard
    const int TEXSZ = 4;
    unsigned char checker[TEXSZ * TEXSZ * 3];
    for (int y = 0; y < TEXSZ; y++) 
    {
        for (int x = 0; x < TEXSZ; x++) 
        {
            int c = ((x ^ y) & 1) ? 255 : 0;
            checker[(y * TEXSZ + x) * 3 + 0] = (unsigned char)c;
            checker[(y * TEXSZ + x) * 3 + 1] = (unsigned char)(255 - c);
            checker[(y * TEXSZ + x) * 3 + 2] = 0;
        }
    }

    gltrace::glTexImage2D(logger, GL_TEXTURE_2D, 0, GL_RGB, TEXSZ, TEXSZ, 0, GL_RGB, GL_UNSIGNED_BYTE, checker);
    gltrace::glTexParameteri(logger, GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    gltrace::glTexParameteri(logger, GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

    // --- FBO
    GLuint fbo;
    gltrace::glGenFramebuffers(logger, 1, &fbo);
    gltrace::glBindFramebuffer(logger, GL_FRAMEBUFFER, fbo);
    gltrace::glFramebufferTexture2D(logger, GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, tex, 0);
    gltrace::glBindFramebuffer(logger, GL_FRAMEBUFFER, 0);

    // --- Uniform locations
    GLint uMVP = gltrace::glGetUniformLocation(logger, prog, "uMVP");
    GLint uTint = gltrace::glGetUniformLocation(logger, prog, "uTint");
    GLint uTex = gltrace::glGetUniformLocation(logger, prog, "uTex");

    // Render loop (capture a few frames)
    for (int frame = 0; frame < 50; frame++) 
    {
        float t = frame / 50.0f;
        gltrace::glViewport(logger, 0, 0, 800, 600);
        gltrace::glClearColor(logger, 0.2f, 0.3f, 0.3f, 1.0f);
        gltrace::glClear(logger, GL_COLOR_BUFFER_BIT);

        gltrace::glUseProgram(logger, prog);

        // Uniforms
        float tint[4] = { 1.0f, t, 1.0f - t, 1.0f };
        //Uniform4fv(logger, uTint, 4, tint); -> Revisit
        gltrace::glUniform4f(logger, uTint, 1.0f, t, 1.0f - t, 1.0f);

        float ident[16] = {
            1,0,0,0,  0,1,0,0,
            0,0,1,0,  0,0,0,1
        };
        gltrace::glUniformMatrix4fv(logger, uMVP, 1, GL_FALSE, ident);

        gltrace::glUniform1i(logger, uTex, 0);

        // State changes
        gltrace::glEnableCap(logger, GL_BLEND);
        gltrace::glBlendFunc(logger, GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

        gltrace::glBindVertexArray(logger, vao);
        gltrace::glDrawElements(logger, GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);

        gltrace::glDisableCap(logger, GL_BLEND);

        FrameMarker(logger, frame);
        PollAndSwap(win);
    }

    DestroyWindow(win);

    return 0;
}
